import pathlib,time,json,os
P=pathlib.Path
JOB_ORIGIN=time.time()
prepcode=P('/tmp/r5_whole_backend_new_prepare_only_20261003.py').read_text().replace('tm-r5wholebackend-current-prepare.','tm-r5whole-receiptfix-fresh-prepare.')
a=prepcode.index("prior=json.loads(");b=prepcode.index("web=json.loads(",a)
prepcode=prepcode[:a]+'''prior=json.loads(P('/private/tmp/tm-r5wholebackend-current-prepare.q9k55v42/source-receipt.json').read_text());prior_compiled={k:v for k,v in prior['files'].items() if k.endswith(('.go','.sql','.css','.js')) or k in {'go.mod','go.sum'} or k.endswith(('/go.mod','/go.sum'))};allow={'internal/store/postgres/r5_legacy_content_test.go':'772fee9066e24b1602f32aae87dda5d212e7b56ee9e567a5d3c5027d06ace138','internal/store/postgres/r5_outbound_receipt_test.go':'479468473933b723b8a349dd413f86a9562bee4f56811bf37e5653028fb5f7ab'};drift=[k for k,v in prior_compiled.items() if files.get(k)!=allow.get(k,v)];assert not drift,('unapproved Go/module/embed drift',drift);assert all(files[k]==v for k,v in allow.items())
newGo=set(k for k in files if k.endswith('.go'))-set(k for k in prior['files'] if k.endswith('.go'));assert newGo=={'internal/store/postgres/r5_current_benchmark_catalog_test.go'},('unknown new Go files',newGo);assert files['internal/store/postgres/r5_current_benchmark_catalog_test.go']=='54c4b01377fff30e42b9d0b56327b419a7f19147d9d24c69aa139ec9726961fc';assert (src/'internal/store/postgres/r5_current_benchmark_catalog_test.go').read_text().startswith('//go:build r5benchmark\\n')
''' +prepcode[b:]
prepcode=prepcode.replace("'current_compiled_go_module_embed_unchanged_from_latest_approved720':True", "'default_compile_source_only_2approved_receipt_tests_changed':True,'new_r5benchmark_catalog_54c4_static_only_excluded_default':True,'receipt5_source_actualboundedPASS':True")
prepcode=prepcode.replace('no runtime授权','root_authorized_once1200_originpre-capture').replace("'PREPARED_ONLY_whole_runtime_not_authorized'", "'AUTHORIZED_SINGLE_FRESH_WHOLE_after_receiptfix'")
prepcode=prepcode.replace('timeout=cap,receipt=rec','timeout=min(cap,JOB_ORIGIN+1170-time.time()),receipt=rec')
# One capture and GoList/AST discovery are part of the same original job budget.
exec(compile(prepcode,'authorized_fresh_whole_preparation','exec'),globals())
prepared=root
(root/'original-authorized-job-origin.json').write_text(json.dumps({'origin_wall_beforecapture':JOB_ORIGIN,'deadline':JOB_ORIGIN+1200,'workstop':JOB_ORIGIN+1170,'initcapture_andcleanup_included':True})+'\n')
# Verify the tagged-only new catalog is absent from actual default GoList inputs.
raw=(root/'phases/actual-default-root-GoList/stdout').read_text();dec=json.JSONDecoder();pos=0;gopackages=[]
while pos<len(raw):
 while pos<len(raw) and raw[pos].isspace():pos+=1
 if pos>=len(raw):break
 obj,pos=dec.raw_decode(raw,pos);gopackages.append(obj)
for obj in gopackages:
 if obj['ImportPath']=='tabmail/internal/store/postgres':
  assert 'r5_current_benchmark_catalog_test.go' not in obj.get('TestGoFiles',[])
  assert 'r5_current_benchmark_catalog_test.go' in obj.get('IgnoredGoFiles',[])
(root/'default-tagged-catalog-exclusion-proof.json').write_text(json.dumps({'tagged54c4file_present_in_static_superset_but_ignored_actual_default':True,'actualrootGoList_AST_boundary_excludes_nestedfork_upstreamtests':True})+'\n')
auditcode=P('/tmp/r5_current_whole_prepare_transitive_input_audit_20261003.py').read_text().replace("root=P('/private/tmp/tm-r5wholebackend-current-prepare.q9k55v42')", "root=P('"+str(root)+"')").replace('no whole runtime','before sole authorized whole runtime').replace("'whole_runtime_not_started_or_authorized':True", "'whole_runtime_not_started_yet':True").replace('new handler3 scopes executed independently; GoList0 itself never runtime evidence','wholeGo actual runtime independent of metadata, GoList0 not PASSproof')
exec(compile(auditcode,'fresh_transitive_compileinput_audit','exec'),globals());assert not missing and not errors,'selected local compilation inputs unknown'
# Generate fresh mandatory identity manifest from actual current ROOT discovery.
actual=json.loads((prepared/'actual-current-required-test-set.json').read_text());packet=prepared/'current-packet';packet.mkdir(mode=0o700)
oldpacket=P('/private/tmp/tm-r5wholebackend-current-prepare.q9k55v42/current-packet')
shutil.copyfile(oldpacket/'classify_full.py',packet/'classify_full.py');shutil.copyfile(oldpacket/'original-required_go_tests.json',packet/'original-required_go_tests.json')
dump(packet/'current-source-manifest.json',{'version':1,'suites':{'current-dirty-full-default':{'required_tests':actual['required'],'allowed_skips':[{'identity':actual['only_allowed_skip'],'reason':'BrowserJourney official shipping-only outside backend; G0notgreen'}]}}})
dump(packet/'source-inventory.json',{'current_source_sha':identity['source_sha'],'declared_tests':actual['declared'],'required_tests':actual['required'],'expected_default_packages':actual['root_packages'],'default_declared_top_level_count':len(actual['declared']),'default_required_count':len(actual['required'])})
# Prepare full exact native/Go runtime by replacing source-specific receipt bindings only.
native=P('/tmp/r5_wholeGo_current0cf_authorized_once_20261003.py').read_text()
start=native.index("P=pathlib.Path;");end=native.index("main=P('/Users/jin/Desktop/tabmail')",start)
native=native[:start]+"P=pathlib.Path;prepared=P('"+str(prepared)+"');src=prepared/'src';identity=json.loads((prepared/'source-receipt.json').read_text());"+native[end:]
native=native.replace('origin=time.time();deadline=origin+1200','origin='+repr(JOB_ORIGIN)+';deadline=origin+1200').replace('tm-r5wholeGo0cf-current.','tm-r5wholeGo-receiptfix-current.').replace('port=55539','port=55541').replace("dbname='tm_whole_current_validation'","dbname='tm_whole_receiptfix_validation'")
native=native.replace("'same_immutable0cf_source':True", "'fresh_receiptfix_current_immutable_source':True").replace("'actual_selected_localcompile_embed_files510_compared_to_current_unchanged':True", "'all_actual_selected_localcompile_embed_files_compared_to_current_unchanged':True")
native=native.replace("'actual_declared908_required907_packages51':True", "'actual_required_set':{'declared':len(actual['declared']),'required':len(actual['required']),'packages':len(actual['root_packages'])}").replace('fresh-required907-classifier','fresh-required-current-classifier').replace('all1229tested_inputbytes_equal','all_current_tested_inputbytes_equal')
native=native.replace("'scoped_webhook9_history5_MIME224_approvedprep':True", "'scoped_webhook9_history5_MIME224_receipt2_refs14_approved':True").replace('sameimmutable0cf','newcurrentimmutable')
# None of stale original labels change old raw; this is a new execution input.
P('/tmp/r5_whole_receiptfix_actual_native_generated_20261003.py').write_text(native)
exec(compile(native,'fresh_receiptfix_authorized_native_runtime','exec'),globals())
