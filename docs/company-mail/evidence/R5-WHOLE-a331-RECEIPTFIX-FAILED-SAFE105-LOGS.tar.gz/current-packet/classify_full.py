#!/usr/bin/env python3
"""Pure log classification for a future full invocation; never runs Go."""
import argparse,importlib.util,json,pathlib
p=argparse.ArgumentParser();p.add_argument('--packet',required=True,type=pathlib.Path);p.add_argument('--source',required=True,type=pathlib.Path);p.add_argument('--log',required=True,type=pathlib.Path);p.add_argument('--exit-code',required=True,type=int);p.add_argument('--source-sha',required=True);a=p.parse_args()
spec=importlib.util.spec_from_file_location('current_gate',a.source/'scripts/check_go_test_evidence.py');gate=importlib.util.module_from_spec(spec);spec.loader.exec_module(gate)
required,allowed=gate.load_suite(a.packet/'current-source-manifest.json','current-dirty-full-default')
raw=a.log.read_text();result=gate.evaluate(raw.splitlines(),required,allowed,a.exit_code)
inventory=json.loads((a.packet/'source-inventory.json').read_text());completed={}
for line in raw.splitlines():
 try:e=json.loads(line)
 except ValueError:continue
 if not e.get('Test') and e.get('Action') in {'pass','fail','skip'}:completed[e.get('Package')]=e['Action']
missing=sorted(set(inventory['expected_default_packages'])-set(completed))
if missing:result['errors'].append('required source packages missing terminal lifecycle: '+str(missing))
result.update(source_sha=a.source_sha,source_identity_kind='executor_frozen_dirty_tree_not_HEAD',missing_required_packages=missing,default_expected_target_red=[],unknown_failures_allowed=0,runtime_executed=True,product_green=False,task_complete=False)
result['status']='pass' if not result['errors'] else 'fail'
print(json.dumps(result,ensure_ascii=False,indent=2));raise SystemExit(0 if result['status']=='pass' else 1)
