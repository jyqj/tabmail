package postgres

import (
	"context"
	"encoding/json"
	"errors"
	"github.com/google/uuid"
	"github.com/jackc/pgx/v5"
	"tabmail/internal/app"
	"tabmail/internal/app/credentials"
	"tabmail/internal/authz"
	"tabmail/internal/company"
)

func (s *PgStore) GetParsedMessage(ctx context.Context, a authz.Actor, mailbox, id uuid.UUID) (*company.ParsedMessage, error) {
	var out *company.ParsedMessage
	e := s.companyReadTx(ctx, a, false, func(tx pgx.Tx, a authz.Actor) error {
		if e := s.authorizeReceivedMailboxTx(ctx, tx, a, mailbox); e != nil {
			return e
		}

		if e := requireReceivedContentTx(ctx, tx, a.TenantID, mailbox, id); e != nil {
			return e
		}
		d := &company.ParsedMessage{MessageID: id}
		var parts []byte
		e := tx.QueryRow(ctx, `SELECT d.source_key,d.source_sha256,d.parser_version,d.text_body,d.html_body,d.body_access,d.parts,d.thread_key FROM mail_documents d JOIN messages m ON m.id=d.message_id AND m.tenant_id=d.tenant_id AND m.raw_object_key=d.source_key WHERE m.tenant_id=$1 AND m.mailbox_id=$2 AND m.id=$3 AND d.parser_version=1 AND `+receivedContentEligible, a.TenantID, mailbox, id).Scan(&d.SourceKey, &d.SourceSHA256, &d.ParserVersion, &d.TextBody, &d.HTMLBody, &d.BodyAccess, &parts, &d.ThreadKey)
		if errors.Is(e, pgx.ErrNoRows) {
			// A deadline can cross between the initial qualification and cache
			// lookup. Only an eligible cache miss may fall back to object I/O.
			return requireReceivedContentTx(ctx, tx, a.TenantID, mailbox, id)
		}
		if e != nil {
			return e
		}
		if e = json.Unmarshal(parts, &d.Parts); e != nil {
			return e
		}
		out = d
		return nil
	})
	if e != nil {
		return nil, e
	}
	return out, nil
}
func saveParsed(ctx context.Context, tx pgx.Tx, tenant uuid.UUID, d company.ParsedMessage) error {
	if d.ParserVersion != 1 || len(d.SourceSHA256) != 64 || len(d.Parts) > 512 {
		return app.BadRequest("invalid parser document")
	}
	parts, e := json.Marshal(d.Parts)
	if e != nil {
		return e
	}
	tag, e := tx.Exec(ctx, `INSERT INTO mail_documents(tenant_id,message_id,source_key,source_sha256,parser_version,text_body,html_body,body_access,parts,thread_key,search_text)
 SELECT m.tenant_id,m.id,m.raw_object_key,$4,$5,$6,$7,$8,$9,$10,concat_ws(E'\n',m.subject,m.sender,array_to_string(m.recipients,','),$6::text)
 FROM messages m WHERE m.tenant_id=$1 AND m.id=$2 AND m.raw_object_key=$3
 ON CONFLICT(message_id) DO UPDATE SET source_key=EXCLUDED.source_key,source_sha256=EXCLUDED.source_sha256,parser_version=EXCLUDED.parser_version,text_body=EXCLUDED.text_body,html_body=EXCLUDED.html_body,body_access=EXCLUDED.body_access,parts=EXCLUDED.parts,thread_key=EXCLUDED.thread_key,search_text=EXCLUDED.search_text,indexed_at=now()`, tenant, d.MessageID, d.SourceKey, d.SourceSHA256, d.ParserVersion, d.TextBody, d.HTMLBody, d.BodyAccess, parts, d.ThreadKey)
	if e != nil {
		return e
	}
	if tag.RowsAffected() != 1 {
		return app.Conflict("message source changed")
	}
	return nil
}
func (s *PgStore) SaveParsedMessage(ctx context.Context, a authz.Actor, mailbox uuid.UUID, d company.ParsedMessage) error {
	return s.companyReadTx(ctx, a, false, func(tx pgx.Tx, a authz.Actor) error {
		if e := s.authorizeReceivedMailboxTx(ctx, tx, a, mailbox); e != nil {
			return e
		}

		// The document's FK protects this message, not an ancestor tenant.
		// Physical delete owns the message before updating mailbox count;
		// never wait in the opposite direction while holding mailbox SHARE.
		var source uuid.UUID
		e := tx.QueryRow(ctx, `SELECT id FROM messages WHERE tenant_id=$1 AND mailbox_id=$2 AND id=$3 AND raw_object_key=$4 FOR SHARE NOWAIT`, a.TenantID, mailbox, d.MessageID, d.SourceKey).Scan(&source)
		if errors.Is(e, pgx.ErrNoRows) {
			return app.NotFound("message not found")
		}
		if e != nil {
			return e
		}
		if e = requireReceivedContentTx(ctx, tx, a.TenantID, mailbox, d.MessageID); e != nil {
			return e
		}
		return saveParsed(ctx, tx, a.TenantID, d)
	})
}
func (s *PgStore) ContentIndexStatus(ctx context.Context, a authz.Actor, mailbox uuid.UUID) (*company.ContentIndexStatus, error) {
	out := &company.ContentIndexStatus{}
	e := s.companyReadTx(ctx, a, false, func(tx pgx.Tx, a authz.Actor) error {
		if e := s.authorizeReceivedMailboxTx(ctx, tx, a, mailbox); e != nil {
			return e
		}

		return tx.QueryRow(ctx, `SELECT count(*),count(d.message_id),count(*) FILTER(WHERE j.state='failed') FROM messages m LEFT JOIN mail_documents d ON d.tenant_id=m.tenant_id AND d.message_id=m.id AND d.source_key=m.raw_object_key AND d.parser_version=1 LEFT JOIN mail_index_jobs j ON j.tenant_id=m.tenant_id AND j.message_id=m.id WHERE m.tenant_id=$1 AND m.mailbox_id=$2 AND m.deleted_at IS NULL AND `+receivedContentEligible, a.TenantID, mailbox).Scan(&out.Total, &out.Indexed, &out.Failed)
	})
	if e != nil {
		return nil, e
	}
	return out, nil
}
func (s *PgStore) ClaimMailIndexJobs(ctx context.Context, limit int) ([]company.MailIndexJob, error) {
	if limit < 1 || limit > 20 {
		limit = 5
	}
	// A worker that repeatedly crashes cannot hold a derived job forever. The
	// existing token/lease predicate is rechecked under the row lock.
	if _, e := s.pool.Exec(ctx, `UPDATE mail_index_jobs SET state='failed',lease_until=NULL,lease_token=NULL,last_error='index worker lease expired' WHERE state='processing' AND lease_until<now() AND attempts>=5`); e != nil {
		return nil, e
	}
	rows, e := s.pool.Query(ctx, `WITH picked AS(SELECT message_id FROM mail_index_jobs WHERE attempts<5 AND ((state='pending' AND next_attempt_at<=now()) OR (state='processing' AND lease_until<now())) ORDER BY next_attempt_at,message_id LIMIT $1 FOR UPDATE SKIP LOCKED)
 UPDATE mail_index_jobs j SET state='processing',attempts=attempts+1,lease_token=gen_random_uuid(),lease_until=now()+interval '90 seconds' FROM picked p WHERE j.message_id=p.message_id RETURNING j.tenant_id,j.message_id,j.source_key,j.lease_token,j.lease_until`, limit)
	if e != nil {
		return nil, e
	}
	defer rows.Close()
	out := []company.MailIndexJob{}
	for rows.Next() {
		v := company.MailIndexJob{}
		if e = rows.Scan(&v.TenantID, &v.MessageID, &v.SourceKey, &v.Token, &v.LeaseUntil); e != nil {
			return nil, e
		}
		out = append(out, v)
	}
	return out, rows.Err()
}

// lockMailIndexLease acquires the exact current job before evaluating elapsed
// time in a separate statement. A WHERE predicate evaluated before a row-lock
// wait is not a sufficient expiry check. Completion also locks the source
// message first; failure changes only the job and acquires no source locks.
func lockMailIndexLease(ctx context.Context, tx pgx.Tx, j company.MailIndexJob) error {
	var id uuid.UUID
	err := tx.QueryRow(ctx, `SELECT message_id FROM mail_index_jobs WHERE tenant_id=$1 AND message_id=$2 AND source_key=$3 AND lease_token=$4 AND state='processing' FOR UPDATE`, j.TenantID, j.MessageID, j.SourceKey, j.Token).Scan(&id)
	if errors.Is(err, pgx.ErrNoRows) {
		return app.Conflict("index lease lost")
	}
	if err != nil {
		return err
	}
	var valid bool
	if err = tx.QueryRow(ctx, `SELECT COALESCE(lease_until>clock_timestamp(),false) FROM mail_index_jobs WHERE tenant_id=$1 AND message_id=$2`, j.TenantID, j.MessageID).Scan(&valid); err != nil {
		return err
	}
	if !valid {
		return app.Conflict("index lease lost")
	}
	return nil
}

func (s *PgStore) CompleteMailIndexJob(ctx context.Context, j company.MailIndexJob, d company.ParsedMessage) error {
	if d.MessageID != j.MessageID || d.SourceKey != j.SourceKey {
		return app.Conflict("index provenance changed")
	}
	tx, e := s.pool.Begin(ctx)
	if e != nil {
		return e
	}
	defer tx.Rollback(ctx)
	// Source updates/deletion acquire the parent message before touching its
	// document/job children. SHARE protects the non-key raw_object_key too;
	// KEY SHARE alone would not serialize a source replacement.
	var source string
	e = tx.QueryRow(ctx, `SELECT raw_object_key FROM messages WHERE tenant_id=$1 AND id=$2 FOR SHARE`, j.TenantID, j.MessageID).Scan(&source)
	if errors.Is(e, pgx.ErrNoRows) {
		return app.Conflict("index provenance changed")
	}
	if e != nil {
		return e
	}
	if source != j.SourceKey {
		return app.Conflict("index provenance changed")
	}
	if e = lockMailIndexLease(ctx, tx, j); e != nil {
		return e
	}
	if e = saveParsed(ctx, tx, j.TenantID, d); e != nil {
		return e
	}
	// Document writes can wait too. Consume the lease only after all derived
	// writes, using database wall time; a late conflict rolls them all back.
	tag, e := tx.Exec(ctx, `UPDATE mail_index_jobs SET state='ready',lease_until=NULL,lease_token=NULL,last_error='' WHERE tenant_id=$1 AND message_id=$2 AND source_key=$3 AND lease_token=$4 AND state='processing' AND lease_until>clock_timestamp()`, j.TenantID, j.MessageID, j.SourceKey, j.Token)
	if e != nil {
		return e
	}
	if tag.RowsAffected() != 1 {
		return app.Conflict("index lease lost")
	}
	return tx.Commit(ctx)
}
func (s *PgStore) FailMailIndexJob(ctx context.Context, j company.MailIndexJob, reason string) error {
	tx, e := s.pool.Begin(ctx)
	if e != nil {
		return e
	}
	defer tx.Rollback(ctx)
	if e = lockMailIndexLease(ctx, tx, j); e != nil {
		return e
	}
	// Diagnostics remain coarse; caller-supplied parser content is not stored.
	// No source/document locks or object I/O are acquired on this failure path.
	tag, e := tx.Exec(ctx, `UPDATE mail_index_jobs SET state=CASE WHEN attempts>=5 THEN 'failed' ELSE 'pending' END,next_attempt_at=clock_timestamp()+interval '1 minute',lease_until=NULL,lease_token=NULL,last_error='content parsing failed' WHERE tenant_id=$1 AND message_id=$2 AND lease_token=$3 AND source_key=$4 AND state='processing' AND lease_until>clock_timestamp()`, j.TenantID, j.MessageID, j.Token, j.SourceKey)
	if e != nil {
		return e
	}
	if tag.RowsAffected() != 1 {
		return app.Conflict("index lease lost")
	}
	return tx.Commit(ctx)
}

var _ company.ParsedContentReader = (*PgStore)(nil)
var _ company.ContentIndexer = (*PgStore)(nil)

// RetryFailedMailIndex is bounded, company-scoped, audited, and excludes live
// leases. Repeating a request cannot retry work already requeued/processing.
func (s *PgStore) RetryFailedMailIndex(ctx context.Context, a authz.Actor, reason string) (int, error) {
	reason, reasonErr := credentials.AuditReason(reason)
	if reasonErr != nil {
		return 0, app.BadRequest("documented recovery reason required (8-1000 bytes)")
	}
	n := 0
	e := s.companyTx(ctx, a, true, func(tx pgx.Tx, a authz.Actor) error {
		tag, e := tx.Exec(ctx, `WITH picked AS (
   SELECT j.message_id FROM mail_index_jobs j JOIN messages m ON m.tenant_id=j.tenant_id AND m.id=j.message_id AND m.raw_object_key=j.source_key
   WHERE j.tenant_id=$1 AND j.state='failed'
   ORDER BY j.message_id LIMIT 100 FOR UPDATE OF j SKIP LOCKED
  ) UPDATE mail_index_jobs j SET state='pending',attempts=0,next_attempt_at=now(),lease_until=NULL,lease_token=NULL,last_error=''
  FROM picked p WHERE j.tenant_id=$1 AND j.message_id=p.message_id AND j.state='failed'`, a.TenantID)
		if e != nil {
			return e
		}
		n = int(tag.RowsAffected())
		return companyAudit(ctx, tx, a, "company.index_retry", "company", a.TenantID, map[string]any{"reason": reason, "requeued": n, "limit": 100})
	})
	if e != nil {
		return 0, e
	}
	return n, nil
}

var _ company.ContentIndexRecovery = (*PgStore)(nil)
