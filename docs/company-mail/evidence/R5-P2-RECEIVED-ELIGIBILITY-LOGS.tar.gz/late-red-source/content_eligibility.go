package postgres

import (
	"context"
	"errors"

	"github.com/google/uuid"
	"github.com/jackc/pgx/v5"
	"tabmail/internal/app"
	"tabmail/internal/authz"
)

// receivedContentEligible is the single received-entry lifecycle predicate.
// Alias m is internal, never request input. A recorded deadline is a snapshot,
// not recalculated from a current policy. NULL creates no deadline and proves
// no perpetual grant. Personal historical hard-expiry is the existing owner
// exemption; purge is independent even for permanent personal mailboxes.
// Physical GC's additional shared COALESCE(override,0)=0 protection is NOT a
// content grant. It remains untouched in the retention/GC implementation.
const receivedContentEligible = `(m.purge_after IS NULL OR m.purge_after>clock_timestamp())
 AND (m.expires_at IS NULL OR m.expires_at>clock_timestamp() OR EXISTS(
  SELECT 1 FROM mailboxes content_mb WHERE content_mb.tenant_id=m.tenant_id AND content_mb.id=m.mailbox_id AND content_mb.owner_user_id IS NOT NULL))`

// Call only inside companyReadTx, after its current-member SHARE fence. The
// mailbox fence serializes rights with grant/handover writers. Every deadline
// statement runs after this potentially blocking fence and uses actual DB time,
// not transaction now() or a predicate evaluated before the lock wait.
func (s *PgStore) authorizeReceivedMailboxTx(ctx context.Context, tx pgx.Tx, a authz.Actor, mailbox uuid.UUID) error {
	if err := lockMailboxAuthorization(ctx, tx, a.TenantID, mailbox); err != nil {
		return err
	}
	var live bool
	if err := tx.QueryRow(ctx, `SELECT expires_at IS NULL OR expires_at>clock_timestamp() FROM mailboxes WHERE tenant_id=$1 AND id=$2`, a.TenantID, mailbox).Scan(&live); err != nil {
		return err
	}
	if !live {
		return app.NotFound("mailbox not found")
	}
	access, err := s.mailboxAccessTx(ctx, tx, a, mailbox)
	if err != nil {
		return err
	}
	if !access.CanRead {
		return app.Forbidden("mailbox read permission required")
	}
	return nil
}

// A valid entry can legitimately lack a parsed cache, but an unavailable entry
// must never be conflated with cache miss and trigger parser/object fallback.
// This statement is also used AFTER SaveParsedMessage acquires its source lock.
func requireReceivedContentTx(ctx context.Context, tx pgx.Tx, tenant, mailbox, id uuid.UUID) error {
	var found uuid.UUID
	err := tx.QueryRow(ctx, `SELECT m.id FROM messages m WHERE m.tenant_id=$1 AND m.mailbox_id=$2 AND m.id=$3 AND `+receivedContentEligible, tenant, mailbox, id).Scan(&found)
	if errors.Is(err, pgx.ErrNoRows) {
		return app.NotFound("message not found")
	}
	return err
}
