"""Fresh protocol-only mocks: no real subprocess, signals, Go/PG or C18 grammar tests."""
import unittest,ast
from pathlib import Path
from unittest.mock import patch
import c18_rss_protocol as p
import c18_rss_controller_prepared_only as c
class C18RSSResourceProtocolNewTests(unittest.TestCase):
 def test_first_sample_and_tail_coverage(self):
  g=p.Freshness(100,200);g.sample(200.05,100.06,200.06,8);g.sample(200.15,100.16,200.16,8);g.finalize(100.20,200.20);self.assertEqual(g.samples,2)
 def test_first_sample_missing_fails(self):
  with self.assertRaisesRegex(p.ProtocolError,'first_sample_missing'):p.Freshness(100,200).finalize(100.10,200.10)
 def test_first_sample_late_fails(self):
  with self.assertRaisesRegex(p.ProtocolError,'gap_over250'):p.Freshness(100,200).sample(200.29,100.3,200.3,8)
 def test_intersample_gap_sticky_even_later_recovery(self):
  g=p.Freshness(100,200);g.sample(200,100.01,200.01,8)
  with self.assertRaisesRegex(p.ProtocolError,'gap_over250'):g.sample(200.3,100.31,200.31,8)
  with self.assertRaises(p.ProtocolError):g.finalize(100.32,200.32)
  self.assertIn('RSS_sample_gap_over250ms',g.failed)
 def test_single_ps_sampling_call_slow_fails(self):
  with self.assertRaisesRegex(p.ProtocolError,'call_over250'):p.Freshness(100,200).sample(200,100.26,200.26,8)
 def test_unknown_or_excess_RSS_fails(self):
  for value in (None,-1,True,2**30+1):
   with self.subTest(value=value),self.assertRaises(p.ProtocolError):p.Freshness(100,200).sample(200,100.01,200.01,value)
 def test_exact_RSS_threshold_is_sample_not_hardquota(self):
  g=p.Freshness(100,200);g.sample(200,100.01,200.01,2**30);self.assertEqual(g.samples,1)
 def test_tail_coverage_gap_fails(self):
  g=p.Freshness(100,200);g.sample(200,100.01,200.01,8)
  with self.assertRaisesRegex(p.ProtocolError,'gap_over250'):g.finalize(100.27,200.27)
 def test_wall_reversal_above_origin_sticky(self):
  g=p.Freshness(100,200);g.sample(200,100.10,200.10,8)
  with self.assertRaisesRegex(p.ProtocolError,'clock_reversal'):g.tick(100.09,200.11)
 def test_sleep_wall_mono_gap_fails(self):
  with self.assertRaisesRegex(p.ProtocolError,'wall_monotonic'):p.Freshness(100,200).tick(101,200.01)
 def test_import_handshake_all_prerequisites_failclosed(self):
  values={'audit_armed':True,'cpu_readback':[60,60],'ready_pid':123,'owned_pid':123,'sample':{'rss_bytes':8,'wall':100},'now':100.1}
  self.assertTrue(p.import_gate(**values))
  for k,v in [('audit_armed',False),('cpu_readback',[60,61]),('ready_pid',124),('sample',None),('now',100.3)]:
   with self.subTest(k=k),self.assertRaises(p.ProtocolError):p.import_gate(**(values|{k:v}))
 def test_signal_requires_unreaped_identity_UID_start_session(self):
  original={'pid':123,'uid':501,'pgid':123,'session_ps':'s','lstart':'start'}
  self.assertTrue(p.may_signal(original,original,unreaped=True,default_sigchld=True))
  for k,v in [('pid',124),('uid',502),('pgid',124),('session_ps','other'),('lstart','later')]:
   self.assertFalse(p.may_signal(original,original|{k:v},unreaped=True,default_sigchld=True))
  self.assertFalse(p.may_signal(original,original,unreaped=False,default_sigchld=True))
  self.assertFalse(p.may_signal(original,original,unreaped=True,default_sigchld=False))
 def test_ps_PID_parser_KiB_to_bytes_and_exact_exception_argv(self):
  class Reply:returncode=0;stdout='123 501 123 abc Fri Oct 3 01:02:03 2026 2048 S\n'
  with patch.object(c.subprocess,'run',return_value=Reply()) as m:
   value=c.owned_identity(123,.12);self.assertEqual(value['rss_bytes'],2048*1024)
   self.assertEqual(m.call_args.args[0],['/bin/ps','-p','123','-o','pid=,uid=,pgid=,sess=,lstart=,rss=,stat='])
 def test_unknown_ps_never_implies_gone(self):
  class Reply:returncode=1;stdout=''
  with patch.object(c.subprocess,'run',return_value=Reply()):
   with self.assertRaises(p.ProtocolError):c.group_observation(123,.12)
 def test_source_order_guard_noAS_and_no_runtime_import(self):
  child=(Path(__file__).parent/'c18_audited_child.py').read_text();outer=(Path(__file__).parent/'c18_rss_controller_prepared_only.py').read_text()
  self.assertLess(child.index('sys.addaudithook(hook)'),child.index('resource.setrlimit(resource.RLIMIT_CPU'))
  self.assertLess(child.index("permit=wait_permit('import-permit.json')"),child.index('import unittest'))
  self.assertNotIn('RLIMIT_AS',child);self.assertNotIn('RLIMIT_DATA',child)
  self.assertIn("TABMAIL_C18_RSS_RUNTIME_APPROVED",outer)
  self.assertLess(outer.index('signal.SIGTERM'),outer.index('grace_end='))
  self.assertLess(outer.index('signal.SIGKILL'),outer.index('returncode=process.wait',outer.index('finally:')))
  ast.parse(child);ast.parse(outer)

class C18RSSV3NarrowRepairTests(unittest.TestCase):
 def test_handshake_received_mid_ps_old_endtime_rule_rejected(self):
  oldsample={'begin_mono':200.,'mono':200.11,'wall':100.11,'rss_bytes':8}
  with self.assertRaisesRegex(p.ProtocolError,'not_after_complete_handshake'):p.post_handshake_sample_valid(200.05,oldsample)
 def test_complete_handshake_then_dedicated_query_positive(self):
  self.assertTrue(p.post_handshake_sample_valid(200.05,{'begin_mono':200.06,'mono':200.10}))
 def test_tail240ms_reported_in_maxGap_after100ms_samples(self):
  g=p.Freshness(100,200);g.sample(200.,100.01,200.01,8);g.sample(200.10,100.11,200.11,8);g.finalize(100.35,200.35)
  self.assertAlmostEqual(g.max_gap,.24,places=6)
 def test_terminal_tail_over250ms_maxGap_preserved_on_failure(self):
  g=p.Freshness(100,200);g.sample(200.,100.01,200.01,8)
  with self.assertRaises(p.ProtocolError):g.finalize(100.28,200.28)
  self.assertAlmostEqual(g.max_gap,.27,places=6)
 def test_source_postcheck_and_receipt_seal_late_never_publish(self):
  state=[];clock=p.WholeClock(100,200)
  def proofwrite():state.append('proof_written')
  def cutoff():clock.check(190.01,290.01)
  self.assertFalse(p.final_seal(proofwrite,lambda:state.append('PASS'),lambda:state.append('revoked'),cutoff,True))
  self.assertEqual(state,['proof_written','revoked'])
 def test_publish_IO_crossing90_revokes_no_new_budget(self):
  states=[];clock=p.WholeClock(100,200);times=iter([(189.99,289.99),(190.01,290.01)])
  def cutoff():clock.check(*next(times))
  self.assertFalse(p.final_seal(lambda:states.append('proof'),lambda:states.append('publish'),lambda:states.append('revoke'),cutoff,True))
  self.assertEqual(states,['proof','publish','revoke']);self.assertIn('whole_original90_exceeded',clock.failures)
 def test_source_clock_reversal_stays_failure_at_final_seal(self):
  clock=p.WholeClock(100,200);clock.check(110,210)
  with self.assertRaises(p.ProtocolError):clock.check(109,211)
  states=[]
  self.assertFalse(p.final_seal(lambda:None,lambda:states.append('PASS'),lambda:states.append('revoke'),lambda:clock.check(111,211),True))
  self.assertEqual(states,['revoke'])
 def test_write_exception_or_revoke_failure_never_accepts(self):
  def error():raise OSError('mock disk error')
  self.assertFalse(p.final_seal(error,lambda:None,lambda:None,lambda:None,True))
  with self.assertRaises(OSError):p.final_seal(error,lambda:None,error,lambda:None,True)

class C18RSSV4ParentClockWiringTests(unittest.TestCase):
 def test_controller_exit_to_cleanup_small_rollback_above_previous_write(self):
  clock=p.WholeClock(100,200)
  # Same function used by runtime controller, not isolated WholeClock-only probe.
  with patch.object(c.time,'time',return_value=109),patch.object(c.time,'monotonic',return_value=209):
   c.observe_parent_clock(clock)
  guard=c.bind_freshness_to_parent_clock(clock,109,209)
  for i in range(1,10):guard.sample(209+i*.1-.01,109+i*.1,209+i*.1,8)
  guard.finalize(110,210)
  self.assertIs(guard.parent_clock,clock);self.assertEqual(clock.previous_wall,110)
  with patch.object(c.time,'time',return_value=109.98),patch.object(c.time,'monotonic',return_value=210.02),self.assertRaisesRegex(p.ProtocolError,'whole_clock_reversal'):
   c.observe_parent_clock(clock)
  self.assertIn('whole_clock_reversal',clock.failures)

 def test_controller_bind_does_not_replay_old_spawn_after_start_receipt_clock(self):
  clock=p.WholeClock(100,200);clock.check(109.02,209.02)
  guard=c.bind_freshness_to_parent_clock(clock,109,209)
  guard.tick(109.03,209.03)
  self.assertIs(guard.parent_clock,clock);self.assertEqual(clock.previous_wall,109.03);self.assertEqual(clock.failures,[])

class C18RSSV5FailedContainmentWiringTests(unittest.TestCase):
 def test_sticky_qualification_clock_does_not_block_liveowned_cleanup_and_failedreceipt(self):
  clock=p.WholeClock(100,200);clock.check(110,210)
  with self.assertRaises(p.ProtocolError):clock.check(109.98,210.02)
  timeline=[291.];actions=[];receipts=[];alive=[True]
  ident={'pid':123,'uid':501,'pgid':123,'session_ps':'s','lstart':'start'}
  class Proc:
   pid=123;returncode=None
   def wait(self,timeout):actions.append('join');self.returncode=-9;return -9
  proc=Proc()
  def observe(pid,timeout):actions.append('observe');return {'status':'observed','live_pids':[123] if alive[0] else []}
  def inspect(pid,timeout):actions.append('identity');return ident
  def send(pid,sig):
   self.assertIsNone(proc.returncode);actions.append(sig.name)
   if sig==c.signal.SIGKILL:alive[0]=False
  def pause(t):timeline[0]+=t
  rec=c.contain_owned_child(proc,ident,290.,bool(clock.failures),observer=observe,identity_query=inspect,now=lambda:timeline[0],send=send,pause=pause,child_signal_default=lambda:True,failed_receipt_writer=receipts.append)
  self.assertTrue(rec['cleanup_proved_gone']);self.assertEqual(rec['child_exit'],-9);self.assertEqual(rec['failure_only_extra_window_seconds'],5)
  self.assertIn('SIGTERM',actions);self.assertIn('SIGKILL',actions);self.assertIn('join',actions);self.assertEqual(actions.count('identity'),2);self.assertLess(actions.index('SIGKILL'),actions.index('join'));self.assertEqual(len(receipts),1);self.assertFalse(receipts[0]['qualification_admission']);self.assertTrue(clock.failures)
 def test_within_original_budget_no_extension_wrongUID_no_blindsignal_receipt_attempted(self):
  timeline=[289.];ident={'pid':123,'uid':501,'pgid':123,'session_ps':'s','lstart':'start'};signals=[];receipts=[]
  class Proc:pid=123;returncode=None
  rec=c.contain_owned_child(Proc(),ident,290.,True,observer=lambda *a:{'status':'observed','live_pids':[123]},identity_query=lambda *a:ident|{'uid':502},now=lambda:timeline[0],send=lambda *a:signals.append(a),pause=lambda t:None,child_signal_default=lambda:True,failed_receipt_writer=receipts.append)
  self.assertEqual(signals,[]);self.assertFalse(rec['cleanup_proved_gone']);self.assertEqual(rec['failure_only_extra_window_seconds'],0);self.assertEqual(rec['containment_cutoff_mono'],290);self.assertEqual(len(receipts),1)

 def test_failed_receipt_IO_exceeding5_is_unknown_never_success(self):
  timeline=[291.]
  class Proc:pid=123;returncode=1
  def slowwriter(rec):timeline[0]=296.1
  rec=c.contain_owned_child(Proc(),None,290.,True,observer=lambda *a:{'status':'observed','live_pids':[]},now=lambda:timeline[0],failed_receipt_writer=slowwriter)
  self.assertFalse(rec['qualification_admission']);self.assertFalse(rec['containment_within_cutoff_after_receipt_attempt']);self.assertTrue(rec['errors']);self.assertGreater(rec['containment_elapsed_seconds_including_receipt_attempt'],5)
