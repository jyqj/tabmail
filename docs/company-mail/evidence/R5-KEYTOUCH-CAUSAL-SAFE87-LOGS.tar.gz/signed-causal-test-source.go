package postgres_test

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"net/http"
	"net/http/httptest"
	"os"
	"sync"
	"sync/atomic"
	"testing"
	"time"

	"github.com/google/uuid"
	"github.com/jackc/pgx/v5"
	"github.com/jackc/pgx/v5/pgconn"
	"github.com/rs/zerolog"
	"tabmail/internal/api"
	"tabmail/internal/api/middleware"
	"tabmail/internal/authz"
	"tabmail/internal/config"
	"tabmail/internal/models"
	"tabmail/internal/outbound"
	"tabmail/internal/policy"
	"tabmail/internal/rawobject"
	"tabmail/internal/store"
	"tabmail/internal/store/postgres"
	"tabmail/internal/testutil"
)

const r5TouchSQL = `UPDATE tenant_api_keys SET last_used_at=now(), last_used_ip=$2 WHERE id=$1`
const r5TouchPermissionSQL = `UPDATE tenant_api_keys SET allowed_zone_ids=$2 WHERE id=$1`
const r5TouchIP = "192.0.2.41"

type r5TouchCall struct {
	id uuid.UUID
	ip string
}

// This is scheduling instrumentation, NOT a replacement auth/receipt oracle.
// Auth still launches its own goroutine; Touch delegates immediately, without
// changing its context, key, IP or error. The receipt seam waits for observable
// PostgreSQL state and then calls the actual PgStore method, unchanged.
// Consequently this can prove a possible causal interleaving, not identify the
// unknown holder in a historical 55P03 log or certify a production fix.
type r5TouchAdmissionStore struct {
	*postgres.PgStore
	started chan r5TouchCall
	done    chan struct{}
	result  error // published by closing done
	calls   atomic.Int32
	workers sync.WaitGroup
	key     uuid.UUID
	job     uuid.UUID
	before  func(context.Context) error
	once    sync.Once
	gateErr error
	reads   int // synchronous in-process router only
}

func (s *r5TouchAdmissionStore) TouchAPIKey(ctx context.Context, id uuid.UUID, ip string) error {
	s.workers.Add(1)
	defer s.workers.Done()
	first := s.calls.Add(1) == 1
	if first {
		s.started <- r5TouchCall{id: id, ip: ip}
	}
	err := s.PgStore.TouchAPIKey(ctx, id, ip)
	if first {
		s.result = err
		close(s.done)
	}
	return err
}

func (s *r5TouchAdmissionStore) GetOutboundReceipt(ctx context.Context, a authz.Actor, id uuid.UUID, scope string) (*store.OutboundReceipt, error) {
	s.reads++
	if a.Type != authz.PrincipalAPIKey || a.ID != s.key || id != s.job {
		return nil, errors.New("receipt did not use the same fixture key and job")
	}
	s.once.Do(func() { s.gateErr = s.before(ctx) })
	if s.gateErr != nil {
		return nil, s.gateErr
	}
	return s.PgStore.GetOutboundReceipt(ctx, a, id, scope)
}

// BEFORE STATEMENT runs before ExecModifyTable fetches the first candidate row:
// PostgreSQL REL_16_STABLE, src/backend/executor/nodeModifyTable.c,
// ExecModifyTable: fireBSTriggers(node), then ExecProcNode(subplanstate).
// https://github.com/postgres/postgres/blob/REL_16_STABLE/src/backend/executor/nodeModifyTable.c
// https://www.postgresql.org/docs/16/trigger-definition.html
// BEFORE ROW is deliberately NOT used: obtaining that row may already lock it.
// AFTER ROW holds the real metadata UPDATE's tuple lock until actual commit.
// Both gates preserve relation locks and all production FOR SHARE NOWAIT reads.
func r5TouchInstallGate(t *testing.T, f *companyFixture, key uuid.UUID, phase string) pgx.Tx {
	t.Helper()
	if phase != "before-statement" && phase != "after-row" {
		t.Fatal("unknown touch gate phase")
	}
	ctx := context.Background()
	var keyCount int
	must(t, f.pool.QueryRow(ctx, `SELECT count(*) FROM tenant_api_keys`).Scan(&keyCount))
	if keyCount != 1 {
		t.Fatal("statement gate requires exactly the one owned fixture key")
	}
	// No roles, SECURITY DEFINER, shared schemas, server setting or external DB.
	// A row trace becomes visible only when the actual Touch transaction commits.
	_, err := f.pool.Exec(ctx, fmt.Sprintf(`
CREATE TABLE r5_touch_trace(key_id uuid NOT NULL, holder_pid integer NOT NULL,
 phase text NOT NULL, authority_unchanged boolean NOT NULL,
 previous_at timestamptz, used_at timestamptz, used_ip inet);
CREATE FUNCTION r5_touch_gate() RETURNS trigger LANGUAGE plpgsql AS $gate$
BEGIN
 IF TG_LEVEL = 'STATEMENT' THEN
  IF '%s' = 'before-statement' THEN PERFORM pg_advisory_xact_lock(529014,1); END IF;
  RETURN NULL;
 END IF;
 IF NEW.id <> '%s'::uuid THEN RAISE EXCEPTION 'unexpected fixture key'; END IF;
 INSERT INTO r5_touch_trace VALUES(NEW.id,pg_backend_pid(),'%s',
  (to_jsonb(OLD)-'last_used_at'-'last_used_ip') = (to_jsonb(NEW)-'last_used_at'-'last_used_ip'),
  OLD.last_used_at,NEW.last_used_at,NEW.last_used_ip);
 IF '%s' = 'after-row' THEN PERFORM pg_advisory_xact_lock(529014,1); END IF;
 RETURN NEW;
END $gate$;
CREATE TRIGGER r5_touch_before BEFORE UPDATE OF last_used_at,last_used_ip ON tenant_api_keys
 FOR EACH STATEMENT EXECUTE FUNCTION r5_touch_gate();
CREATE TRIGGER r5_touch_after AFTER UPDATE OF last_used_at,last_used_ip ON tenant_api_keys
 FOR EACH ROW EXECUTE FUNCTION r5_touch_gate();`, phase, key, phase, phase))
	must(t, err)
	t.Cleanup(func() {
		ctx, cancel := context.WithTimeout(context.Background(), 3*time.Second)
		defer cancel()
		_, err := f.pool.Exec(ctx, `DROP TRIGGER r5_touch_before ON tenant_api_keys;
DROP TRIGGER r5_touch_after ON tenant_api_keys; DROP FUNCTION r5_touch_gate(); DROP TABLE r5_touch_trace`)
		if err != nil {
			t.Errorf("owned touch fixture teardown failed: %T", err)
		}
	})
	hold, err := f.pool.Begin(ctx)
	must(t, err)
	t.Cleanup(func() { r5TouchRollback(t, hold) })
	_, err = hold.Exec(ctx, `SELECT pg_advisory_xact_lock(529014,1)`)
	must(t, err)
	return hold
}

func r5TouchRollback(t *testing.T, tx pgx.Tx) {
	t.Helper()
	if tx == nil {
		return
	}
	ctx, cancel := context.WithTimeout(context.Background(), 3*time.Second)
	defer cancel()
	if err := tx.Rollback(ctx); err != nil && !errors.Is(err, pgx.ErrTxClosed) {
		t.Errorf("owned transaction rollback failed: %T", err)
	}
}

// Poll only an explicit lock/transaction predicate; elapsed time never stands
// in for reaching a phase. Parent context bounds all observer queries.
func r5TouchAwait(ctx context.Context, check func() (bool, error)) error {
	tick := time.NewTicker(time.Millisecond)
	defer tick.Stop()
	for {
		ok, err := check()
		if err != nil || ok {
			return err
		}
		select {
		case <-ctx.Done():
			return ctx.Err()
		case <-tick.C:
		}
	}
}

func r5TouchWaitGate(ctx context.Context, f *companyFixture, gatePID uint32) (int32, error) {
	var pid int32
	err := r5TouchAwait(ctx, func() (bool, error) {
		var query string
		err := f.pool.QueryRow(ctx, `SELECT a.pid,a.query FROM pg_stat_activity a
WHERE a.datname=current_database() AND a.wait_event_type='Lock' AND a.wait_event='advisory'
 AND pg_blocking_pids(a.pid)=ARRAY[$1::integer]
 AND EXISTS(SELECT 1 FROM pg_locks l WHERE l.pid=a.pid AND l.locktype='advisory'
  AND NOT l.granted AND l.classid=529014 AND l.objid=1 AND l.objsubid=2)`, gatePID).Scan(&pid, &query)
		if errors.Is(err, pgx.ErrNoRows) {
			return false, nil
		}
		if err != nil {
			return false, err
		}
		if query != r5TouchSQL {
			return false, errors.New("advisory waiter is not the real metadata UPDATE")
		}
		return true, nil
	})
	return pid, err
}

// The diagnostic SHARE waiter is not the production admission query. It proves
// the exact same-key blocker PID, then joins and releases its own tx
// BEFORE delegating to the untouched production FOR SHARE NOWAIT reader.
func r5TouchProveRowBlocker(ctx context.Context, t *testing.T, f *companyFixture, key uuid.UUID, holder int32, holderQuery string) error {
	t.Helper()
	probe, err := f.pool.Begin(ctx)
	if err != nil {
		return err
	}
	pid := probe.Conn().PgConn().PID()
	// The server ends this diagnostic statement itself. Do not close the
	// connection with client cancellation and race its asynchronous rollback.
	if _, err = probe.Exec(ctx, `SET LOCAL statement_timeout='1500ms'`); err != nil {
		r5TouchRollback(t, probe)
		return err
	}
	done := make(chan error, 1)
	go func() {
		_, err := probe.Exec(ctx, `SELECT id FROM tenant_api_keys WHERE id=$1 FOR SHARE`, key)
		done <- err
	}()
	// Always join before releasing this pool borrower, including failed proofs.
	defer func() {
		select {
		case err := <-done:
			var pgerr *pgconn.PgError
			if !errors.As(err, &pgerr) || pgerr.Code != "57014" {
				t.Errorf("same-key diagnostic waiter did not end by its statement timeout: %T", err)
			}
		case <-time.After(6 * time.Second):
			t.Error("diagnostic same-key waiter did not join")
		}
		r5TouchRollback(t, probe)
	}()
	err = r5TouchAwait(ctx, func() (bool, error) {
		var blocked bool
		err := f.pool.QueryRow(ctx, `SELECT EXISTS(SELECT 1 FROM pg_stat_activity a
JOIN pg_stat_activity h ON h.pid=$2 WHERE a.pid=$1 AND a.datname=current_database()
 AND a.wait_event_type='Lock' AND pg_blocking_pids(a.pid)=ARRAY[$2::integer]
 AND h.query=$3 AND h.xact_start IS NOT NULL)`, pid, holder, holderQuery).Scan(&blocked)
		return blocked, err
	})
	if err == nil {
		t.Logf("phase=same_key_SHARE_wait waiter_pid=%d exact_blocker_pid=%d holder_query=%s", pid, holder, holderQuery)
	}
	return err
}

func r5TouchRowFree(ctx context.Context, t *testing.T, f *companyFixture, key uuid.UUID) error {
	t.Helper()
	probe, err := f.pool.Begin(ctx)
	if err != nil {
		return err
	}
	defer r5TouchRollback(t, probe)
	var got uuid.UUID
	err = probe.QueryRow(ctx, `SELECT id FROM tenant_api_keys WHERE id=$1 FOR SHARE NOWAIT`, key).Scan(&got)
	if err == nil && got != key {
		return errors.New("row-free probe selected another key")
	}
	return err
}

func r5TouchRouter(f *companyFixture, st *r5TouchAdmissionStore, svc *outbound.Service, obj *testutil.MemoryObjectStore) http.Handler {
	return api.NewRouter(api.RouterConfig{Store: st, CompanyRepository: f.st,
		ObjectStore: obj, RawObjects: rawobject.NewStore(obj, f.st),
		JWTSecret: companyTestJWT, MailboxTokenSecret: "test-only-mailbox-secret",
		PublicTenantID: "00000000-0000-0000-0000-000000000001", NamingMode: policy.NamingFull,
		CompanyOnly: true, RateLimiter: middleware.NewRateLimiter(nil, st, 10000, nil),
		OutboundService: svc, Logger: zerolog.Nop(), Readiness: f.st.Readiness})
}

func r5TouchHTTP(ctx context.Context, h http.Handler, key, method, path string) *httptest.ResponseRecorder {
	req := httptest.NewRequest(method, path, nil).WithContext(ctx)
	req.RemoteAddr = r5TouchIP + ":41001"
	req.Header.Set("X-API-Key", key)
	w := httptest.NewRecorder()
	h.ServeHTTP(w, req)
	return w
}

func r5TouchCommitted(t *testing.T, ctx context.Context, f *companyFixture, st *r5TouchAdmissionStore, key uuid.UUID, pid int32, phase string, since time.Time) {
	t.Helper()
	select {
	case <-st.done:
	case <-ctx.Done():
		t.Fatal("real asynchronous metadata UPDATE did not finish")
	}
	if st.result != nil {
		t.Fatalf("real asynchronous metadata UPDATE failed: %T", st.result)
	}
	var valid bool
	must(t, f.pool.QueryRow(ctx, `SELECT count(*)=1 AND bool_and(
 tr.key_id=$1 AND tr.holder_pid=$2 AND tr.phase=$3 AND tr.authority_unchanged
 AND tr.previous_at IS NULL AND tr.used_at >= $4 AND tr.used_at <= clock_timestamp()
 AND host(tr.used_ip)=$5 AND k.last_used_at=tr.used_at AND k.last_used_ip=tr.used_ip)
 FROM r5_touch_trace tr JOIN tenant_api_keys k ON k.id=tr.key_id`, key, pid, phase, since, r5TouchIP).Scan(&valid))
	if !valid || st.calls.Load() != 1 {
		t.Fatal("same-key telemetry did not commit exactly once with real timestamp/IP and unchanged authority")
	}
	must(t, r5TouchRowFree(ctx, t, f, key))
	t.Logf("phase=telemetry_committed holder_pid=%d trigger_phase=%s calls=1 last_used_at_and_ip_verified=true", pid, phase)
}

// Default (untagged) integration test: four serial, separately owned databases.
// Missing private fixture input is a failure, never a skip. There is no worker,
// SMTP server, redis server, HTTP listener, real mail, credential file or signal.
// This is additional default-package work; it does not repair/replace the old
// whole-suite result or justify silently widening/splitting its 180 s budget.
func TestR5KeyTouchReceiptAdmissionCausality(t *testing.T) {
	if os.Getenv("TABMAIL_TEST_DB_DSN") == "" {
		t.Fatal("key-touch causality requires an explicit owned TABMAIL_TEST_DB_DSN")
	}
	for _, scenario := range []string{"telemetry_held_conflicts", "telemetry_committed_then_zone_revoked", "permission_change_held_conflicts", "unrevoked_retry_and_telemetry_commit"} {
		t.Run(scenario, func(t *testing.T) {
			f := seedCompany(t) // fresh DB, never the supplied DSN's existing DB
			ctx, cancel := context.WithTimeout(context.Background(), 12*time.Second)
			defer cancel()
			key, _ := r5LegacyKey(t, f)
			otherZone := &models.DomainZone{TenantID: f.tenant.ID, Domain: "other-touch.test", IsVerified: true, MXVerified: true}
			must(t, f.st.CreateZone(ctx, otherZone))
			_, err := f.pool.Exec(ctx, `UPDATE tenant_api_keys SET scopes='["send:read","send:write"]'::jsonb WHERE id=$1`, key.ID)
			must(t, err)
			key.Scopes = []string{"send:read", "send:write"}
			obj := testutil.NewMemoryObjectStore()
			svc := outbound.NewService(config.Outbound{Enabled: true, Mode: "relay", RelayHost: "127.0.0.1", RelayPort: 1}, f.st, f.st, zerolog.Nop())
			svc.SetObjectStore(obj)
			job := r5StageQueued(t, f, svc, f.personal, key, "synthetic@touch.test")
			_, err = f.pool.Exec(ctx, `UPDATE outbound_jobs SET state='dead' WHERE id=$1`, job.ID)
			must(t, err)
			phase := "before-statement"
			if scenario == "telemetry_held_conflicts" {
				phase = "after-row"
			}
			gate := r5TouchInstallGate(t, f, key.ID, phase)
			st := &r5TouchAdmissionStore{PgStore: f.st, started: make(chan r5TouchCall, 1), done: make(chan struct{}), key: key.ID, job: job.ID}
			var permission pgx.Tx
			requested, joined := false, false
			// Later cleanup precedes trigger drops and testpg's synchronous pool
			// close/drop. Release both owners before joining auth's detached work.
			t.Cleanup(func() {
				r5TouchRollback(t, permission)
				r5TouchRollback(t, gate)
				if requested && !joined {
					select {
					case <-st.done:
						if st.result != nil {
							t.Errorf("cleanup joined failed telemetry UPDATE: %T", st.result)
						}
					case <-time.After(6 * time.Second):
						t.Error("auth telemetry not launched or not joined before owned fixture teardown")
					}
				}
				// The observed first launch is joined above. Subsequent launches
				// are forbidden by the real throttle within this 12 s case; still
				// join all wrapper-entered work if that invariant regresses.
				st.workers.Wait()
			})
			var permissionPID uint32
			if scenario == "permission_change_held_conflicts" {
				permission, err = f.pool.Begin(ctx)
				must(t, err)
				permissionPID = permission.Conn().PgConn().PID()
				_, err = permission.Exec(ctx, r5TouchPermissionSQL, key.ID, []uuid.UUID{otherZone.ID})
				must(t, err)
			}
			var telemetryPID int32
			st.before = func(ctx context.Context) error {
				select {
				case call := <-st.started:
					if call.id != key.ID || call.ip != r5TouchIP {
						return errors.New("auth launched telemetry for another key or IP")
					}
				case <-ctx.Done():
					return errors.New("auth did not launch real telemetry")
				}
				var err error
				telemetryPID, err = r5TouchWaitGate(ctx, f, gate.Conn().PgConn().PID())
				if err != nil {
					return err
				}
				t.Logf("phase=%s telemetry_pid=%d advisory_blocker_pid=%d query=%s", phase, telemetryPID, gate.Conn().PgConn().PID(), r5TouchSQL)
				if phase == "after-row" {
					return r5TouchProveRowBlocker(ctx, t, f, key.ID, telemetryPID, r5TouchSQL)
				}
				if permission != nil {
					return r5TouchProveRowBlocker(ctx, t, f, key.ID, int32(permissionPID), r5TouchPermissionSQL)
				}
				// Positive counterfactual: UPDATE truly reached the statement gate,
				// but the same-key SHARE NOWAIT probe can still take the row lock.
				return r5TouchRowFree(ctx, t, f, key.ID)
			}
			h := r5TouchRouter(f, st, svc, obj)
			path := "/api/v1/outbound/" + job.ID.String()
			rawKey := "tm_content_" + key.ID.String()
			before := r5StageOwnerlessRetryState(t, f, job.ID)
			var since time.Time
			must(t, f.pool.QueryRow(ctx, `SELECT clock_timestamp()`).Scan(&since))
			method, requestPath, want := "POST", path+"/retry", http.StatusConflict
			if scenario == "telemetry_committed_then_zone_revoked" {
				method, requestPath, want = "GET", path, http.StatusOK
			} else if scenario == "unrevoked_retry_and_telemetry_commit" {
				want = http.StatusOK
			}
			requested = true
			w := r5TouchHTTP(ctx, h, rawKey, method, requestPath)
			if st.gateErr != nil {
				t.Fatalf("causal gate evidence failed: %T", st.gateErr)
			}
			if st.reads == 0 || w.Code != want {
				t.Fatalf("real receipt admission HTTP=%d want=%d reads=%d (response redacted)", w.Code, want, st.reads)
			}
			if want == http.StatusConflict {
				var envelope struct {
					Error struct{ Code, Message string }
				}
				must(t, json.Unmarshal(w.Body.Bytes(), &envelope))
				if envelope.Error.Code != "CONFLICT" || envelope.Error.Message != "key is changing; reload before retrying" {
					t.Fatal("409 was not the current key receipt-admission conflict")
				}
			}
			if scenario != "unrevoked_retry_and_telemetry_commit" && before != r5StageOwnerlessRetryState(t, f, job.ID) {
				t.Fatal("receipt-only or denied retry changed job/recipients/attempts/audit/outbox")
			}
			r5TouchRollback(t, permission)
			r5TouchRollback(t, gate)
			r5TouchCommitted(t, ctx, f, st, key.ID, telemetryPID, phase, since)
			joined = true
			if scenario != "unrevoked_retry_and_telemetry_commit" && before != r5StageOwnerlessRetryState(t, f, job.ID) {
				t.Fatal("denied/read-only state changed after real telemetry commit")
			}
			if scenario == "telemetry_committed_then_zone_revoked" {
				_, err = f.pool.Exec(ctx, r5TouchPermissionSQL, key.ID, []uuid.UUID{otherZone.ID})
				must(t, err) // autocommit returned before the new request
				before = r5StageOwnerlessRetryState(t, f, job.ID)
				w = r5TouchHTTP(ctx, h, rawKey, "POST", path+"/retry")
				// No sleeps/reset of auth's real one-minute touch throttle. Its first
				// update has committed, and the second request remains within 12 s.
				if w.Code != http.StatusNotFound || st.reads != 2 || st.calls.Load() != 1 {
					t.Fatalf("stable zone revocation HTTP=%d want=404 receipt_reads=%d touch_calls=%d", w.Code, st.reads, st.calls.Load())
				}
				if before != r5StageOwnerlessRetryState(t, f, job.ID) {
					t.Fatal("stable denied retry changed job/recipients/attempts/audit/outbox")
				}
			} else if scenario == "unrevoked_retry_and_telemetry_commit" {
				current, err := f.st.GetOutboundJob(ctx, job.ID)
				must(t, err)
				var retries int
				must(t, f.pool.QueryRow(ctx, `SELECT count(*) FROM audit_log WHERE resource_id=$1 AND action='outbound.retry'`, job.ID).Scan(&retries))
				var events int
				must(t, f.pool.QueryRow(ctx, `SELECT count(*) FROM outbox_events WHERE payload->'metadata'->>'resource_id'=$1 AND payload->'metadata'->>'action'='outbound.retry'`, job.ID.String()).Scan(&events))
				if current == nil || current.State != models.OutboundPending || retries != 1 || events != 1 || st.reads < 2 {
					t.Fatal("positive router retry did not really commit exactly once")
				}
			}
		})
	}
}
