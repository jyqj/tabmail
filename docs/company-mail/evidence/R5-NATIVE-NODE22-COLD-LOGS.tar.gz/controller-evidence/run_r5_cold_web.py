#!/usr/bin/env python3
"""Private, bounded cold Next build; never a shipping-image/browser acceptance.

Preparation is the default and runs no Node process. --dirty-file explicitly
reviews every changed/untracked admissible web path (including deletions). The
runner copies HEAD via git archive, never the workspace .next/node_modules.
Execution requires the runtime owner's separately reserved window label:

  python3 -B scripts/run_r5_cold_web.py --output-dir /tmp/new-cold-web \
    --dirty-file web/path.tsx ...
  # Use a NEW output directory for execution; do not reuse prepared evidence.
  python3 -B scripts/run_r5_cold_web.py --output-dir /tmp/new-cold-web-run \
    --dirty-file web/path.tsx ... --execute --runtime-window OWNER-LABEL \
    --node-bin /absolute/trusted/node22/bin --expected-source-identity PREPARED_SHA256

The label records scheduling, not an OS lock or proof that another owner is idle.
Dependencies/install scripts run as the current user, with a private HOME/cache
and allowlisted environment; this is source isolation, not a container sandbox.
"""
import argparse
import hashlib
import io
import json
import os
from pathlib import Path, PurePosixPath
import signal
import stat
import subprocess
import tarfile
import tempfile
import time
from datetime import datetime, timezone

MAX_FILE_BYTES = 32 * 1024 * 1024
MAX_SOURCE_BYTES = 128 * 1024 * 1024
MAX_LOG_BYTES = 16 * 1024 * 1024
DENIED_PARTS = {'.git', '.next', 'node_modules', '.npmrc', '.yarnrc', '.yarnrc.yml',
                '.ssh', '.aws', '.gnupg', '.netrc', '.npm', '.cache', 'credentials', 'secrets',
                'id_rsa', 'id_ed25519'}


class GateError(ValueError):
    pass


def utc_now():
    return datetime.now(timezone.utc).isoformat()


def sha256(data):
    return hashlib.sha256(data).hexdigest()


def admissible(path):
    """Only web regular source; never configs/caches bearing host secrets."""
    p = PurePosixPath(path)
    if not path or p.is_absolute() or '..' in p.parts or str(p) != path:
        raise GateError('non-canonical relative path: ' + path)
    if not p.parts or p.parts[0] != 'web':
        raise GateError('outside web write/snapshot scope: ' + path)
    for part in p.parts:
        lower = part.lower()
        if (lower in DENIED_PARTS or lower.startswith(('.env', 'credentials.', 'secrets.')) or
                lower.endswith(('.pem', '.key', '.p12', '.pfx', '.tsbuildinfo'))):
            return False
    return True


def git(repo, *args):
    return subprocess.check_output(['git', '-C', str(repo), *args], timeout=30)


def dirty_paths(repo):
    changed = git(repo, 'diff', '--name-only', '-z', 'HEAD', '--', 'web')
    untracked = git(repo, 'ls-files', '--others', '--exclude-standard', '-z', '--', 'web')
    return sorted(set(os.fsdecode(p) for p in (changed + untracked).split(b'\0') if p))


def write_json(path, value):
    data = (json.dumps(value, indent=2, sort_keys=True) + '\n').encode()
    fd = os.open(str(path), os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    with os.fdopen(fd, 'wb') as stream:
        stream.write(data)


def private_output(output, repo):
    output = Path(output)
    if not output.is_absolute():
        raise GateError('output directory must be absolute')
    parent = output.parent.resolve(strict=True)
    allowed_roots = {Path(tempfile.gettempdir()).resolve(), Path('/tmp').resolve()}
    if not any(parent == root or root in parent.parents for root in allowed_roots):
        raise GateError('output directory must be under temporary storage')
    target = parent / output.name
    repo = repo.resolve()
    if target == repo or repo in target.parents:
        raise GateError('output directory must not be in the checkout')
    target.mkdir(mode=0o700)  # Existing evidence is never overwritten.
    return target


def regular_bytes(path, root):
    """Refuse symlink ancestors as well as links/devices at the leaf."""
    relative = path.relative_to(root)
    current = root
    for part in relative.parts:
        current = current / part
        if current.is_symlink():
            raise GateError('symlink source refused: ' + str(relative))
    flags = os.O_RDONLY | getattr(os, 'O_NOFOLLOW', 0)
    fd = os.open(str(path), flags)
    with os.fdopen(fd, 'rb') as stream:
        before = os.fstat(stream.fileno())
        if not stat.S_ISREG(before.st_mode) or before.st_size > MAX_FILE_BYTES:
            raise GateError('nonregular/oversized source: ' + str(relative))
        data = stream.read(MAX_FILE_BYTES + 1)
        after = os.fstat(stream.fileno())
    if (len(data) > MAX_FILE_BYTES or before.st_size != len(data) or
            (before.st_mtime_ns, before.st_size) != (after.st_mtime_ns, after.st_size)):
        raise GateError('source changed while reading: ' + str(relative))
    return data, 0o700 if before.st_mode & 0o111 else 0o600


def put_file(root, relative, data, mode):
    target = root / relative
    target.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    fd = os.open(str(target), os.O_WRONLY | os.O_CREAT | os.O_TRUNC,
                 mode)
    with os.fdopen(fd, 'wb') as stream:
        stream.write(data)
    target.chmod(mode)


def prepare_snapshot(repo, output, reviewed_dirty):
    repo = repo.resolve()
    head = git(repo, 'rev-parse', 'HEAD').decode().strip()
    current_dirty = dirty_paths(repo)
    allowed_dirty = {p for p in current_dirty if admissible(p)}
    if 'web/package-lock.json' in allowed_dirty:
        raise GateError('original tracked lockfile required; dirty lockfile refused')
    reviewed = set(reviewed_dirty)
    if len(reviewed) != len(reviewed_dirty):
        raise GateError('duplicate dirty-file review')
    for path in reviewed:
        if not admissible(path):
            raise GateError('forbidden dirty-file review: ' + path)
    if reviewed != allowed_dirty:
        raise GateError('explicit dirty review mismatch: ' + json.dumps({
            'missing': sorted(allowed_dirty - reviewed),
            'unexpected': sorted(reviewed - allowed_dirty)}))
    archive = git(repo, 'archive', '--format=tar', head, '--', 'web')
    if len(archive) > MAX_SOURCE_BYTES:
        raise GateError('tracked archive exceeds source byte budget')
    source = output / 'source'
    source.mkdir(mode=0o700)
    excluded, count, total = [], 0, 0
    # No extractall: refuse links/devices/path traversal before creating files.
    with tarfile.open(fileobj=io.BytesIO(archive), mode='r:') as tar:
        for member in tar:
            name = member.name.rstrip('/')
            if not admissible(name):
                excluded.append(name)
                continue
            if member.isdir():
                (source / name).mkdir(parents=True, exist_ok=True, mode=0o700)
                continue
            if not member.isfile() or member.size > MAX_FILE_BYTES:
                raise GateError('unsafe archive member: ' + name)
            data = tar.extractfile(member).read(MAX_FILE_BYTES + 1)
            total += len(data)
            if total > MAX_SOURCE_BYTES or len(data) != member.size:
                raise GateError('archive source byte budget/integrity failure')
            put_file(source, name, data, 0o700 if member.mode & 0o111 else 0o600)
            count += 1
    delta = []
    for path in sorted(reviewed):
        origin, target = repo / path, source / path
        if origin.exists() or origin.is_symlink():
            data, mode = regular_bytes(origin, repo)
            total += len(data)
            if total > MAX_SOURCE_BYTES:
                raise GateError('dirty source exceeds byte budget')
            put_file(source, path, data, mode)
            delta.append({'path': path, 'action': 'overlay', 'sha256': sha256(data),
                          'bytes': len(data), 'mode': oct(mode)})
        else:
            if not target.is_file():
                raise GateError('deleted dirty source absent from tracked snapshot: ' + path)
            target.unlink()
            delta.append({'path': path, 'action': 'delete'})
    # Only the reviewed delta is reread, not a per-file full-tree hash sweep.
    for entry in delta:
        origin = repo / entry['path']
        if entry['action'] == 'delete':
            if origin.exists() or origin.is_symlink():
                raise GateError('deleted source reappeared: ' + entry['path'])
        else:
            data, mode = regular_bytes(origin, repo)
            if sha256(data) != entry['sha256'] or oct(mode) != entry['mode']:
                raise GateError('dirty source changed during capture: ' + entry['path'])
    if git(repo, 'rev-parse', 'HEAD').decode().strip() != head or dirty_paths(repo) != current_dirty:
        raise GateError('HEAD/dirty inventory changed during capture')
    web = source / 'web'
    for required in ('package.json', 'package-lock.json', 'Dockerfile'):
        if not (web / required).is_file():
            raise GateError('required tracked build input missing: web/' + required)
    package = json.loads((web / 'package.json').read_text())
    if package.get('scripts', {}).get('build') != 'next build':
        raise GateError('real next build script required; wrapper/bypass refused')
    if (web / 'node_modules').exists() or (web / '.next').exists():
        raise GateError('non-cold snapshot')
    identity = {'head': head, 'tracked_web_archive_sha256': sha256(archive), 'dirty_delta': delta,
                'excluded_tracked_paths': sorted(excluded),
                'excluded_dirty_paths': sorted(set(current_dirty) - allowed_dirty)}
    receipt = {**identity, 'source_identity_sha256': sha256(json.dumps(identity, sort_keys=True).encode()),
               'source_root': str(source), 'captured_at': utc_now(),
               'tracked_regular_file_count': count, 'capture_bytes_upper_bound': total,
               'package_json_sha256': sha256((web / 'package.json').read_bytes()),
               'lockfile_sha256': sha256((web / 'package-lock.json').read_bytes()),
               'dockerfile_sha256': sha256((web / 'Dockerfile').read_bytes()),
               'cold_before_install': True,
               'scope': 'tracked web HEAD plus exact explicitly reviewed working-tree delta'}
    write_json(output / 'source-receipt.json', receipt)
    return receipt


def build_environment(output, node_bin):
    node_bin = Path(node_bin).resolve(strict=True)
    if not node_bin.is_dir() or not (node_bin / 'node').is_file() or not (node_bin / 'npm').is_file():
        raise GateError('node-bin must contain trusted node and npm executables')
    for name in ('home', 'npm-cache', 'tmp'):
        (output / name).mkdir(mode=0o700)
    userconfig = output / 'empty-npmrc'
    userconfig.touch(mode=0o600)
    globalconfig = output / 'empty-global-npmrc'
    globalconfig.touch(mode=0o600)
    return {'PATH': str(node_bin) + ':/usr/bin:/bin', 'HOME': str(output / 'home'),
            'TMPDIR': str(output / 'tmp'), 'CI': '1', 'LC_ALL': 'C', 'TZ': 'UTC',
            'NEXT_TELEMETRY_DISABLED': '1', 'INTERNAL_API_URL': 'http://tabmail:8080',
            'npm_config_cache': str(output / 'npm-cache'),
            'npm_config_userconfig': str(userconfig), 'npm_config_globalconfig': str(globalconfig),
            'npm_config_audit': 'false', 'npm_config_fund': 'false',
            'npm_config_registry': 'https://registry.npmjs.org/'}


def observe_group(pgid):
    """Record only owned-group PID/PGID/state; never unrelated command lines."""
    try:
        probe = subprocess.run(['/bin/ps', '-axo', 'pid=,pgid=,stat='],
                               stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
                               env={'PATH': '/usr/bin:/bin', 'LC_ALL': 'C'}, timeout=2, check=True)
        members = []
        for line in probe.stdout.decode('ascii', errors='replace').splitlines():
            fields = line.split()
            if len(fields) != 3 or int(fields[1]) != pgid:
                continue
            pid = int(fields[0])
            try:
                sid = os.getsid(pid)
            except ProcessLookupError:
                continue
            members.append({'pid': pid, 'pgid': pgid, 'sid': sid, 'state': fields[2]})
        try:
            os.killpg(pgid, 0)
            exists = True
        except ProcessLookupError:
            exists = False
        return {'observed_at': utc_now(), 'pgid': pgid, 'group_absent': not exists,
                'members': members, 'live_pids': [m['pid'] for m in members if not m['state'].startswith('Z')],
                'ownership_confirmed': all(m['sid'] == pgid for m in members),
                'unknown': exists and not members}
    except (OSError, ValueError, subprocess.SubprocessError) as exc:
        return {'observed_at': utc_now(), 'pgid': pgid, 'group_absent': False,
                'members': [], 'live_pids': [], 'ownership_confirmed': False,
                'unknown': True, 'error': str(exc)}


def cleanup_group(process, budget=5):
    """Terminate only the recorded child session, even if its leader exited."""
    pgid = process.pid  # start_new_session binds PID == PGID == SID.
    end = time.monotonic() + max(0, budget)
    observations, signals = [], []
    sent_term, sent_kill = False, False
    while True:
        process.poll()  # Reap our leader before testing group absence.
        observed = observe_group(pgid)
        observations.append(observed)
        if observed['unknown'] or not observed['ownership_confirmed']:
            break  # Ownership uncertainty is a failed cleanup, never a broad kill.
        if not observed['live_pids']:
            break  # A zombie cannot consume CPU; retain explicit non-absence state.
        remaining = end - time.monotonic()
        sig = None
        if not sent_term:
            sig, sent_term = signal.SIGTERM, True
        elif not sent_kill and remaining <= min(2, budget / 2):
            sig, sent_kill = signal.SIGKILL, True
        if sig is not None:
            try:
                os.killpg(pgid, sig)
                signals.append({'signal': int(sig), 'at': utc_now(), 'pgid': pgid})
            except ProcessLookupError:
                pass
        if remaining <= 0:
            break
        time.sleep(min(0.05, remaining))
    process.poll()
    final = observe_group(pgid)
    observations.append(final)
    return {'pgid': pgid, 'sid': pgid, 'signals': signals, 'observations': observations,
            'final': final, 'verified_no_live_group': not final['unknown'] and
            final['ownership_confirmed'] and not final['live_pids'] and process.returncode is not None}


def run_command(output, stage, argv, cwd, env, timeout, cleanup_budget=5):
    """Bound lifetime/log bytes; persist exact command, owned group and red logs."""
    record = {'stage': stage, 'argv': argv, 'cwd': str(cwd), 'env_allowlist': dict(env),
              'timeout_seconds': timeout, 'started_at': utc_now(), 'ended_at': None,
              'exit_code': None, 'timed_out': False, 'log_limit_exceeded': False,
              'pid': None, 'pgid': None, 'sid': None, 'cleanup_verified': False}
    receipt_path = output / (stage + '.json')
    write_json(receipt_path, record)
    started = time.monotonic()
    paths = [output / (stage + suffix) for suffix in ('.stdout', '.stderr')]
    with paths[0].open('xb') as stdout, paths[1].open('xb') as stderr:
        for path in paths:
            path.chmod(0o600)
        process = None
        try:
            process = subprocess.Popen(argv, cwd=str(cwd), env=env,
                                       stdout=stdout, stderr=stderr, start_new_session=True)
            record.update(pid=process.pid, pgid=process.pid, sid=process.pid)
            write_json(receipt_path, record)  # Interrupted parent still leaves group identity.
            while process.poll() is None:
                if any(p.stat().st_size > MAX_LOG_BYTES for p in paths):
                    record['log_limit_exceeded'] = True
                    break
                remaining = timeout - (time.monotonic() - started)
                if remaining <= 0:
                    record['timed_out'] = True
                    break
                time.sleep(min(0.1, remaining))
        except BaseException as exc:
            record['error'] = type(exc).__name__ + ': ' + str(exc)
            raise
        finally:
            if process is not None:
                cleanup = cleanup_group(process, cleanup_budget)
                record['group_cleanup'] = cleanup
                record['cleanup_verified'] = cleanup['verified_no_live_group']
                record['exit_code'] = process.returncode
            record['ended_at'] = utc_now()
            record['elapsed_seconds'] = round(time.monotonic() - started, 3)
            stdout.flush()
            stderr.flush()
            for label, path in zip(('stdout', 'stderr'), paths):
                record[label + '_bytes'] = path.stat().st_size
                record[label + '_sha256'] = sha256(path.read_bytes())
            record['log_limit_exceeded'] |= any(p.stat().st_size > MAX_LOG_BYTES for p in paths)
            write_json(receipt_path, record)
    return record


def command_passed(record):
    return (record['exit_code'] == 0 and not record['timed_out'] and
            not record['log_limit_exceeded'] and record.get('cleanup_verified', False) and
            'error' not in record)


def execute_build(output, source, node_bin, window, timeout, total_timeout=600):
    started = time.monotonic()
    deadline = started + total_timeout
    cleanup_reserve = min(5, total_timeout / 10)
    env = build_environment(output, node_bin)
    web = Path(source['source_root']) / 'web'
    result = {'status': 'running', 'runtime_window': window, 'commands': [],
              'total_timeout_seconds': total_timeout, 'cleanup_reserve_seconds': cleanup_reserve,
              'budget_exhausted': False,
              'shipping_image_passed': False, 'browser_passed': False, 'G0_passed': False,
              'isolation': 'private native source/HOME/cache, not a container sandbox',
              'platform': os.uname().sysname + '/' + os.uname().machine,
              'source_identity_sha256': source['source_identity_sha256'],
              'started_at': utc_now(), 'ended_at': None}
    def stage_command(stage, argv, ceiling):
        remaining = deadline - time.monotonic() - cleanup_reserve
        if remaining <= 0:
            result['budget_exhausted'] = True
            raise GateError('total cold-build deadline exhausted before ' + stage)
        try:
            return run_command(output, stage, argv, web, env, min(ceiling, remaining), cleanup_reserve)
        finally:
            persisted = output / (stage + '.json')
            if persisted.is_file():
                result['commands'].append(json.loads(persisted.read_text()))

    try:
        for stage, argv in (('node-version', ['node', '--version']),
                            ('npm-version', ['npm', '--version'])):
            command = stage_command(stage, argv, 15)
            if not command_passed(command):
                raise GateError('tool version command failed: ' + stage)
        node_version = (output / 'node-version.stdout').read_text().strip()
        result['node_version'] = node_version
        result['npm_version'] = (output / 'npm-version.stdout').read_text().strip()
        if not node_version.startswith('v22.'):
            raise GateError('Node 22 required by shipping Dockerfile/CI')
        for stage, argv in (('npm-ci', ['npm', 'ci']), ('npm-build', ['npm', 'run', 'build'])):
            if stage == 'npm-build' and (web / '.next').exists():
                raise GateError('install produced .next: refuse non-cold build')
            command = stage_command(stage, argv, timeout)
            if not command_passed(command):
                result['status'] = stage + '_failed'
                break
        else:
            artifacts = {name: (web / name).is_file() for name in
                         ('.next/BUILD_ID', '.next/standalone/server.js')}
            artifacts['.next/static'] = (web / '.next/static').is_dir()
            result['artifact_presence'] = artifacts
            result['status'] = 'cold_next_build_passed' if all(artifacts.values()) else 'build_artifacts_missing'
        result['lockfile_unchanged'] = sha256((web / 'package-lock.json').read_bytes()) == source['lockfile_sha256']
        result['package_json_unchanged'] = sha256((web / 'package.json').read_bytes()) == source['package_json_sha256']
        if not result['lockfile_unchanged'] or not result['package_json_unchanged']:
            result['status'] = 'dependency_input_mutated'
    except BaseException as exc:
        result['status'] = 'execution_error'
        result['error'] = type(exc).__name__ + ': ' + str(exc)
        raise
    finally:
        result['ended_at'] = utc_now()
        result['elapsed_seconds'] = round(time.monotonic() - started, 3)
        result['total_deadline_exceeded'] = time.monotonic() > deadline
        result['all_owned_groups_no_live'] = bool(result['commands']) and all(
            c.get('cleanup_verified', False) for c in result['commands'])
        if result['total_deadline_exceeded'] or not result['all_owned_groups_no_live']:
            if result['status'] == 'cold_next_build_passed':
                result['status'] = 'deadline_or_cleanup_failed'
        write_json(output / 'cold-build-receipt.json', result)
    return result


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument('--repo', type=Path, default=Path(__file__).resolve().parents[1])
    parser.add_argument('--output-dir', type=Path, required=True)
    parser.add_argument('--dirty-file', action='append', default=[])
    parser.add_argument('--execute', action='store_true')
    parser.add_argument('--runtime-window')
    parser.add_argument('--node-bin', type=Path)
    parser.add_argument('--expected-source-identity')
    parser.add_argument('--timeout-seconds', type=int, default=300)
    parser.add_argument('--total-timeout-seconds', type=int, default=600)
    args = parser.parse_args(argv)
    if args.execute and (not args.runtime_window or not args.node_bin or not args.expected_source_identity):
        parser.error('--execute requires runtime-owner window, trusted --node-bin and --expected-source-identity')
    if not 1 <= args.total_timeout_seconds <= 600:
        parser.error('total timeout must be 1..600 seconds, including cleanup reserve')
    if not 1 <= args.timeout_seconds <= 600:
        parser.error('per-stage timeout must be 1..600 seconds')
    output = None
    try:
        output = private_output(args.output_dir, args.repo)
        source = prepare_snapshot(args.repo, output, args.dirty_file)
        if not args.execute:
            write_json(output / 'cold-build-receipt.json', {
                'status': 'prepared_not_executed', 'cold_next_build_passed': False,
                'source_identity_sha256': source['source_identity_sha256'],
                'shipping_image_passed': False, 'browser_passed': False, 'G0_passed': False})
            print(json.dumps({'status': 'prepared_not_executed', 'evidence': str(output)}))
            return 0
        if source['source_identity_sha256'] != args.expected_source_identity:
            raise GateError('prepared source identity drift; build refused before npm')
        result = execute_build(output, source, args.node_bin, args.runtime_window, args.timeout_seconds, args.total_timeout_seconds)
        print(json.dumps({'status': result['status'], 'evidence': str(output)}))
        return 0 if result['status'] == 'cold_next_build_passed' else 1
    except (GateError, OSError, subprocess.SubprocessError) as exc:
        if output is not None:
            write_json(output / 'error.json', {'error': str(exc), 'at': utc_now(), 'passed': False})
        print(json.dumps({'status': 'failed', 'error': str(exc), 'evidence': str(output)}))
        return 1


if __name__ == '__main__':
    raise SystemExit(main())
