"""Archive exact existing evidence bytes and verify every saved member."""
from __future__ import annotations

import argparse
import gzip
import hashlib
import io
import json
from pathlib import Path
import tarfile


def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument('--source', required=True, type=Path)
    parser.add_argument('--output', required=True, type=Path)
    args = parser.parse_args()
    source, output = args.source.resolve(), args.output.resolve()
    if source == output or source in output.parents:
        raise SystemExit('archive output must be outside its source')
    files = sorted(source.rglob('*'), key=lambda path: path.relative_to(source).as_posix())
    if any(path.is_symlink() for path in files):
        raise SystemExit('evidence symlinks are not accepted')
    regular = [path for path in files if path.is_file()]
    entries = []
    for path in regular:
        before = path.stat()
        data = path.read_bytes()
        after = path.stat()
        if (before.st_ino, before.st_size, before.st_mtime_ns) != (after.st_ino, after.st_size, after.st_mtime_ns):
            raise SystemExit('source changed during capture: ' + str(path))
        entries.append({'path': path.relative_to(source).as_posix(), 'bytes': len(data), 'sha256': digest(data)})
    manifest = {'schema': 'next1010-existing-evidence-archive-v1', 'file_count': len(entries),
                'total_uncompressed_bytes': sum(e['bytes'] for e in entries), 'files': entries,
                'qualification': 'Only actually present recovered or newly executed evidence is archived. Lost pre-reset native-only files and the old native bundle are not reconstructed.'}
    manifest_bytes = (json.dumps(manifest, indent=2, ensure_ascii=False) + '\n').encode()
    output.mkdir(parents=True, exist_ok=True)
    archive = output / 'r5-next1010-evidence.tar.gz'
    with archive.open('wb') as raw:
        with gzip.GzipFile(filename='', mode='wb', fileobj=raw, mtime=0) as compressed:
            with tarfile.open(fileobj=compressed, mode='w|', format=tarfile.PAX_FORMAT) as tar:
                for entry in entries:
                    data = (source / entry['path']).read_bytes()
                    if len(data) != entry['bytes'] or digest(data) != entry['sha256']:
                        raise SystemExit('source changed before archive: ' + entry['path'])
                    info = tarfile.TarInfo(entry['path'])
                    info.size, info.mode, info.mtime = len(data), 0o644, 0
                    tar.addfile(info, io.BytesIO(data))
                info = tarfile.TarInfo('ARCHIVE-MANIFEST.json')
                info.size, info.mode, info.mtime = len(manifest_bytes), 0o644, 0
                tar.addfile(info, io.BytesIO(manifest_bytes))
    expected = {e['path']: (e['bytes'], e['sha256']) for e in entries}
    expected['ARCHIVE-MANIFEST.json'] = (len(manifest_bytes), digest(manifest_bytes))
    with tarfile.open(archive, 'r:gz') as tar:
        members = tar.getmembers()
        if len(members) != len(expected) or {m.name for m in members} != set(expected):
            raise SystemExit('archive membership mismatch')
        for member in members:
            if not member.isfile():
                raise SystemExit('non-regular archive member')
            data = tar.extractfile(member).read()
            if (len(data), digest(data)) != expected[member.name]:
                raise SystemExit('archived member differs: ' + member.name)
    current = sorted(p.relative_to(source).as_posix() for p in source.rglob('*') if p.is_file())
    if current != [e['path'] for e in entries]:
        raise SystemExit('evidence membership changed during archive')
    for entry in entries:
        data = (source / entry['path']).read_bytes()
        if (len(data), digest(data)) != (entry['bytes'], entry['sha256']):
            raise SystemExit('evidence changed during archive: ' + entry['path'])
    (output / 'manifest.json').write_bytes(manifest_bytes)
    archive_bytes = archive.read_bytes()
    receipt = {'schema': 'next1010-archive-receipt-v1', 'archive': archive.name,
               'bytes': len(archive_bytes), 'sha256': digest(archive_bytes),
               'manifest_sha256': digest(manifest_bytes), 'file_count': len(entries),
               'every_member_verified': True, 'source_membership_and_bytes_stable': True}
    (output / 'archive-receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
    print(json.dumps(receipt, indent=2))


if __name__ == '__main__':
    main()
