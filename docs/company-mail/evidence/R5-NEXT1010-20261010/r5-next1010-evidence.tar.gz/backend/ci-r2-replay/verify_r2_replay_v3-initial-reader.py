#!/usr/bin/env python3
"""Independently verify original CI bytes; never execute or modify a test/gate."""
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re

HERE = Path(__file__).resolve().parent
OLD = HERE.parent / "ci-current-rounds"
HEAD = "13a2a07979b2939fe30330e81cc5e12bec253be2"
TREE = "184992fa8a7c8cf3975f2ffb77f91629f4371b2b"
BASE = "74d5fc72f7ad2e086bd3060b78c548dc302d0408"
BASE_TREE = "5cbe43bbdda6601a8bfca79e5ae9d1f83db7b95c"
WORKFLOW_HEAD = "4cc223a901d39e74cf885f2e6ce848fa5dd09acc"
WORKFLOW_MERGE = "75580e060952e8e879c5b0813fb27a9d8680ff2f"
WORKFLOW_TREE = "47955583e2c043134d9a91aac587e4f5cc5d8ef0"
RUN = 37994091262
JOB = 114035525252
PROTECTED = {
    "scripts/run_r5_next1010_pg.py": "703e9c81bde85662caa2c59bceeb7b2f242aad11db63dacc7e3190b024ec3389",
    "internal/api/handlers/r5_refresh_issuance_pg_test.go": "6404b853662b8d9dfec0f86aa4154674b5d63ea0f0f714af11cee54958e2297e",
    "internal/api/handlers/r5_refresh_issuance_test.go": "b6877aa181da130982c0538ff4f8d56d6c78da3bd578c6f84e550528da09d53f",
}
CHECKS = {}


def check(name, truth):
    if name in CHECKS:
        raise ValueError("duplicate check " + name)
    CHECKS[name] = bool(truth)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def read(name):
    return json.loads((HERE / name).read_text())


def api(name):
    return read(name)["api_report"]


def normalized(path):
    prefix = re.compile(rb"^\xef\xbb\xbf?(?=x)")  # overwritten by the complete anchored timestamp expression below
    prefix = re.compile(rb"^(?:\xef\xbb\xbf)?\d{4}-\d\d-\d\dT\d\d:\d\d:\d\d\.\d+Z ?")
    return b"\n".join(prefix.sub(b"", line) for line in path.read_bytes().split(b"\n"))


log_path = HERE / "v3-success-job114035525252-api-exact.log"
raw = log_path.read_bytes()
check("exact-public-job-log-bytes", len(raw) == 97228 and sha(raw) == "adc245c573becd29ede10dcb82f82c31d734ae40c3402f76675a6da59b78906a")
text = normalized(log_path)
frames = {}
frame_report = {}
allowed = {"postgres-service.log", "postgres-create-role.log", "postgres-create-database.log", "postgres-cleanup.log", "runner.exit", "runner.stdout", "runner.stderr"}
allowed |= {f"original-run/{phase}/go-test.{suffix}" for phase in ("baseline", "candidate") for suffix in ("jsonl", "stderr")}
begin = re.compile(rb"(?m)^R2_REFRESH_EVIDENCE_BEGIN (\S+) bytes=(\d+) sha256=([0-9a-f]{64})\n")
for match in begin.finditer(text):
    name = match[1].decode("ascii")
    if name not in allowed or name in frames:
        raise ValueError("unexpected or duplicate evidence frame " + name)
    ends = list(re.finditer(rb"(?m)^R2_REFRESH_EVIDENCE_END " + re.escape(match[1]) + rb"(?:\n|$)", text))
    check(name + "-unique-end", len(ends) == 1 and ends[0].start() >= match.end())
    body = text[match.end():ends[0].start()]
    size = int(match[2])
    separator_removed = False
    if len(body) == size + 1 and body.endswith(b"\n") and not body[:size].endswith(b"\n"):
        body = body[:size]
        separator_removed = True
    check(name + "-exact-length", len(body) == size)
    check(name + "-exact-hash", sha(body) == match[3].decode())
    if len(body) != size or sha(body) != match[3].decode():
        raise ValueError("cannot reconstruct exact evidence frame " + name)
    path = HERE / "restored-ci" / name
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(body)
    frames[name] = body
    frame_report[name] = {"path": str(path), "bytes": size, "sha256": sha(body), "printer_separator_lf_removed": separator_removed}
check("all-eleven-frames-present", set(frames) == allowed and len(frames) == 11)
check("original-runner-exit-zero", frames["runner.exit"] == b"0\n")
report = json.loads(frames["runner.stdout"])
check("receipt-correct-case", report["case"] == "refresh-issuance")
objects = []
for line in text.split(b"\n"):
    if not line.startswith(b"{"):
        continue
    try:
        objects.append(json.loads(line))
    except ValueError:
        continue
check("unique-full-comparison-in-public-log", sum(isinstance(o, dict) and {"case", "baseline", "candidate"} <= o.keys() for o in objects) == 1)
snapshots = [o for o in objects if isinstance(o, dict) and "phase" in o and "source" in o]
check("exact-before-and-after-snapshots", len(snapshots) == 2 and [s["phase"] for s in snapshots] == ["before", "after"])
expected_source = {"commit": HEAD, "tree": TREE, "status": "", "protected_sha256": PROTECTED}
for source in snapshots:
    check(source["phase"] + "-exact-product-source-clean", source["source"] == expected_source)
    check(source["phase"] + "-workflow-execution-identity", source["workflow"] == {"GITHUB_RUN_ATTEMPT": "1", "GITHUB_RUN_ID": str(RUN), "GITHUB_SHA": WORKFLOW_MERGE, "GITHUB_WORKFLOW_REF": "jyqj/tabmail/.github/workflows/next1010-r2-host-postgres.yml@refs/pull/258/merge", "GITHUB_WORKFLOW_SHA": WORKFLOW_MERGE})
check("wrapper-source-stable", snapshots[0]["source"] == snapshots[1]["source"])
for path, digest in PROTECTED.items():
    check("public-source-bytes-" + path, sha((HERE / "recovered-source" / Path(path).name).read_bytes()) == digest)
leaf_base = {"TestR5RefreshIssuancePostgresRotationFailurePreservesAncestor": "pass"}
leaf_base.update({"TestR5RefreshIssuancePostgresPreservesCurrentAndRetry/" + name: "pass" for name in ("display_name", "read_failure", "unchanged")})
leaf_base.update({"TestR5RefreshIssuancePostgresRejectsPostCommitAccountChange/" + name: state for name, state in (("deleted_user", "pass"), ("freeze", "pass"), ("freeze_unfreeze", "fail"), ("password", "fail"), ("role_change", "fail"))})
phase_results = {}
for phase in ("baseline", "candidate"):
    receipt = report[phase]
    expected_leaves = leaf_base if phase == "baseline" else {name: "pass" for name in leaf_base}
    expected_tests = dict(expected_leaves)
    expected_tests["TestR5RefreshIssuancePostgresPreservesCurrentAndRetry"] = "pass"
    expected_tests["TestR5RefreshIssuancePostgresRejectsPostCommitAccountChange"] = "fail" if phase == "baseline" else "pass"
    expected_end = "fail" if phase == "baseline" else "pass"
    data = frames[f"original-run/{phase}/go-test.jsonl"]
    check(phase + "-jsonl-hash-equals-original-receipt", sha(data) == receipt["log_sha256"])
    lines = data.split(b"\n")
    check(phase + "-jsonl-final-lf", lines[-1] == b"")
    rows = [json.loads(line) for line in lines[:-1]]
    check(phase + "-single-expected-package", {row.get("Package") for row in rows} == {"tabmail/internal/api/handlers"})
    starts = Counter(row["Test"] for row in rows if row.get("Test") and row["Action"] == "run")
    terminal_rows = [row for row in rows if row.get("Test") and row["Action"] in ("pass", "fail", "skip")]
    terminals = Counter(row["Test"] for row in terminal_rows)
    states = {row["Test"]: row["Action"] for row in terminal_rows}
    check(phase + "-all-eleven-test-starts-exactly-once", starts == Counter({name: 1 for name in expected_tests}))
    check(phase + "-all-eleven-test-terminals-exactly-once", terminals == Counter({name: 1 for name in expected_tests}))
    check(phase + "-exact-leaf-and-parent-states", states == expected_tests)
    check(phase + "-no-unstarted-test-output", {row["Test"] for row in rows if row.get("Test")} == set(starts))
    ordered = all(next(i for i, row in enumerate(rows) if row.get("Test") == name and row["Action"] == "run") < next(i for i, row in enumerate(rows) if row.get("Test") == name and row["Action"] in ("pass", "fail", "skip")) for name in expected_tests)
    check(phase + "-test-start-before-terminal", ordered)
    packages = [row["Action"] for row in rows if not row.get("Test") and row["Action"] != "output"]
    check(phase + "-strict-package-start-terminal", packages == ["start", expected_end])
    check(phase + "-package-terminates-last", rows[0]["Action"] == "start" and not rows[0].get("Test") and rows[-1]["Action"] == expected_end and not rows[-1].get("Test"))
    check(phase + "-no-any-skip", all(row["Action"] != "skip" for row in rows))
    check(phase + "-no-race-diagnostic", b"WARNING: DATA RACE" not in data)
    leaves = {name: state for name, state in states.items() if not any(other.startswith(name + "/") for other in states)}
    check(phase + "-same-nine-fixed-terminal-leaves", len(leaves) == 9 and leaves == expected_leaves == receipt["leaves"])
    check(phase + "-original-command", receipt["command"] == ["go", "test", "-mod=readonly", "-race", "-count=1", "-timeout=180s", "-json", "./internal/api/handlers", "-run", "^TestR5RefreshIssuancePostgres"])
    check(phase + "-original-exit", receipt["exit_code"] == (1 if phase == "baseline" else 0))
    check(phase + "-original-no-skip-missing", receipt["all_skips"] == 0 and receipt["missing_terminals"] == [])
    counts = Counter(leaves.values())
    check(phase + "-receipt-counts", receipt["pass"] == counts["pass"] and receipt["fail"] == counts["fail"])
    regression = {path: digest for path, digest in PROTECTED.items() if path.endswith("_test.go")}
    identity = {"commit": BASE if phase == "baseline" else HEAD, "tree": BASE_TREE if phase == "baseline" else TREE, "status": "\n".join("?? " + path for path in sorted(regression)) if phase == "baseline" else "", "regression_sha256": regression}
    check(phase + "-source-exact-and-stable", receipt["source_before"] == receipt["source_after"] == identity and receipt["source_stable"] is True)
    check(phase + "-stderr-empty", frames[f"original-run/{phase}/go-test.stderr"] == b"" and receipt["stderr_tail"] == "")
    check(phase + "-failure-output-matches-original-events", set(receipt["failure_output"]) == {name for name, state in states.items() if state != "pass"})
    phase_results[phase] = {"counts": dict(counts), "leaf_states": leaves, "test_start_count": sum(starts.values()), "test_terminal_count": sum(terminals.values()), "package_events": packages, "jsonl_sha256": sha(data), "source": identity, "baseline_is_clean": False if phase == "baseline" else None}
service = [o for o in objects if isinstance(o, dict) and "server_version" in o and "server_version_num" in o]
session = [o for o in objects if isinstance(o, dict) and "database" in o and "createdb" in o]
check("unique-pg-service-and-authenticated-session-reports", len(service) == len(session) == 1)
pg, login = service[0], session[0]
check("actual-postgres16-major", 160000 <= pg["server_version_num"] < 170000 and pg["server_version_num"] == login["server_version_num"] and pg["version"] == login["version"])
check("run-owned-disposable-authenticated-session", login["role"] == login["database"] == f"tm_r2_refresh_{RUN}_1" and login["createdb"] is True and login["superuser"] is True)
check("cleanup-original-db-and-role-observed", frames["postgres-create-role.log"] == b"CREATE ROLE\n" and frames["postgres-create-database.log"] == b"CREATE DATABASE\n" and frames["postgres-cleanup.log"] == b"DROP DATABASE\nDROP ROLE\n")
versions = re.findall(rb"(?m)^go version (\S+) \S+$", text)
check("actual-go1257", bool(versions) and set(versions) == {b"go1.25.7"})
run = api("v3-run-api.json")
check("ci-run-final-success-identity", run["id"] == RUN and run["head_sha"] == WORKFLOW_HEAD and run["event"] == "pull_request" and run["run_attempt"] == 1 and run["status"] == "completed" and run["conclusion"] == "success")
jobs = read("v3-jobs-api.json")["result"]["structuredContent"]["jobs"]
check("single-successful-required-job", len(jobs) == 1 and jobs[0]["id"] == JOB and jobs[0]["run_id"] == RUN and jobs[0]["status"] == "completed" and jobs[0]["conclusion"] == "success")
check("all-job-steps-completed-success", bool(jobs[0]["steps"]) and all(s["status"] == "completed" and s["conclusion"] == "success" for s in jobs[0]["steps"]))
required = {"Assert and record exact product source before execution", "Start preinstalled PostgreSQL 16 and create an owned disposable login", "Execute unchanged fixed baseline and exact candidate runner", "Assert and record exact product source after execution", "Remove only databases and login owned by this execution", "Print original receipt and both complete Go JSONL streams", "Preserve original execution and source evidence"}
check("all-required-steps-present-once", all(sum(s["name"] == name for s in jobs[0]["steps"]) == 1 for name in required))
check("public-workflow-exact-frozen-bytes", sha((HERE / "v3-workflow-public.yml").read_bytes()) == "6031dff2e749440ee6060666a77774228932b2bd9cd7c9d46042b3badb25e754")
public = api("v3-head-api.json")
actual = api("v3-actual-workflow-merge-api.json")
check("workflow-public-tree", public["sha"] == WORKFLOW_HEAD and public["tree"]["sha"] == WORKFLOW_TREE)
check("actual-workflow-merge-tree-parents", actual["sha"] == WORKFLOW_MERGE and actual["tree"]["sha"] == WORKFLOW_TREE and [p["sha"] for p in actual["parents"]] == [HEAD, WORKFLOW_HEAD])
artifacts = api("v3-artifacts-api.json")
check("one-original-artifact", artifacts["total_count"] == len(artifacts["artifacts"]) == 1)
artifact = artifacts["artifacts"][0]
check("artifact-identity-digest-not-expired", artifact["id"] == 11646835844 and artifact["name"] == f"next1010-r2-refresh-preinstalled-{RUN}-1" and artifact["workflow_run"]["id"] == RUN and artifact["workflow_run"]["head_sha"] == WORKFLOW_HEAD and artifact["expired"] is False and re.fullmatch(r"sha256:[0-9a-f]{64}", artifact["digest"]) is not None)
check("artifact-api-and-upload-reported-digest-agree", re.findall(rb"(?m)^SHA256 digest of uploaded artifact zip is ([0-9a-f]{64})$", text) == [artifact["digest"].split(":")[1].encode()])
history_path = HERE / "recovered-round2-history-review.json"
history = json.loads(history_path.read_text())
check("historical-review-identity", sha(history_path.read_bytes()) == "7c16d9502bb7b2731b29998d94af9c21cdebfb000be2e4138afb5db795818bb1")
check("historical-audit-sponsor-accepted-same-tree", history["all_checks_pass"] is True and all(history["checks"].values()) and history["accepted_candidate_fixed_leaves"] == 21 and len(history["cases"]) == 2 and all(c["actual_tree"] == TREE and c["public_head_same_tree"] == HEAD for c in history["cases"]))
for case in history["cases"]:
    check(case["case"] + "-old-raw-still-matches", sha(Path(case["raw_log"]).read_bytes()) == case["raw_log_sha256"])
v1 = api("replay-v1-failed-run-recovered-api.json")
check("failed-workflow-v1-zero-jobs-retained", v1["id"] == 37992850872 and v1["conclusion"] == "failure" and read("v1-zero-jobs-api.json")["result"]["structuredContent"]["jobs"] == [])
v2 = api("replay-v2-run-initial-recovered-api.json")
v2jobs = read("v2-jobs-api.json")["result"]["structuredContent"]["jobs"]
v2text = normalized(HERE / "v2-failed-job114033941462-api-exact.log")
check("failed-workflow-v2-diagnostic-zero-tests-retained", v2["id"] == 37993638392 and v2["conclusion"] == "failure" and len(v2jobs) == 1 and v2jobs[0]["id"] == 114033941462 and any(s["name"] == "Execute unchanged fixed baseline and exact candidate runner" and s["conclusion"] == "skipped" for s in v2jobs[0]["steps"]) and b'ERROR:  unrecognized configuration parameter "lc_collate"' in v2text and b"R2_REFRESH_EVIDENCE_BEGIN original-run/" not in v2text)
result = {"generated_at": datetime.now(timezone.utc).isoformat(), "verifier_path": str(Path(__file__).resolve()), "verifier_sha256": sha(Path(__file__).read_bytes()),
    "evidence_provenance": "New independent review of exact decoded public CI logs after a workspace reset; no product test or CI runner changes, no fabricated restoration of old native logs.",
    "workflow_run": RUN, "workflow_job": JOB, "workflow_public_head": WORKFLOW_HEAD, "workflow_actual_merge_commit": WORKFLOW_MERGE, "workflow_tree": WORKFLOW_TREE,
    "product_actual_checkout_commit": HEAD, "product_tree": TREE, "raw_job_log": str(log_path), "raw_job_log_sha256": sha(raw),
    "restored_frames": frame_report, "source_before": snapshots[0], "source_after": snapshots[1], "phases": phase_results,
    "postgres_service": pg, "postgres_authenticated_session": login, "artifact_api_report": artifact, "artifact_zip_locally_downloaded": False, "artifact_zip_digest_locally_verified": False,
    "prior_same_tree_audit10_sponsor11": {"report": str(history_path), "sha256": sha(history_path.read_bytes()), "cases": history["cases"], "attempt2_reused_not_reexecuted": True},
    "prior_zero_test_executions_preserved": history["failed_refresh_attempts"] + [{"run_id": 37992850872, "reason": "Workflow v1 invalid runner context at job env; no jobs"}, {"run_id": 37993638392, "job_id": 114033941462, "reason": "Workflow v2 PostgreSQL session diagnostic lc_collate lookup failed; runner step skipped; cleanup succeeded"}],
    "checks": CHECKS, "all_checks_pass": all(CHECKS.values()), "accepted_candidate_fixed_leaves": 30 if all(CHECKS.values()) else None,
    "round2_postgres_complete": all(CHECKS.values()), "todo_count_for_this_verification_work": 0,
    "verdict": "ACCEPT_ROUND2_POSTGRES_30_LEAVES_SAME_PRODUCT_TREE" if all(CHECKS.values()) else "REJECT"}
out = HERE / "acceptance.json"
out.write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps({"path": str(out), "sha256": sha(out.read_bytes()), "checks": len(CHECKS), "failed": [name for name, passed in CHECKS.items() if not passed], "verdict": result["verdict"]}))
raise SystemExit(0 if all(CHECKS.values()) else 1)
