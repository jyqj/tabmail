"""Independent verification of the original framed R2 replay output."""
from pathlib import Path
import json,re,hashlib,collections,subprocess
p=Path(__file__).resolve().parent
raw=(p/'v3-success-job114035525252-api-exact.log').read_bytes()
lines=[re.sub(rb'^(?:\xef\xbb\xbf)?\d{4}-\d{2}-\d{2}T\S+Z ?',b'',x) for x in raw.splitlines(keepends=True)]
frames={};i=0
while i<len(lines):
    m=re.fullmatch(rb'R2_REFRESH_EVIDENCE_BEGIN (\S+) bytes=(\d+) sha256=([a-f0-9]{64})\r?\n?',lines[i])
    if not m:i+=1;continue
    name=m[1].decode();n=int(m[2]);assert name not in frames;data=[];i+=1
    while i<len(lines) and lines[i].rstrip(b'\r\n')!=b'R2_REFRESH_EVIDENCE_END '+m[1]:data.append(lines[i]);i+=1
    assert i<len(lines);body=b''.join(data);assert len(body)==n or (len(body)==n+1 and body[-1:]==b'\n');body=body[:n]
    assert hashlib.sha256(body).hexdigest()==m[3].decode(),name
    frames[name]=body;i+=1
assert frames['runner.exit']==b'0\n'
# Original runner stdout also contains git worktree's HEAD announcement.
reports=[json.loads(x) for x in frames['runner.stdout'].splitlines() if x.startswith(b'{')]
reports=[x for x in reports if isinstance(x,dict) and {'case','baseline','candidate'}<=x.keys()]
assert len(reports)==1;report=reports[0];assert report['case']=='refresh-issuance'
pack='tabmail/internal/api/handlers';manifest={}
for label,good,bad,final in [('baseline',6,3,'fail'),('candidate',9,0,'pass')]:
    data=frames['original-run/'+label+'/go-test.jsonl'];rows=[json.loads(x) for x in data.splitlines()];s=report[label]
    assert hashlib.sha256(data).hexdigest()==s['log_sha256']
    events=[{'package':r.get('Package'),'action':r['Action']} for r in rows if not r.get('Test') and r['Action'] in ['start','pass','fail','skip']]
    assert events==[{'package':pack,'action':'start'},{'package':pack,'action':final}]
    starts=collections.Counter(r['Test'] for r in rows if r.get('Test') and r['Action']=='run');terms=collections.defaultdict(list)
    for r in rows:
        if r.get('Test') and r['Action'] in ['pass','fail','skip']:terms[r['Test']].append(r['Action'])
    assert set(starts)==set(terms) and all(n==1 for n in starts.values()) and all(len(v)==1 for v in terms.values())
    leaves={k:v[0] for k,v in terms.items() if not any(other.startswith(k+'/') for other in terms)}
    assert leaves==s['leaves'] and len(leaves)==9 and collections.Counter(leaves.values())==collections.Counter({'pass':good,'fail':bad})
    assert not any(r['Action']=='skip' for r in rows) and b'DATA RACE' not in data
    assert s['source_stable'] and s['source_before']==s['source_after'] and s['missing_terminals']==[] and s['all_skips']==0
    assert s['command']==['go','test','-mod=readonly','-race','-count=1','-timeout=180s','-json','./internal/api/handlers','-run','^TestR5RefreshIssuancePostgres']
    assert (s['exit_code']==0)==(label=='candidate')
    manifest[label]={'leaves':leaves,'package_events':events,'jsonl_sha256':hashlib.sha256(data).hexdigest()}
assert set(manifest['baseline']['leaves'])==set(manifest['candidate']['leaves'])
candidate=report['candidate']['source_before'];assert candidate['commit']=='13a2a07979b2939fe30330e81cc5e12bec253be2' and candidate['tree']=='184992fa8a7c8cf3975f2ffb77f91629f4371b2b' and candidate['status']==''
assert report['baseline']['source_before']['commit']=='74d5fc72f7ad2e086bd3060b78c548dc302d0408'
phase=[]
for line in lines:
    try:d=json.loads(line)
    except (ValueError,UnicodeDecodeError):continue
    if isinstance(d,dict) and d.get('phase') in ['before','after'] and 'workflow' in d:phase.append(d)
assert len(phase)==2 and [v['phase'] for v in phase]==['before','after'];assert phase[0]['source']==phase[1]['source']
src=phase[0]['source'];assert src['commit']==candidate['commit'] and src['tree']==candidate['tree'] and src['status']==''
assert src['protected_sha256']['scripts/run_r5_next1010_pg.py']=='703e9c81bde85662caa2c59bceeb7b2f242aad11db63dacc7e3190b024ec3389'
repo=p.parents[2]/'tabmail-recovered'
for name,want in src['protected_sha256'].items():
    actual=subprocess.check_output(['git','-C',str(repo),'show',candidate['commit']+':'+name]);assert hashlib.sha256(actual).hexdigest()==want
nf=p.parents[1]/'recovered/native129';tests=json.loads((nf/'vitest-results.json').read_text())
assert tests['success'] and tests['numTotalTests']==tests['numPassedTests']==129 and tests['numFailedTests']==tests['numPendingTests']==tests['numTodoTests']==0
assert len(tests['testResults'])==9 and all(a['status']=='passed' for f in tests['testResults'] for a in f['assertionResults']);assert json.loads((nf/'tsc.json').read_text())['exit']==0
out={'status':'ACCEPT_ROOT_INDEPENDENT_REPLAY_AND_NATIVE129','run':37994091262,'job':114035525252,'actual_product_source':candidate,'exact_raw_log_sha256':hashlib.sha256(raw).hexdigest(),'frame_count':len(frames),'all_frame_lengths_and_sha256_verified':True,'go_jsonl_independently_reparsed':manifest,'original_runner_unchanged':True,'source_before_after_clean':True,'native129_report_sha256':hashlib.sha256((nf/'acceptance.json').read_bytes()).hexdigest(),'native129':{'tests':129,'files':9,'fail':0,'skip_or_todo':0,'typecheck_exit':0},'reader_refinement':'Initial root inspection incorrectly treated original runner.stdout as pure JSON; its normal git worktree HEAD line is now preserved and the single original comparison JSON object is selected. No original bytes or acceptance condition changed.','qualification':'R2 product13a executed via a separate workflow definition head. Native frontend is a new final177 execution after evidence loss, not restoration of old native log bytes.'}
(p/'root-independent-replay-review.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({'status':out['status'],'frames':len(frames),'baseline':[6,3],'candidate':[9,0],'native129':out['native129'],'root_report_sha256':hashlib.sha256((p/'root-independent-replay-review.json').read_bytes()).hexdigest()},indent=2))
