#!/usr/bin/env python3
"""Fresh independent reconstruction from re-fetched public R2 receipts after reset.

This reads evidence only. It does not run or modify product tests or CI gates.
"""
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re

HERE = Path(__file__).resolve().parent
OLD = HERE.parent / "ci-current-rounds"
BASE = "74d5fc72f7ad2e086bd3060b78c548dc302d0408"
BASE_TREE = "5cbe43bbdda6601a8bfca79e5ae9d1f83db7b95c"
HEAD = "13a2a07979b2939fe30330e81cc5e12bec253be2"
MERGE = "b93001f102b87b0e6e5541847091730bd72da8e6"
TREE = "184992fa8a7c8cf3975f2ffb77f91629f4371b2b"
RUN = 37983167534
CHECKS = {}


def check(name, value):
    if name in CHECKS:
        raise ValueError("duplicate check " + name)
    CHECKS[name] = bool(value)


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def api(path):
    return json.loads(path.read_text())["api_report"]


def normalized(path):
    raw = path.read_text()
    return "\n".join(re.sub(r"^\ufeff?\d{4}-\d\d-\d\dT\d\d:\d\d:\d\d\.\d+Z ?", "", line)
                     for line in raw.split("\n"))


def comparisons(path):
    text = normalized(path)
    decoder = json.JSONDecoder()
    reports = []
    for match in re.finditer(r"(?m)^\{", text):
        try:
            item, _ = decoder.raw_decode(text[match.start():])
        except ValueError:
            continue
        if isinstance(item, dict) and {"case", "baseline", "candidate"} <= item.keys():
            reports.append(item)
    return reports


AUDIT = {
    "TestR5PermissionAuditActualCommandsVisible/permission." + action: "fail"
    for action in ("override.patch", "profile.assign", "profile.create", "profile.delete", "profile.update")
}
AUDIT.update({"TestR5PermissionAuditHTTPProjectionPaginationAndBoundaries/" + name: state for name, state in (
    ("admin_paginated_safe_projection", "fail"), ("api_key_cannot_read", "pass"),
    ("current_role_rechecked", "pass"), ("employee_cannot_read", "pass"), ("foreign_actor_cannot_read", "pass"))})
SPONSOR = {
    "TestR5ActivationSponsorPostgresBusyWriterRejectsWithoutWaiting": "fail",
    "TestR5ActivationSponsorPostgresCancellationDuringOutboxWait": "pass",
}
SPONSOR.update({"TestR5ActivationSponsorPostgresCurrentSponsor/" + name: "pass" for name in (
    "foreign_demoted", "foreign_frozen", "foreign_reenabled", "foreign_super", "local_admin")})
SPONSOR.update({"TestR5ActivationSponsorPostgresRevokedDuringOutboxWait/" + name: "fail" for name in (
    "delete", "demote_admin", "demote_user", "freeze")})
CASES = [
    ("permission-audit", 113998482065, 114021322601,
     "round2-audit-job113998482065-api-exact.log", "round2-attempt2-audit-carried-job114021322601.log",
     "b1d5c5ab1b4e7a83356cb29c05fefdfdc4d143e96e66c9abc2a936215b961a69",
     "r5_permission_audit_visibility_test.go", "226e8f23986277a6fede2dd20f7fc485844fc717279077dc411f49530d2201ea",
     "^TestR5PermissionAudit", AUDIT, 11643694771,
     "sha256:ec45fe5d0e7cf9faff57ea2487f5f1d7494751f96411afce40812e3d4fe81697"),
    ("activation-sponsor", 113998482254, 114021367889,
     "round2-sponsor-job113998482254.log", "round2-attempt2-sponsor-carried-job114021367889.log",
     "74ae2934441e4cf1e1fa88619a921f2c599ca93c957ffd8e1e6e2750c1268a26",
     "r5_activation_sponsor_test.go", "1ccd857e3ad5f7d6541db247a25bc5ad3c8142277395a5fe7fcda89d5b1fb2a0",
     "^TestR5ActivationSponsorPostgres", SPONSOR, 11644158720,
     "sha256:7b1b80a7a59a5be171cd4bc9ec6441537e16f40683896f447f4ab2fccb7e1e87"),
]
jobs1 = api(HERE / "old-attempt1-jobs-api.json")
jobs2 = api(HERE / "old-attempt2-jobs-api.json")
check("attempt1-three-jobs", jobs1["total_count"] == len(jobs1["jobs"]) == 3)
check("attempt2-three-jobs", jobs2["total_count"] == len(jobs2["jobs"]) == 3)
jobs = {job["id"]: job for batch in (jobs1, jobs2) for job in batch["jobs"]}
artifacts = api(OLD / "round2-artifacts-recovered-api.json")
check("two-original-artifacts", artifacts["total_count"] == len(artifacts["artifacts"]) == 2)
artifact_by_id = {item["id"]: item for item in artifacts["artifacts"]}
for phase in (1, 2):
    run = api(OLD / f"round2-attempt{phase}-recovered-api.json")
    check(f"attempt{phase}-run-identity", run["id"] == RUN and run["run_attempt"] == phase and run["head_sha"] == HEAD)
    check(f"attempt{phase}-remains-failed", run["status"] == "completed" and run["conclusion"] == "failure")
head = api(OLD / "round2-source-head-recovered-api.json")
merge = api(OLD / "round2-merge-recovered-api.json")
check("public-head-tree", head["sha"] == HEAD and head["tree"]["sha"] == TREE)
check("actual-merge-tree", merge["sha"] == MERGE and merge["tree"]["sha"] == TREE)
check("actual-merge-parents", [parent["sha"] for parent in merge["parents"]] == ["ffb22b64698e4ff168a8d622018d3e169b3cdf07", HEAD])
case_results = []
for case, original_id, carried_id, original_name, carried_name, raw_sha, basename, test_sha, pattern, expected, artifact_id, digest in CASES:
    path = OLD / original_name
    check(case + "-original-raw-hash", sha(path) == raw_sha)
    check(case + "-carried-is-same-execution-bytes", path.read_bytes() == (OLD / carried_name).read_bytes())
    check(case + "-public-frozen-test-hash", sha(HERE / "recovered-source" / basename) == test_sha)
    found = comparisons(path)
    check(case + "-unique-comparison", len(found) == 1)
    if len(found) != 1:
        continue
    report = found[0]
    check(case + "-case", report["case"] == case)
    regression = {"internal/store/postgres/" + basename: test_sha}
    command = ["go", "test", "-mod=readonly", "-race", "-count=1", "-timeout=180s", "-json", "./internal/store/postgres", "-run", pattern]
    for phase, states, commit, tree, status, code in (
        ("baseline", expected, BASE, BASE_TREE, "?? internal/store/postgres/" + basename, 1),
        ("candidate", {name: "pass" for name in expected}, MERGE, TREE, "", 0)):
        p = report[phase]
        identity = {"commit": commit, "tree": tree, "status": status, "regression_sha256": regression}
        check(case + "-" + phase + "-source", p["source_before"] == p["source_after"] == identity and p["source_stable"] is True)
        check(case + "-" + phase + "-command", p["command"] == command)
        check(case + "-" + phase + "-fixed-terminal-leaves", p["leaves"] == states)
        count = Counter(states.values())
        check(case + "-" + phase + "-counts", p["pass"] == count["pass"] and p["fail"] == count["fail"])
        check(case + "-" + phase + "-no-skip-or-missing", p["all_skips"] == 0 and p["missing_terminals"] == [])
        check(case + "-" + phase + "-exit", p["exit_code"] == code)
        check(case + "-" + phase + "-valid-reported-stream-hash", re.fullmatch(r"[0-9a-f]{64}", p["log_sha256"]) is not None)
    check(case + "-candidate-no-failure-output", report["candidate"]["failure_output"] == {})
    for job_id, attempt in ((original_id, 1), (carried_id, 2)):
        job = jobs[job_id]
        check(str(job_id) + "-job", job["run_id"] == RUN and job["run_attempt"] == attempt and job["status"] == "completed" and job["conclusion"] == "success")
        check(str(job_id) + "-original-compare-success", sum(step["name"] == "Compare fixed baseline and exact candidate" and step["conclusion"] == "success" for step in job["steps"]) == 1)
    artifact = artifact_by_id[artifact_id]
    check(case + "-artifact", artifact["name"] == "next1010-" + case and artifact["expired"] is False and artifact["digest"] == digest and artifact["workflow_run"]["id"] == RUN and artifact["workflow_run"]["head_sha"] == HEAD)
    out = HERE / ("recovered-" + case + "-comparison.json")
    out.write_text(json.dumps(report, indent=2) + "\n")
    case_results.append({"case": case, "run_id": RUN, "original_attempt": 1, "original_job_id": original_id,
        "attempt2_carried_job_id": carried_id, "carried_log_is_byte_identical": True, "executions_counted": 1,
        "actual_checkout_commit": MERGE, "actual_tree": TREE, "public_head_same_tree": HEAD,
        "baseline_counts": dict(Counter(expected.values())), "candidate_pass": len(expected),
        "frozen_leaf_ids": sorted(expected), "raw_log": str(path), "raw_log_sha256": sha(path),
        "comparison": str(out), "comparison_sha256": sha(out), "artifact_api": artifact,
        "artifact_zip_locally_downloaded": False, "artifact_zip_digest_locally_verified": False,
        "original_go_jsonl_bytes_locally_restored": False,
        "evidence_limit": "Original runner receipt and process exits establish fixed terminal leaves/no reported missing or skips; raw Go JSONL was an artifact, not printed, and cannot be locally checked for duplicate events after reset."})
failures = []
for job_id, attempt, filename, digest in (
    (113998482277, 1, "round2-refresh-job113998482277.log", "b514221b639bd8b9cd20882961cd48826c32f6b32602002df656a6a22ecca383"),
    (114021320289, 2, "round2-refresh-job114021320289.log", "d8d856bea086d932efed82ec8624859660336fa94b5a785c15344e4c993a6a09")):
    path = OLD / filename
    job = jobs[job_id]
    steps = {step["name"]: step["conclusion"] for step in job["steps"]}
    check(str(job_id) + "-raw-hash", sha(path) == digest)
    check(str(job_id) + "-failed-job", job["run_id"] == RUN and job["run_attempt"] == attempt and job["conclusion"] == "failure" and job["status"] == "completed")
    check(str(job_id) + "-pre-checkout-docker-failure", steps["Initialize containers"] == "failure" and steps["Run actions/checkout@v4"] == "skipped" and steps["Compare fixed baseline and exact candidate"] == "skipped" and "toomanyrequests" in normalized(path) and "unauthenticated pull rate limit" in normalized(path))
    check(str(job_id) + "-zero-comparisons", len(comparisons(path)) == 0)
    failures.append({"job_id": job_id, "attempt": attempt, "run_id": RUN, "raw_log": str(path), "sha256": sha(path), "failure": "Docker Hub postgres:16 pull limit before checkout", "original_runner_executed": False, "comparison_count": 0, "regression_tests_executed": 0})
result = {"generated_at": datetime.now(timezone.utc).isoformat(),
    "provenance": "Fresh review reconstructed from re-fetched original GitHub logs/API after workspace reset; not restoration of lost local review report bytes.",
    "previous_native_execution_logs_restored": False, "previous_local_report_bytes_restored": False,
    "verifier_path": str(Path(__file__).resolve()), "verifier_sha256": sha(Path(__file__)),
    "cases": case_results, "failed_refresh_attempts": failures,
    "accepted_candidate_fixed_leaves": 21, "round2_complete": False,
    "remaining": "Exact product13a refresh9 replay requires independent final acceptance.",
    "checks": CHECKS, "all_checks_pass": all(CHECKS.values()),
    "verdict": "ACCEPT_RECOVERED_AUDIT10_SPONSOR11_ONLY" if all(CHECKS.values()) else "REJECT"}
output = HERE / "recovered-round2-history-review.json"
output.write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps({"path": str(output), "sha256": sha(output), "checks": len(CHECKS), "failed": [name for name, passed in CHECKS.items() if not passed], "verdict": result["verdict"]}))
raise SystemExit(0 if all(CHECKS.values()) else 1)
