#!/usr/bin/env python3
"""Freeze a new final read-only GitHub audit and its recovered evidence manifest.

Consumes freshly saved API responses. Does not run tests or contact GitHub.
The previous append-only audit is updated only under an exact hash guard.
"""
from pathlib import Path
import hashlib
import json
import re

ROOT = Path("/workspace/scratch/831fbd171897/tabmail-run-evidence/recovered")
AUDIT = ROOT / "branch-audit"
SOURCE = json.loads((AUDIT / "final-api-normalized.json").read_bytes())
D = SOURCE["data"]
MAIN = "d6d512172fb6b874c3283d9df3f4d56758684a13"
INTEGRATION = "integration/company-mail-r5-pr-management-20261007"
FINAL = "f92517a2fe39cf2bc186ec1f57601cd438d81d72"
PREVIOUS = "7fe2830c309e05a0c25e5a54bf3de773e50dd332c829821bee358f9056ea08d7"
OLD_MANIFEST = "0744a517bb461a0f9242dc343e604fc2ad0f9dafe502b6f6ec8017a935078a5e"

def sha(data):
    return hashlib.sha256(data).hexdigest()

def meta(path):
    data = path.read_bytes()
    return {"path": str(path), "bytes": len(data), "sha256": sha(data)}

def relative_meta(path, base=ROOT):
    item = meta(path)
    item["path"] = path.relative_to(base).as_posix()
    return item

def encode(obj):
    return (json.dumps(obj, ensure_ascii=False, indent=2) + "\n").encode()

def new(path, data):
    if not isinstance(data, bytes):
        data = encode(data)
    with path.open("xb") as stream:
        stream.write(data)

branches = D["branches_page1"] + D["branches_page2"]
assert len(D["branches_page1"]) == 100
assert len(D["branches_page2"]) == 18
assert D["branches_page3"] == []
index = {b["name"]: b for b in branches}
assert len(branches) == len(index) == 118
for name, expected in SOURCE["expected_refs"].items():
    assert index[name]["commit"]["sha"] == expected, name
assert D["branch_main"]["commit"]["sha"] == MAIN
assert D["branch_integration"]["commit"]["sha"] == FINAL
assert D["branch_integration"]["commit"]["commit"]["tree"]["sha"] == "e8a04cbe516889f225d24ae7aed5d81d8e073650"
assert D["branch_replay_base"]["commit"]["sha"] == "c8bd2173b804654c4cd4e0ca6fb77cabdd2fd719"

expected_merges = [
    (254, 1, "b458e917c6b084fbc557f351f03ca762b1c11924", "a6a0090fc069d131213b559f94c669184525f312", "8dba655927b80a1e5ee66228fd3d29bab3a8bee2", ["ffb22b64698e4ff168a8d622018d3e169b3cdf07", "b458e917c6b084fbc557f351f03ca762b1c11924"], INTEGRATION),
    (255, 2, "13a2a07979b2939fe30330e81cc5e12bec253be2", "421293164295073a024799c5bf5bc2cc328647a0", "184992fa8a7c8cf3975f2ffb77f91629f4371b2b", ["a6a0090fc069d131213b559f94c669184525f312", "13a2a07979b2939fe30330e81cc5e12bec253be2"], INTEGRATION),
    (256, 3, "177ee571b194836678cc9a473f178c655326ba7c", "66a059d90cd93069926595af4587e42998f0b53a", "2d5d2c44680f6a6cb2b2d1166e2923806beafcc8", ["421293164295073a024799c5bf5bc2cc328647a0", "177ee571b194836678cc9a473f178c655326ba7c"], INTEGRATION),
    (257, "catalog-maintenance", "6a402ce1269bfc41c932a67b592fee5bca235774", FINAL, "e8a04cbe516889f225d24ae7aed5d81d8e073650", ["66a059d90cd93069926595af4587e42998f0b53a", "6a402ce1269bfc41c932a67b592fee5bca235774"], INTEGRATION),
    (258, "verification-only", "4cc223a901d39e74cf885f2e6ce848fa5dd09acc", "c8bd2173b804654c4cd4e0ca6fb77cabdd2fd719", "47955583e2c043134d9a91aac587e4f5cc5d8ef0", ["13a2a07979b2939fe30330e81cc5e12bec253be2", "4cc223a901d39e74cf885f2e6ce848fa5dd09acc"], "verification/r5-next1010-r2-replay-base"),
]
merges = []
for number, round_id, head, merge, tree, parents, base in expected_merges:
    pr, commit = D[f"pr{number}"], D[f"merge{number}"]
    assert pr["state"] == "closed" and pr["merged"] is True and pr["draft"] is False
    assert pr["head"]["sha"] == head and pr["merge_commit_sha"] == merge
    assert pr["base"]["ref"] == base
    assert commit["sha"] == merge and commit["tree"]["sha"] == tree
    assert [p["sha"] for p in commit["parents"]] == parents
    merges.append({
        "number": number, "round": round_id, "url": pr["html_url"],
        "state": pr["state"], "merged": pr["merged"], "merged_at": pr["merged_at"],
        "head_ref": pr["head"]["ref"], "head_sha": head, "base_ref": base,
        "payload_base_sha": pr["base"]["sha"], "actual_merge_commit": merge,
        "complete_tree": tree, "parents": parents,
        "head_reachable_as_second_parent": True,
        "merge_and_tree_match_expected": True,
        "stale_payload_base_not_used_as_actual_ref": True,
    })

deleted = []
assert D["repo"]["delete_branch_on_merge"] is True
for i, name in enumerate(SOURCE["deleted_refs"]):
    result = D[f"deleted_branch_{i}"]
    assert name not in index
    assert result["error_data"]["status"] == "404"
    assert result["error_data"]["message"] == "Branch not found"
    deleted.append({
        "ref": name, "listed_in_complete_inventory": False, "named_branch_http_status": 404,
        "consistent_with_enabled_delete_branch_on_merge": True,
        "actual_deletion_actor_independently_verified": False,
    })

historical = []
for number in [17, 20, 24, 40]:
    pr = D[f"pr{number}"]
    assert pr["state"] == "open" and pr["draft"] is True and pr["merged"] is False
    row = {"number": number, "url": pr["html_url"], "state": "open", "draft": True,
           "mergeable": pr["mergeable"], "mergeable_state": pr["mergeable_state"]}
    for side in ["head", "base"]:
        ref = pr[side]["ref"]
        actual = index[ref]["commit"]["sha"]
        assert actual == SOURCE["expected_refs"][ref]
        comparison = D[f"compare_pr{number}_{side}"]
        expected_ahead = {"head": {17: 3, 20: 8, 24: 3, 40: 2}, "base": {17: 0, 20: 7, 24: 0, 40: 0}}[side][number]
        assert comparison["ahead_by"] == expected_ahead
        row[side] = {
            "ref": ref, "actual_sha": actual, "pr_payload_sha": pr[side]["sha"],
            "payload_matches_actual_ref": pr[side]["sha"] == actual, "retained": True,
            "unchanged_from_recovered_pre_final_snapshot": True,
            "unique_git_commits_vs_final_integration": comparison["ahead_by"],
            "behind_final_integration": comparison["behind_by"],
            "compare_status": comparison["status"],
        }
    historical.append(row)

completed_numbers = [242, 243, 244, 245, 246, 247, 249, 250, 252, 253]
issue_rows = []
for number in completed_numbers + [248, 251]:
    issue = D[f"issue{number}"]
    tasks = [
        {"checked": m.group(1).lower() == "x", "text": m.group(2)}
        for m in re.finditer(r"^\s*[-*]\s+\[([xX ])\]\s*(.*)$", issue["body"], re.M)
    ]
    planned = number in completed_numbers
    assert issue["state"] == "closed"
    assert issue["state_reason"] == ("completed" if planned else "not_planned")
    assert len(tasks) == 4
    assert sum(task["checked"] for task in tasks) == (4 if planned else 0)
    issue_rows.append({
        "number": number, "url": issue["html_url"], "title": issue["title"],
        "state": issue["state"], "state_reason": issue["state_reason"],
        "closed_at": issue["closed_at"], "updated_at": issue["updated_at"],
        "checked": sum(task["checked"] for task in tasks),
        "unchecked": sum(not task["checked"] for task in tasks),
        "task_checkboxes": tasks, "body_utf8_sha256": sha(issue["body"].encode()),
        "counted_implementation_todo": planned,
    })
assert sum(row["counted_implementation_todo"] for row in issue_rows) == 10

pr56 = D["pr56"]
assert pr56["state"] == "open" and pr56["draft"] is True and pr56["merged"] is False
assert pr56["head"]["ref"] == INTEGRATION and pr56["head"]["sha"] == FINAL
assert pr56["base"]["ref"] == "main" and pr56["base"]["sha"] == MAIN
assert D["rulesets"] == []
assert D["main_classic_protection"]["error_data"]["status"] == "403"

report = {
    "schema": "recovered-final-pr-branch-issue-audit-v1",
    "status": "PASS_READ_ONLY_FINAL_10_IMPLEMENTATION_TODOS",
    "retrieval_started": SOURCE["retrieval_started"], "retrieval_finished": SOURCE["retrieval_finished"],
    "scope": "Fresh GitHub read-only audit after all three implementation merges, catalog maintenance and separate R2 verification merge. No Go/PG rerun, PR mutation, issue mutation, branch deletion or source modification.",
    "implementation_progress": {
        "target": 10, "completed": 10, "remaining": 0,
        "counted_issues": completed_numbers, "withdrawn_not_planned_issues": [248, 251],
        "maintenance_and_verification_todos_counted": 0,
        "rounds": [
            {"round": 1, "issues": [242, 243, 244, 245], "newly_completed": 4, "completed_total": 4, "remaining": 6},
            {"round": 2, "issues": [246, 247, 252], "newly_completed": 3, "completed_total": 7, "remaining": 3},
            {"round": 3, "issues": [249, 250, 253], "newly_completed": 3, "completed_total": 10, "remaining": 0},
        ],
        "checkboxes_checked": 40, "checkboxes_unchecked": 0,
        "all_counted_issues_independently_fresh_read": True,
    },
    "issues": issue_rows, "merged_prs": merges,
    "integration": {"ref": INTEGRATION, "actual_sha": FINAL, "complete_tree": D["merge257"]["tree"]["sha"]},
    "main": {"actual_sha": MAIN, "unchanged": True},
    "integration_pr": {
        "number": 56, "url": pr56["html_url"], "state": "open", "draft": True,
        "head": FINAL, "base": MAIN, "mergeable": pr56["mergeable"], "mergeable_state": pr56["mergeable_state"],
        "not_merged_to_main": True,
    },
    "remote_branch_inventory": {
        "count": 118, "unique_names": 118, "page_sizes": [100, 18, 0],
        "per_page": 100, "terminal_empty_page_observed": True,
        "complete_at_retrieval_time": True,
        "all_names_and_shas": sorted(branches, key=lambda item: item["name"]),
        "not_a_count_delta_from_lost_pre_session_full_inventory": True,
    },
    "deleted_batch_heads": deleted,
    "retained_verification_base": {
        "ref": "verification/r5-next1010-r2-replay-base",
        "actual_sha": "c8bd2173b804654c4cd4e0ca6fb77cabdd2fd719",
        "complete_tree": "47955583e2c043134d9a91aac587e4f5cc5d8ef0",
        "purpose": "Retained standalone preinstalled PostgreSQL verification configuration evidence",
        "merge_target_separate_from_integration_and_main": True,
    },
    "historical_prs_and_eight_retained_refs": historical,
    "branch_settings": {
        "delete_branch_on_merge": D["repo"]["delete_branch_on_merge"],
        "allow_merge_commit": D["repo"]["allow_merge_commit"],
        "allow_squash_merge": D["repo"]["allow_squash_merge"],
        "allow_rebase_merge": D["repo"]["allow_rebase_merge"],
        "inventory_protected_branch_count": sum(branch["protected"] for branch in branches),
        "main_branch_reported_protection": D["branch_main"]["protection"],
        "integration_branch_reported_protection": D["branch_integration"]["protection"],
        "visible_repository_and_parent_rulesets": D["rulesets"],
        "classic_protection_admin_endpoint": {
            "http_status": 403, "message": "Resource not accessible by integration",
            "not_independently_verified_from_admin_endpoint": True,
        },
        "settings_not_modified": True,
    },
    "interpretation": [
        "The actual integration ref and merge objects take precedence over stale base.sha fields in closed PR payloads.",
        "All five merged head branches are absent from the full inventory and individually return 404. This is consistent with automatic branch deletion being enabled; the deletion actor is not proven.",
        "The four historical PR heads and PR20 base contain unique Git commits versus final integration. Unique commits alone do not establish unique patches or functional behavior.",
        "PR17, PR24 and PR40 bases are ancestors of final integration, but all eight historical refs remain retained as requested.",
        "PR17 remains draft and conflicting; PR56 remains draft/mergeable with an unstable summary. Neither was merged into main.",
        "This audit observes API branch-protection fields and an empty visible ruleset list; the administrative classic-protection endpoint returned 403.",
        "The temporary R2 verification merge targets its dedicated base. It contributes zero implementation TODOs.",
        "This snapshot precedes any later documentation-only PR and does not assert later branch counts or heads.",
    ],
    "evidence": [meta(AUDIT / "final-api.json"), meta(AUDIT / "final-api-normalized.json")],
    "implementation_todos_completed_by_this_audit": 0,
}
new(AUDIT / "final-merge-branch-issue-audit.json", report)
new(AUDIT / "final-remote-branches.json", {
    "retrieved_at": SOURCE["retrieval_finished"], "count": 118,
    "branches": report["remote_branch_inventory"]["all_names_and_shas"],
})
report_meta = meta(AUDIT / "final-merge-branch-issue-audit.json")

old_path = AUDIT / "r1-and-historical-audit.json"
old_bytes = old_path.read_bytes()
assert sha(old_bytes) == PREVIOUS
old = json.loads(old_bytes)
prior_fields = {key: value for key, value in old.items() if key != "updates"}
prior_updates = list(old["updates"])
new(AUDIT / "r1-and-historical-audit.pre-final.json", old_bytes)
for row in merges[2:]:
    old["updates"].append({
        "checkpoint": row["round"], "status": "PASS_READ_ONLY_POST_MERGE",
        "verified_at": SOURCE["retrieval_finished"], "merged_pr": row,
        "implementation_todos_completed_by_this_audit": 0, "full_receipt": report_meta,
    })
old["updates"].append({
    "checkpoint": "final-branches-and-issues",
    "status": report["status"], "verified_at": SOURCE["retrieval_finished"],
    "implementation_progress": report["implementation_progress"],
    "actual_integration": report["integration"], "main": report["main"],
    "remote_branch_count": 118, "historical_refs_retained": 8,
    "deleted_batch_heads": [row["ref"] for row in deleted],
    "verification_base_retained": report["retained_verification_base"],
    "integration_pr56_open_draft": True,
    "full_receipt": report_meta, "previous_audit": meta(AUDIT / "r1-and-historical-audit.pre-final.json"),
    "implementation_todos_completed_by_this_audit": 0,
})
assert {key: value for key, value in old.items() if key != "updates"} == prior_fields
assert old["updates"][:len(prior_updates)] == prior_updates
old_path.write_bytes(encode(old))

manifest_path = AUDIT / "recovered-files.json"
manifest_bytes = manifest_path.read_bytes()
assert sha(manifest_bytes) == OLD_MANIFEST
new(AUDIT / "recovered-files.pre-final.json", manifest_bytes)
branch_files = sorted(path for path in AUDIT.rglob("*") if path.is_file() and path != manifest_path)
assert all(not path.is_symlink() for path in branch_files)
manifest_path.write_bytes(encode({
    "schema": "recovered-final-branch-audit-files-v1",
    "scope": "Frozen final read-only branch and issue audit with prior recovery snapshots retained",
    "frozen_at": SOURCE["retrieval_finished"],
    "files": [relative_meta(path, AUDIT) for path in branch_files],
    "self_excluded": "recovered-files.json",
}))

# Do not rewrite earlier fresh recovery receipts. Their exact known bytes remain included.
assert sha((ROOT / "final-exec-go/recovered-acceptance.json").read_bytes()) == "4ce5f0bc3241aaad5e12156aea3f9ec479655a680ff4f8cddaac49629e251dc9"
assert sha((ROOT / "r1-public/recovered-r1-comparisons.json").read_bytes()) == "9a069524513df48c6977bf36bd484c198d4eb1fc257d864d82a0bf93f4f21536"
owned_scopes = ["final-exec-go", "r1-public", "branch-audit"]
all_files = sorted(path for scope in owned_scopes for path in (ROOT / scope).rglob("*") if path.is_file())
assert all(not path.is_symlink() for path in all_files)
frozen = {
    "schema": "transport-recovered-final-evidence-manifest-v1",
    "status": "FROZEN_NO_FURTHER_TRANSPORT_WRITES",
    "frozen_at": SOURCE["retrieval_finished"],
    "scope_directories": owned_scopes,
    "base_path": str(ROOT),
    "file_count": len(all_files),
    "total_bytes": sum(path.stat().st_size for path in all_files),
    "files": [relative_meta(path) for path in all_files],
    "self_excluded": "transport-final-manifest.json",
    "scope_limits": [
        "Only the three transport-owned recovered evidence directories are included; root/backend/frontend files are outside this manifest.",
        "All recovery receipts are new files based on fresh GitHub retrievals after workspace loss.",
        "The recovered final EXEC original job log matches its known pre-loss byte count and SHA256. Its full Go events were independently reparsed.",
        "Recovered R1 logs contain original printed comparison objects, not raw GoJSONL. Their 19-leaf maps are original-runner-reported, not recovered raw-event qualification.",
        "Previously lost native commit bundles, native regression packets, original local receipts and unacquired artifact ZIP bytes are not restored and are not included.",
        "No Go or PostgreSQL tests were rerun to prepare this final audit or manifest.",
    ],
}
new(ROOT / "transport-final-manifest.json", frozen)

# Read-only verification of the just-frozen manifest and append-only audit structure.
for item in frozen["files"]:
    path = ROOT / item["path"]
    actual = path.read_bytes()
    assert len(actual) == item["bytes"] and sha(actual) == item["sha256"], item["path"]
print(json.dumps({
    "status": report["status"], "completed": 10, "remaining": 0,
    "remote_branch_count": 118, "historical_refs_retained": 8,
    "main_unchanged": True, "five_batch_heads_absent": True,
    "final_receipt": report_meta, "append_only_audit": meta(old_path),
    "branch_manifest": meta(manifest_path),
    "frozen_manifest": meta(ROOT / "transport-final-manifest.json"),
    "frozen_file_count": frozen["file_count"], "frozen_total_bytes": frozen["total_bytes"],
    "no_further_transport_writes": True,
}, indent=2))
