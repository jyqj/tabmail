"""Read recovered original GitHub evidence; never execute repository tests."""
from pathlib import Path
import ast
import datetime
import hashlib
import json
import re
import sys
import yaml

ROOT = Path(__file__).resolve().parent
CAT = "6a402ce1269bfc41c932a67b592fee5bca235774"
CAT_TREE = "e8a04cbe516889f225d24ae7aed5d81d8e073650"
PUBLIC = "177ee571b194836678cc9a473f178c655326ba7c"
MERGE = "b7834bf4f0a2511467bd86db4dd5971d2305424d"
WEB_TREE = "2d5d2c44680f6a6cb2b2d1166e2923806beafcc8"
TIMESTAMP = re.compile(r"^\ufeff?\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d+Z ?", re.M)


def metadata(path):
    data = path.read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())


def read_json(path):
    return json.loads(path.read_text())


def log(path):
    raw = path.read_text()
    return TIMESTAMP.sub("", raw), [i + 1 for i, line in enumerate(raw.splitlines()) if line.startswith("\ufeff")]


def objects(text):
    decoder = json.JSONDecoder()
    result = []
    for match in re.finditer(r"^\{", text, re.M):
        try:
            obj, end = decoder.raw_decode(text, match.start())
        except json.JSONDecodeError:
            continue
        if isinstance(obj, dict):
            result.append((obj, text[match.start():end]))
    return result


def one(items):
    assert len(items) == 1, f"expected one original object, found {len(items)}"
    return items[0]


def job_checks(jobs, job_id, run_id, head, required):
    job = one([j for j in jobs["jobs"] if j["id"] == job_id])
    return job, dict(
        identity=job["run_id"] == run_id and job["head_sha"] == head,
        successful=job["status"] == "completed" and job["conclusion"] == "success",
        all_reported_steps_successful=bool(job["steps"]) and all(s["status"] == "completed" and s["conclusion"] == "success" for s in job["steps"]),
        all_required_steps_present_once=all(sum(s["name"] == name for s in job["steps"]) == 1 for name in required),
    )


def artifact_check(artifacts, name, artifact_id, run_id, head, text):
    artifact = one([a for a in artifacts["artifacts"] if a["name"] == name])
    good = (artifact["id"] == artifact_id and not artifact["expired"]
            and artifact["workflow_run"]["id"] == run_id and artifact["workflow_run"]["head_sha"] == head
            and re.fullmatch(r"sha256:[a-f0-9]{64}", artifact["digest"]) is not None
            and artifact["digest"].removeprefix("sha256:") in text
            and f"Artifact ID {artifact_id}" in text and name in text)
    return good, dict(id=artifact_id, name=name, api_digest=artifact["digest"], api_size=artifact["size_in_bytes"],
                     upload_log_digest_matches_api=True if good else False,
                     zip_downloaded=False, zip_digest_locally_verified=False)


def finish(directory, record):
    record["accepted"] = all(record["checks"].values())
    record["recovered_at_utc"] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    record["evidence_files"] = [metadata(p) for p in sorted(directory.iterdir()) if p.is_file() and p.name != "acceptance.json"]
    record["reader"] = metadata(Path(__file__))
    record["recovery_limitations"] = [
        "Original CI job logs and API metadata were fetched again; derived JSON and this acceptance report were newly generated from those raw inputs.",
        "Job log decoding removes only a timestamp prefix and its optional leading BOM. Raw UTF-8 files remain unchanged.",
        "Artifact identity and digests are corroborated by API metadata and upload logs; no ZIP was downloaded or locally digest-verified.",
        "Lost native 129-test logs, local 875-test failure traces, old local review files and continuous poll snapshots were not reconstructed from conversation summaries.",
        "No original tests, collectors or runners were re-executed during recovery; no new TODO credit or issue-completion claim is granted.",
    ]
    record["todo_credit"] = 0
    (directory / "acceptance.json").write_text(json.dumps(record, ensure_ascii=False, indent=2) + "\n")
    return record


def catalog():
    d = ROOT / "catalog257"
    source, source_boms = log(d / "source-version.log")
    inventory, inventory_boms = log(d / "inventory.log")
    source_objects, inventory_objects = objects(source), objects(inventory)
    report, report_text = one([(o, text) for o, text in source_objects if "groups" in o and "discovered_test_ids" in o])
    (d / "source-version.json").write_text(report_text + "\n")
    sources = [[o for o, _ in entries if set(o) == {"commit", "tree", "status"}] for entries in (source_objects, inventory_objects)]
    expected_source = dict(commit=CAT, tree=CAT_TREE, status="")
    checks = dict(
        source_raw_matches_pre_loss_identity=metadata(d / "source-version.log")["bytes"] == 5187696 and metadata(d / "source-version.log")["sha256"] == "fb6488c5ae551b3736bd004975680e12a5a419117f61fce48c8b94ffe7bc6c1b",
        inventory_raw_matches_pre_loss_identity=metadata(d / "inventory.log")["bytes"] == 95480 and metadata(d / "inventory.log")["sha256"] == "abcb089c831d312cb0eb7cbfb854a7efce63606e44334138db646088421a0076",
        both_jobs_direct_exact_clean_source_before_after=all(items == [expected_source, expected_source] for items in sources),
        report_schema_and_status=report.get("schema_version") == 1 and report.get("status") == "pass",
        no_preparation_error=report.get("preparation_error") in (None, ""),
        all_original_dispatch_flags_true=all(report.get(k) is True for k in ("dispatch_no_missing", "dispatch_no_overlap", "no_missing", "no_overlap")),
        original_missing_list_empty=report.get("missing_test_ids") == [],
    )
    discovered = report["discovered_test_ids"]
    checks["discovered_875_unique"] = len(discovered) == len(set(discovered)) == 875
    runner = ast.parse((d / "original-source-version-runner.py").read_text())
    baseline_node = one([n for n in runner.body if isinstance(n, ast.Assign) and any(isinstance(t, ast.Name) and t.id == "BASELINE" for t in n.targets)])
    historical_node = one([n for n in runner.body if isinstance(n, ast.Assign) and any(isinstance(t, ast.Name) and t.id == "HISTORICAL_IDS" for t in n.targets)])
    baseline = ast.literal_eval(baseline_node.value)
    generator = historical_node.value.args[0]
    historical_ids = {ast.literal_eval(generator.elt.left) + name for name in ast.literal_eval(generator.generators[0].iter)}
    groups = report["groups"]
    checks["exact_two_original_groups"] = [g["group"] for g in groups] == ["current", "frozen-v1"]
    all_actual, all_requested, group_summaries = [], [], []
    for group, expected_count, expected_sha in zip(groups, (871, 4), (CAT, baseline), strict=True):
        rep, requested = group["report"], group["requested_test_ids"]
        loaded, actual = rep["loaded_test_ids"], rep["actual_test_ids"]
        name = group["group"]
        checks[name + "_source_and_exit"] = group["source_sha"] == rep["source_sha"] == expected_sha and group["exit"] == 0
        checks[name + "_exact_requested_loaded_started"] = requested == loaded == actual and len(actual) == len(set(actual)) == rep["tests_run"] == expected_count
        checks[name + "_no_failure_error_skip_or_missing"] = all(rep.get(k) == [] for k in ("missing_test_ids", "failures", "errors", "skips", "expected_failures", "unexpected_successes"))
        checks[name + "_original_partition"] = (set(actual) == historical_ids if name == "frozen-v1" else set(actual).isdisjoint(historical_ids))
        all_actual.extend(actual)
        all_requested.extend(requested)
        group_summaries.append(dict(group=name, source_sha=expected_sha, tests=expected_count, child_exit=group["exit"], failures=len(rep["failures"]), errors=len(rep["errors"]), skips=len(rep["skips"])))
    checks["full_union_no_missing_extra_or_overlap"] = (len(all_actual) == len(set(all_actual)) == len(all_requested) == 875 and set(all_actual) == set(all_requested) == set(discovered))
    checks["both_original_unittest_terminals_ok"] = re.findall(r"^Ran (\d+) tests in [^\n]+\n\nOK$", source, re.M) == ["871", "4"]
    prep = report["preparation"]
    checks["original_preparation_success_bound_to_source"] = prep["source_sha"] == CAT and prep["exit"] == 0 and prep["go_version"] == "go1.25.7" and prep["go_selection_unchanged"] is True and prep["actual_started_test_ids"] == prep["actual_passed_test_ids"] == ["TestOrdinaryReceiptOpenAPIWireFixtures"]
    verbose = re.findall(r"^(test\S+) \(([^)]+)\) \.\.\. (.+)$", inventory, re.M)
    checks["inventory_106_unique_all_ok"] = len(verbose) == len({v[1] for v in verbose}) == 106 and all(v[2] == "ok" for v in verbose) and re.findall(r"^Ran (\d+) tests in [^\n]+\n\nOK$", inventory, re.M) == ["106"]
    module_counts = {m: sum(v[1].startswith(m + ".") for v in verbose) for m in sorted({v[1].split(".")[0] for v in verbose})}
    checks["exact_five_original_inventory_modules"] = module_counts == dict(test_r5_catalog_reconciliation=39, test_r5_compatibility=19, test_r5_current_source_inventory=15, test_r5_reviewed_web_locks=7, test_r5_transactions=26)
    tx = one([o for o, _ in inventory_objects if "postgres_files" in o])
    compatibility = one([o for o, _ in inventory_objects if "wire_validation_scope" in o])
    checks["original_three_cli_outputs"] = tx["status"] == "PASS" and compatibility["status"] == "source_inventory_and_upgrade_plan_checked" and "API client inventory PASS: 137 branches, 7 explicit transport forwarders" in inventory
    checks["original_unfinished_qualification_preserved"] = tx["task_complete"] is False and tx["runtime_verified"] is False and compatibility["task_complete"] is False and compatibility["product_green"] is False
    run, jobs, artifacts, commit = (read_json(d / f) for f in ("run.json", "jobs.json", "artifacts.json", "commit.json"))
    checks["api_run_and_commit_tree"] = run["id"] == 37986871640 and run["head_sha"] == commit["sha"] == CAT and commit["tree"]["sha"] == CAT_TREE and run["status"] == "completed" and run["conclusion"] == "success" and run["run_attempt"] == 1
    workflow = yaml.load((d / "original-workflow.yml").read_text(), Loader=yaml.BaseLoader)
    job_receipts = []
    for key, job_id in (("inventory", 114011053321), ("source-version", 114011053379)):
        required = [s["name"] for s in workflow["jobs"][key]["steps"] if "name" in s]
        job, values = job_checks(jobs, job_id, run["id"], CAT, required)
        checks.update({key + "_job_" + k: v for k, v in values.items()})
        job_receipts.append(dict(id=job_id, name=key, required_steps=required, conclusion=job["conclusion"]))
        checks[key + "_original_direct_head_checkout"] = workflow["jobs"][key]["steps"][0]["with"]["ref"] == "${{ github.event.pull_request.head.sha || github.sha }}"
    proposal = one([j for j in jobs["jobs"] if j["name"] == "proposal"])
    checks["proposal_skip_reported_without_pass_credit"] = proposal["conclusion"] == "skipped"
    artifact_receipts = []
    for name, aid, text in (("catalog16-source-version-37986871640-1", 11644752912, source), ("catalog16-inventory-37986871640-1", 11644268136, inventory)):
        good, receipt = artifact_check(artifacts, name, aid, run["id"], CAT, text)
        checks[name + "_artifact_api_and_upload_log_binding"] = good
        artifact_receipts.append(receipt)
    return finish(d, dict(schema="recovered-catalog257-acceptance-v1", checks=checks, original_run_id=run["id"], source=expected_source, groups=group_summaries,
                         invocation_semantics="actual_test_ids records startTest calls; exact invocation lists plus normally completed children and zero failure events establish this pass. No per-ID stopTest receipt is claimed.",
                         inventory=dict(tests=106, module_counts=module_counts, original_clis=3), jobs=job_receipts,
                         proposal=dict(job_id=proposal["id"], conclusion="skipped", pass_credit=False), artifacts=artifact_receipts,
                         optional_bom_prefix_lines=dict(source_version=source_boms, inventory=inventory_boms)))


def web():
    d = ROOT / "final-exec-web"
    text, boms = log(d / "web.log")
    result, result_text = one([(o, block) for o, block in objects(text) if "testResults" in o and "numTotalTests" in o])
    (d / "vitest.json").write_text(result_text + "\n")
    run, jobs, artifacts, merge, public = (read_json(d / f) for f in ("run.json", "jobs.json", "artifacts.json", "merge-commit.json", "public-commit.json"))
    workflow = yaml.load((d / "original-workflow.yml").read_text(), Loader=yaml.BaseLoader)
    expected_steps = [s["name"] for s in workflow["jobs"]["web-regressions"]["steps"] if "name" in s]
    job, checks = job_checks(jobs, 114007319923, 37985791844, PUBLIC, expected_steps + ["Run npm ci", "Run actions/upload-artifact@v4"])
    checks["api_run_public_head"] = run["id"] == 37985791844 and run["head_sha"] == PUBLIC and run["status"] == "completed" and run["conclusion"] == "success" and run["run_attempt"] == 1
    checks["actual_merge_source_record_and_tree_equivalence"] = (f"\n{MERGE}\n{WEB_TREE}\n" in text and merge["sha"] == MERGE and public["sha"] == PUBLIC and merge["tree"]["sha"] == public["tree"]["sha"] == WEB_TREE and PUBLIC in [p["sha"] for p in merge["parents"]])
    checks["complete_nonincremental_typecheck"] = "npx tsc --noEmit --incremental false" in text and one([s for s in job["steps"] if s["name"] == "Complete TypeScript check"])["conclusion"] == "success"
    checks["original_vitest_top_level_229_pass"] = result["success"] is True and result["numTotalTests"] == result["numPassedTests"] == 229 and all(result[k] == 0 for k in ("numFailedTests", "numPendingTests", "numTodoTests", "numFailedTestSuites", "numPendingTestSuites"))
    test_step = one([s for s in workflow["jobs"]["web-regressions"]["steps"] if s.get("name") == "Mailbox lifecycle, ownership, rich drafts and explicit route regressions"])
    expected_files = re.findall(r"^\s+((?:components|features|lib)/\S+\.test\.tsx?)\s+\\$", test_step["run"], re.M)
    actual_files = [r["name"].split("/web/", 1)[1] for r in result["testResults"]]
    assertions = [(r["name"], a) for r in result["testResults"] for a in r["assertionResults"]]
    checks["exact_original_15_file_list"] = len(expected_files) == len(actual_files) == len(set(actual_files)) == 15 and set(expected_files) == set(actual_files)
    checks["all_229_unique_assertions_passed"] = len(assertions) == len({(name, a["fullName"]) for name, a in assertions}) == 229 and all(a["status"] == "passed" and not a.get("failureMessages") for _, a in assertions)
    checks["all_15_file_results_passed"] = all(r["status"] == "passed" for r in result["testResults"])
    good, artifact = artifact_check(artifacts, "exec-web-regressions", 11644124056, run["id"], PUBLIC, text)
    checks["artifact_api_and_upload_log_binding"] = good
    return finish(d, dict(schema="recovered-exec-web-acceptance-v1", checks=checks, original_run_id=run["id"], original_job_id=job["id"],
                         source=dict(public_head=PUBLIC, actual_checkout=MERGE, tree=WEB_TREE, tree_equals_public_head=True, before_clean_status="not recorded", after_snapshot="not recorded", source_stability_claim=False),
                         tests=dict(assertions=229, files=15, original_report_suite_count=result["numTotalTestSuites"], passed_suite_count=result["numPassedTestSuites"], pending=0, todo=0, per_file=[dict(path=p, assertions=len(r["assertionResults"])) for p, r in zip(actual_files, result["testResults"], strict=True)]),
                         typecheck="npx tsc --noEmit --incremental false", required_steps=expected_steps, artifact=artifact, optional_bom_prefix_lines=boms,
                         scope="Original EXEC web job only. Its 15 files do not include the newly added tenant/index files; no new execution of the lost native 129-test suite is claimed."))


if __name__ == "__main__":
    reports = [catalog(), web()]
    for report, directory in zip(reports, ("catalog257", "final-exec-web"), strict=True):
        print(json.dumps(dict(directory=directory, accepted=report["accepted"], checks=len(report["checks"]), failed_checks=[k for k, v in report["checks"].items() if not v], acceptance=metadata(ROOT / directory / "acceptance.json"))))
    raise SystemExit(0 if all(r["accepted"] for r in reports) else 1)
