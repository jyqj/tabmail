"""Accept the newly recorded exact-source native run, without re-running tests."""
from pathlib import Path
import datetime
import hashlib
import json
import subprocess
import sys

OUT = Path(__file__).resolve().parent
ROOT = Path('/workspace/scratch/831fbd171897/tabmail-frontend-native-recovery')


def read(name):
    return json.loads((OUT / name).read_text())


def meta(path):
    raw = path.read_bytes()
    return dict(path=str(path), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())


before, after, execution, selection, result = (read(n) for n in ('source-before.json', 'source-after.json', 'execution.json', 'selection.json', 'vitest-results.json'))
expected = dict(commit='177ee571b194836678cc9a473f178c655326ba7c', tree='2d5d2c44680f6a6cb2b2d1166e2923806beafcc8', web_tree='b2eed55730431ff50443c6ebf331e173c4762a73')
checks = dict(
    exact_public_source=all(before[k] == expected[k] for k in expected),
    source_clean_before_after=before['status'] == after['status'] == '',
    all_source_and_protected_bytes_unchanged=before == after == execution['before'] == execution['after'] and execution['source_stable'] is True,
    exact_nine_requested_files=len(selection['files']) == len(set(selection['files'])) == 9,
    all_five_commands_completed_once=[r['name'] for r in execution['records']] == ['node-version', 'npm-version', 'npm-ci', 'vitest', 'tsc'],
    original_commands_succeeded=all(r['exit'] == 0 and not r.get('timeout') for r in execution['records']),
    execution_receipt_has_actual_test_commands=execution['required_test_commands_executed'] is True and execution['all_commands_exit_zero'] is True,
    vitest_top_level_129_pass=result['success'] is True and result['numTotalTests'] == result['numPassedTests'] == 129,
    no_failed_pending_todo=result['numFailedTests'] == result['numPendingTests'] == result['numTodoTests'] == result['numFailedTestSuites'] == result['numPendingTestSuites'] == 0,
)
files = [str(Path(item['name']).relative_to(ROOT / 'web')) for item in result['testResults']]
assertions = [(item['name'], assertion) for item in result['testResults'] for assertion in item['assertionResults']]
checks['exact_actual_file_selection'] = len(files) == len(set(files)) == 9 and set(files) == set(selection['files'])
checks['all_129_distinct_assertions_passed'] = len(assertions) == len({(file, assertion['fullName']) for file, assertion in assertions}) == 129 and all(a['status'] == 'passed' and not a.get('failureMessages') for _, a in assertions)
checks['all_nine_file_results_passed'] = all(item['status'] == 'passed' for item in result['testResults'])
commands = {r['name']: r for r in execution['records']}
checks['full_nonincremental_tsc_argv'] = commands['tsc']['argv'] == [str(ROOT / 'web/node_modules/.bin/tsc'), '--noEmit', '--incremental', 'false']
checks['normal_npm_ci'] = commands['npm-ci']['argv'] == ['npm', 'ci']
checks['vitest_exact_argv'] = commands['vitest']['argv'] == [str(ROOT / 'web/node_modules/.bin/vitest'), 'run', *selection['files'], '--reporter=json', '--outputFile=' + str(OUT / 'vitest-results.json')]
checks['every_command_uses_pinned_web_cwd'] = all(r['cwd'] == str(ROOT / 'web') for r in execution['records'])
public_hashes = {name: hashlib.sha256(subprocess.check_output(['git', '-C', str(ROOT), 'show', expected['commit'] + ':web/' + name])).hexdigest() for name in before['protected_sha256']}
checks['all_protected_files_equal_public_git_blobs'] = public_hashes == before['protected_sha256']
checks['live_source_still_exact_clean'] = subprocess.check_output(['git', '-C', str(ROOT), 'rev-parse', 'HEAD', 'HEAD^{tree}', 'HEAD:web'], text=True).splitlines() == [expected['commit'], expected['tree'], expected['web_tree']] and subprocess.check_output(['git', '-C', str(ROOT), 'status', '--porcelain', '--untracked-files=all'], text=True) == ''
dependencies = {name: json.loads((ROOT / 'web/node_modules' / name / 'package.json').read_text())['version'] for name in ('vitest', 'typescript', 'next', 'react', 'react-dom')}
report = dict(
    schema='native129-final-public-source-reexecution-acceptance-v1',
    accepted=all(checks.values()), checks=checks, accepted_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    execution_kind='New single execution at public 177ee571 after temporary evidence loss; not a reconstruction or rerun attributed to old native 16b6661.',
    source=before, source_after=after, environment=dict(node=(OUT / 'node-version.stdout').read_text().strip(), npm=(OUT / 'npm-version.stdout').read_text().strip(), locked_installed_dependencies=dependencies),
    tests=dict(assertions=129, files=9, pending=0, todo=0, per_file=[dict(path=path, assertions=len(item['assertionResults'])) for path, item in zip(files, result['testResults'], strict=True)]),
    full_typecheck=commands['tsc'], commands=execution['records'],
    evidence_files=[meta(p) for p in sorted(OUT.iterdir()) if p.is_file() and p.name != 'acceptance.json'],
    limits=['Historical native 16b6661 raw output remains lost; this report grants only the new final-public-source run.', 'Original fixed baseline failure logs were not regenerated in this scope.', 'Original EXEC 229 is a different file selection; it is not counted as execution of these nine suites.'],
    todo_credit=0, product_tests_or_lockfile_modified=False,
)
(OUT / 'acceptance.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
print(json.dumps(dict(accepted=report['accepted'], failed_checks=[k for k, v in checks.items() if not v], checks=len(checks), per_file=report['tests']['per_file'], report=meta(OUT / 'acceptance.json'))))
raise SystemExit(0 if report['accepted'] else 1)
