"""One new, source-pinned native verification after loss of historical raw logs."""
from pathlib import Path
import datetime
import hashlib
import json
import subprocess
import sys
import time

ROOT = Path('/workspace/scratch/831fbd171897/tabmail-frontend-native-recovery')
OUT = Path(__file__).resolve().parent
COMMIT = '177ee571b194836678cc9a473f178c655326ba7c'
TREE = '2d5d2c44680f6a6cb2b2d1166e2923806beafcc8'
WEBTREE = 'b2eed55730431ff50443c6ebf331e173c4762a73'
FILES = [
    'app/(dashboard)/admin/tenants/page.test.tsx',
    'app/(dashboard)/admin/tenants/api-keys-requests.test.tsx',
    'app/(dashboard)/admin/tenants/override-snapshot.test.tsx',
    'app/(dashboard)/admin/tenants/tenant-create-ownership.test.tsx',
    'app/(dashboard)/admin/tenants/tenant-create-session-reset.test.tsx',
    'app/(dashboard)/admin/tenants/tenant-delete-ownership.test.tsx',
    'features/company/overview.test.tsx',
    'features/company/overview-recovery-receipt.test.tsx',
    'features/company/overview-read-denial.test.tsx',
]
PROTECTED = FILES + ['package.json', 'package-lock.json', 'tsconfig.json', 'vitest.config.ts', 'vitest.setup.ts',
                     'app/(dashboard)/admin/tenants/page.tsx', 'features/company/overview.tsx']


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def git(*args):
    return subprocess.check_output(['git', '-C', str(ROOT), *args], text=True).strip()


def snapshot():
    return dict(commit=git('rev-parse', 'HEAD'), tree=git('rev-parse', 'HEAD^{tree}'),
                web_tree=git('rev-parse', 'HEAD:web'), status=git('status', '--porcelain', '--untracked-files=all'),
                protected_sha256={p: hashlib.sha256((ROOT / 'web' / p).read_bytes()).hexdigest() for p in PROTECTED})


def write(name, value):
    (OUT / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


def command(name, argv, timeout):
    receipt = dict(name=name, argv=argv, cwd=str(ROOT / 'web'), started_at=now())
    print(json.dumps(dict(event='start', **receipt)), flush=True)
    start = time.monotonic()
    with (OUT / (name + '.stdout')).open('wb') as stdout, (OUT / (name + '.stderr')).open('wb') as stderr:
        try:
            result = subprocess.run(argv, cwd=ROOT / 'web', stdout=stdout, stderr=stderr, timeout=timeout, check=False)
            receipt['exit'] = result.returncode
        except subprocess.TimeoutExpired:
            receipt.update(exit=None, timeout=True)
    receipt.update(ended_at=now(), elapsed_seconds=time.monotonic() - start)
    write(name + '.json', receipt)
    print(json.dumps(dict(event='end', **receipt)), flush=True)
    return receipt


if __name__ == '__main__':
    OUT.mkdir(parents=True, exist_ok=True)
    before = snapshot()
    write('source-before.json', before)
    assert before['commit'] == COMMIT and before['tree'] == TREE and before['web_tree'] == WEBTREE and not before['status']
    write('selection.json', dict(files=FILES, expected_assertions=129, original_selection_basis='Final public source contains the six tenant and three overview related suites; the pre-loss PR256 review records 129 assertions across nine files.',
                                 execution_kind='new execution at final public 177ee571; not replay of lost native 16b6661 raw output', todo_credit=0))
    records = []
    try:
        records.append(command('node-version', ['node', '--version'], 30))
        records.append(command('npm-version', ['npm', '--version'], 30))
        records.append(command('npm-ci', ['npm', 'ci'], 600))
        if records[-1]['exit'] == 0:
            records.append(command('vitest', [str(ROOT / 'web/node_modules/.bin/vitest'), 'run', *FILES, '--reporter=json', '--outputFile=' + str(OUT / 'vitest-results.json')], 300))
            records.append(command('tsc', [str(ROOT / 'web/node_modules/.bin/tsc'), '--noEmit', '--incremental', 'false'], 300))
    finally:
        after = snapshot()
        write('source-after.json', after)
        write('execution.json', dict(records=records, before=before, after=after, source_stable=before == after, all_commands_exit_zero=all(r['exit'] == 0 for r in records), required_test_commands_executed=all(any(r['name'] == n for r in records) for n in ('vitest', 'tsc'))))
    raise SystemExit(0 if before == after and all(r['exit'] == 0 for r in records) and all(any(r['name'] == n for r in records) for n in ('vitest', 'tsc')) else 1)
