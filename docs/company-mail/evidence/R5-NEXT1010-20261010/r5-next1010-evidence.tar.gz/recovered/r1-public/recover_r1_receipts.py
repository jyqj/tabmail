#!/usr/bin/env python3
"""Recover public R1 comparison receipts, without inventing absent Go streams."""
import ast
import hashlib
import json
from pathlib import Path
import re
import traceback

ROOT = Path(__file__).resolve().parent
BASE = '74d5fc72f7ad2e086bd3060b78c548dc302d0408'
BASE_TREE = '5cbe43bbdda6601a8bfca79e5ae9d1f83db7b95c'
HEAD = 'b458e917c6b084fbc557f351f03ca762b1c11924'
CI = '7564295a786b50ae80e3b45ca221463b04c237e1'
MERGED = 'a6a0090fc069d131213b559f94c669184525f312'
TREE = '8dba655927b80a1e5ee66228fd3d29bab3a8bee2'
CASES = {'refresh': ('refresh-issuance', 113998462652, 9, 6, 3), 'audit': ('permission-audit', 113998462514, 10, 4, 6)}

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def canonical(obj):
    return (json.dumps(obj, ensure_ascii=False, indent=2) + '\n').encode()

def dec(raw):
    value = raw.get('structuredContent', raw)
    if isinstance(value.get('content'), str):
        try:
            return json.loads(value['content'])
        except json.JSONDecodeError:
            pass
    return value

def pin(path):
    path = Path(path)
    raw = path.read_bytes()
    return dict(path=str(path), bytes=len(raw), sha256=sha(raw))

def clean_lines(raw):
    return [re.sub(r'\x1b\[[0-9;]*m', '', re.sub(r'^\d{4}-\d\d-\d\dT\d\d:\d\d:\d\d\.\d+Z ?', '', line)) for line in raw.decode().splitlines()]

result = dict(schema='recovered-r1-public-comparison-receipts-v1', findings=[], implementation_todos_completed=0, local_pg_or_go_reexecuted=False)

def main():
    primary = json.loads((ROOT / 'primary-api.json').read_text())
    api = {name: dec(raw) for name, raw in primary['responses'].items()}
    assert api['pr254']['state'] == 'closed' and api['pr254']['merged'] is True
    assert api['pr254']['head']['sha'] == HEAD and api['pr254']['merge_commit_sha'] == MERGED
    assert api['merge254']['sha'] == MERGED and api['merge254']['tree']['sha'] == TREE
    assert api['pg_source']['sha'] == CI and api['pg_source']['tree']['sha'] == TREE
    for name in ['merge254', 'pg_source']:
        assert [p['sha'] for p in api[name]['parents']] == ['ffb22b64698e4ff168a8d622018d3e169b3cdf07', HEAD]
    run = api['pg_run']
    assert run['id'] == 37983162903 and run['head_sha'] == HEAD
    assert run['status'] == 'completed' and run['conclusion'] == 'success'
    sources = json.loads((ROOT / 'source-api.json').read_text())
    assert sources['public_product_source'] == HEAD
    baseline = dec(sources['responses']['baseline']['raw'])
    assert baseline['sha'] == BASE and baseline['tree']['sha'] == BASE_TREE
    source_pins = {}
    source_text = {}
    for name, row in sources['responses'].items():
        if name == 'baseline':
            continue
        content = dec(row['raw'])['content'].encode()
        path = ROOT / 'source' / row['path']
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(content)
        source_pins[row['path']] = pin(path)
        source_text[name] = content.decode()
    tree = ast.parse(source_text['runner'])
    const = {n.targets[0].id: ast.literal_eval(n.value) for n in tree.body if isinstance(n, ast.Assign) and isinstance(n.targets[0], ast.Name) and n.targets[0].id in ['BASELINE', 'CASES']}
    assert const['BASELINE'] == BASE and set(const['CASES']) == {c[0] for c in CASES.values()}
    assert 'case: [refresh-issuance, permission-audit]' in source_text['workflow']
    assert 'image: postgres:16' in source_text['workflow']
    assert 'python3 -B scripts/run_r5_next1010_pg.py --candidate .' in source_text['workflow']
    assert 'go-test.jsonl' not in source_text['workflow'], 'This original workflow did not print original Go streams'
    jobs = {j['id']: j for j in api['pg_jobs']['jobs']}
    cases = {}
    all_leaf_keys = set()
    for label, (case, job_id, expected, old_pass, old_fail) in CASES.items():
        job = jobs[job_id]
        assert job['name'] == 'postgres-regressions (' + case + ')'
        assert job['status'] == 'completed' and job['conclusion'] == 'success'
        assert all(s['status'] == 'completed' and s['conclusion'] == 'success' for s in job['steps'])
        log_path = ROOT / (label + '-job' + str(job_id) + '-decoded.log')
        log = log_path.read_bytes()
        lines = clean_lines(log)
        assert [line for line in lines if re.fullmatch('[a-f0-9]{40}', line)] == [CI]
        assert 'go version go1.25.7 linux/amd64' in lines
        assert 'DATA RACE' not in log.decode()
        objects = []
        for line in lines:
            if line.startswith('{'):
                try:
                    objects.append((line, json.loads(line)))
                except json.JSONDecodeError:
                    pass
        assert not any('Action' in row and 'Package' in row for _, row in objects)
        reports = [(line, row) for line, row in objects if set(row) == {'baseline', 'candidate', 'case'}]
        assert len(reports) == 1
        printed, report = reports[0]
        assert report['case'] == case
        paths, package, pattern, declared_count = const['CASES'][case]
        assert declared_count == expected
        expected_hashes = {path: source_pins[path]['sha256'] for path in paths}
        command = ['go', 'test', '-mod=readonly', '-race', '-count=1', '-timeout=180s', '-json', package, '-run', pattern]
        for phase in ['baseline', 'candidate']:
            row = report[phase]
            assert row['command'] == command and row['source_stable'] is True
            assert row['source_before'] == row['source_after']
            assert row['source_before']['regression_sha256'] == expected_hashes
            assert row['all_skips'] == 0 and row['missing_terminals'] == []
            assert len(row['leaves']) == expected
            assert row['pass'] == sum(v == 'pass' for v in row['leaves'].values())
            assert row['fail'] == sum(v == 'fail' for v in row['leaves'].values())
            assert re.fullmatch('[a-f0-9]{64}', row['log_sha256'])
        old, new = report['baseline'], report['candidate']
        assert old['source_before']['commit'] == BASE and old['source_before']['tree'] == BASE_TREE
        assert old['source_before']['status'].splitlines() == ['?? ' + path for path in sorted(paths)]
        assert new['source_before']['commit'] == CI and new['source_before']['tree'] == TREE and not new['source_before']['status']
        assert (old['pass'], old['fail'], old['exit_code']) == (old_pass, old_fail, 1)
        assert (new['pass'], new['fail'], new['exit_code']) == (expected, 0, 0)
        assert set(old['leaves']) == set(new['leaves'])
        assert all(value == 'pass' for value in new['leaves'].values())
        assert new['failure_output'] == {}
        keys = {(package, name) for name in new['leaves']}
        assert not (all_leaf_keys & keys)
        all_leaf_keys.update(keys)
        printed_path = ROOT / (label + '-original-stdout-comparison.json')
        printed_path.write_text(printed + '\n')
        cases[case] = dict(job_id=job_id, api_conclusion='success', printed_receipt=pin(printed_path), original_job_log=pin(log_path), command=command, fixed_source_hashes=expected_hashes, baseline=dict(commit=BASE, tree=BASE_TREE, pass_count=old_pass, fail=old_fail, exit_code=1, reported_raw_go_jsonl_sha256=old['log_sha256']), candidate=dict(commit=CI, tree=TREE, pass_count=expected, fail=0, exit_code=0, reported_raw_go_jsonl_sha256=new['log_sha256']), complete_leaf_names=sorted(new['leaves']), identical_baseline_candidate_leaf_maps=True, source_stable_and_no_skips_or_missing_as_reported_by_original_runner=True, raw_go_event_stream_recovered=False)
    assert len(all_leaf_keys) == 19
    result['status'] = 'RECOVERED_ORIGINAL_R1_PUBLIC_COMPARISONS_19_LEAVES'
    result['retrieved_at'] = primary['retrieved_at']
    result['public_source'] = dict(head=HEAD, actual_ci_checkout=CI, merged_commit=MERGED, complete_tree=TREE, matching_api_parents=['ffb22b64698e4ff168a8d622018d3e169b3cdf07', HEAD])
    result['cases'] = cases
    result['total_candidate_leaf_names'] = 19
    result['total_unique_package_test_leaf_names'] = 19
    result['source_pins'] = source_pins
    result['api_evidence'] = [pin(ROOT / 'primary-api.json'), pin(ROOT / 'source-api.json'), pin(ROOT / 'log-retrieval.json'), pin(ROOT / 'artifacts-api.json')]
    result['artifact_metadata'] = dict(api_reported=dec(json.loads((ROOT / 'artifacts-api.json').read_text())['response']), zip_downloaded=False, zip_or_raw_go_jsonl_digests_locally_verified=False)
    result['recovery_boundary'] = ['Both complete original job logs and the original runner comparison objects are freshly recovered from GitHub.', 'The old workflow did not print original Go JSONL streams. Its log_sha256 values are original-runner-reported hashes, not newly computed hashes of recovered Go event files.', 'The public comparison leaf maps, source identities, frozen file hashes, commands, process exits, and reported skip/missing counters are independently checked for consistency with newly retrieved public source.', 'No event-level package-terminal or duplicate-event check can be reconstructed from these logs alone. No native test packet, previous receipt file, commit bundle, or artifact ZIP is claimed restored.']

try:
    main()
except BaseException as error:
    result['status'] = 'RECOVERY_REVIEW_FAILED'
    result['findings'].append(dict(type=type(error).__name__, message=str(error), traceback=traceback.format_exc()))
finally:
    result['recovery_script_sha256'] = sha(Path(__file__).read_bytes())
    (ROOT / 'recovered-r1-comparisons.json').write_bytes(canonical(result))
    print(json.dumps({key: result[key] for key in ['status', 'total_candidate_leaf_names', 'total_unique_package_test_leaf_names', 'findings', 'recovery_script_sha256'] if key in result}, indent=2))
if result['status'] != 'RECOVERED_ORIGINAL_R1_PUBLIC_COMPARISONS_19_LEAVES':
    raise SystemExit(1)
