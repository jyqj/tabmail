#!/usr/bin/env python3
"""Rebuild a new receipt only from freshly recovered GitHub source and logs."""
import collections
import hashlib
import json
from pathlib import Path
import re
import traceback

ROOT = Path(__file__).resolve().parent
SOURCE = '177ee571b194836678cc9a473f178c655326ba7c'
TREE = '2d5d2c44680f6a6cb2b2d1166e2923806beafcc8'
MERGE = 'b7834bf4f0a2511467bd86db4dd5971d2305424d'
DEBUG = 'github.com/emersion/go-smtp/cmd/smtp-debug-server'
EXPECTED = {'packages': 1745, 'settings': 11, 'http': 89, 'pre-sql': 12}
EXPECTED_PACKAGES = {
    'packages': ['tabmail/internal/company', 'tabmail/internal/app/templates', 'tabmail/internal/app/admin', 'tabmail/internal/smtp', 'tabmail/internal/outbound', 'github.com/emersion/go-smtp', DEBUG],
    'settings': ['tabmail/internal/settings'], 'http': ['tabmail/internal/api/handlers'], 'pre-sql': ['tabmail/internal/store/postgres'],
}
EXPECTED_FILES = {
    'dns': '222ae447585041c224107d2e3ac158e20f0165e78c20ba8113b50019112ddaa6',
    'tls': '556495447450bff33d79a713e61496b329236596c024f0b101ba8c30af50c3e0',
}

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def canonical(obj):
    return (json.dumps(obj, ensure_ascii=False, indent=2, allow_nan=False) + '\n').encode()

def decode(raw):
    value = raw.get('structuredContent', raw)
    if isinstance(value.get('content'), str):
        try:
            return json.loads(value['content'])
        except json.JSONDecodeError:
            pass
    return value

def pin(path):
    path = Path(path)
    raw = path.read_bytes()
    return dict(path=str(path), bytes=len(raw), sha256=sha(raw))

def clean(raw):
    return [re.sub(r'\x1b\[[0-9;]*m', '', re.sub(r'^\d{4}-\d\d-\d\dT\d\d:\d\d:\d\d\.\d+Z ?', '', line)) for line in raw.decode().splitlines()]

def parse(lines):
    phase = None
    events = collections.defaultdict(list)
    raw_lines = collections.defaultdict(list)
    phases_seen = []
    for line in lines:
        if line.startswith('##[group]Run set -euo pipefail'):
            phase = None
        match = re.search(r'tee exec-evidence/(packages|settings|http|pre-sql)\.jsonl', line)
        if match:
            phase = match.group(1)
            phases_seen.append(phase)
        if line.startswith('{'):
            try:
                event = json.loads(line)
            except json.JSONDecodeError:
                continue
            if 'Action' in event and 'Package' in event:
                assert phase is not None
                events[phase].append(event)
                raw_lines[phase].append(line)
    return dict(events), dict(raw_lines), phases_seen

def tests(events):
    starts = collections.Counter((e['Package'], e['Test']) for e in events if e.get('Test') and e['Action'] == 'run')
    terminals = collections.defaultdict(list)
    for event in events:
        if event.get('Test') and event['Action'] in ['pass', 'fail', 'skip']:
            terminals[(event['Package'], event['Test'])].append(event['Action'])
    names = set(starts) | set(terminals)
    leaves = {key for key in names if not any(p == key[0] and t.startswith(key[1] + '/') for p, t in names)}
    return starts, terminals, names, leaves

result = dict(schema='recovered-final-exec-go-acceptance-v1', recovery=True, findings=[], implementation_todos_completed=0, scope='New independent parsing receipt from freshly fetched GitHub job logs, API records and public source after workspace loss. No repository checkout, Go rerun, fabricated log, or reconstruction of unavailable native bundles.')

def main():
    api_raw = json.loads((ROOT / 'api.json').read_text())
    api = {key: decode(value) for key, value in api_raw['responses'].items()}
    result['retrieved_at'] = api_raw['retrieved_at']
    run = api['run']
    assert run['id'] == 37985791844 and run['head_sha'] == SOURCE
    assert run['status'] == 'completed' and run['conclusion'] == 'success'
    assert run['head_commit']['tree_id'] == TREE
    job = next(j for j in api['jobs']['jobs'] if j['id'] == 114007320268)
    assert job['name'] == 'go-regressions' and job['status'] == 'completed' and job['conclusion'] == 'success'
    assert job['steps'] == api['steps']['steps'] and len(job['steps']) == 12
    assert all(s['status'] == 'completed' and s['conclusion'] == 'success' for s in job['steps'])
    merge = api['merge']
    assert merge['sha'] == MERGE and merge['tree']['sha'] == TREE
    assert [p['sha'] for p in merge['parents']] == ['ffb22b64698e4ff168a8d622018d3e169b3cdf07', SOURCE]
    source_api = json.loads((ROOT / 'source-api.json').read_text())
    assert source_api['source'] == SOURCE
    source_files = []
    for name, row in source_api['responses'].items():
        content = decode(row['raw'])['content'].encode()
        if name in EXPECTED_FILES:
            assert sha(content) == EXPECTED_FILES[name]
        path = ROOT / 'source' / row['path']
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(content)
        source_files.append(dict(**pin(path), repository_path=row['path'], public_ref=SOURCE, recovered_from=decode(row['raw']).get('url')))
    raw_path = ROOT / 'job114007320268-decoded.log'
    raw = raw_path.read_bytes()
    assert len(raw) == 2093687 and sha(raw) == '93f69cd8cd4723df749c790200d53f5c84fe66253c61ce31af754a8685e256c4'
    lines = clean(raw)
    assert [line for line in lines if re.fullmatch('[a-f0-9]{40}', line)] == [MERGE, MERGE, TREE]
    assert lines.count('go version go1.25.7 linux/amd64') == 1
    assert 'DATA RACE' not in raw.decode()
    assert sum(line.startswith('##[group]Run set -euo pipefail') for line in lines) == 4
    assert sum(line == 'go test -mod=readonly -race -p 1 -count=1 -timeout=120s -json \\' for line in lines) == 4
    events, streams, seen = parse(lines)
    assert seen == list(EXPECTED) and set(events) == set(EXPECTED)
    occurrences = collections.Counter()
    manifests = []
    phase_leaves = {}
    phase_report = {}
    for phase, expected_count in EXPECTED.items():
        ev = events[phase]
        starts, terminal, names, leaves = tests(ev)
        assert set(starts) == set(terminal)
        assert all(n == 1 for n in starts.values())
        assert all(states == ['pass'] for states in terminal.values())
        assert len(leaves) == expected_count
        packages = collections.defaultdict(list)
        for event in ev:
            if not event.get('Test') and event['Action'] in ['start', 'pass', 'fail', 'skip']:
                packages[event['Package']].append(event['Action'])
        assert set(packages) == set(EXPECTED_PACKAGES[phase])
        for package in EXPECTED_PACKAGES[phase]:
            assert packages[package] == ['start', 'skip' if package == DEBUG else 'pass']
        stream_path = ROOT / (phase + '.jsonl')
        stream_path.write_text('\n'.join(streams[phase]) + '\n')
        phase_leaves[phase] = leaves
        occurrences.update(leaves)
        manifests.extend(dict(phase=phase, package=p, test=t, terminal='pass', runs=1, terminals=1) for p, t in sorted(leaves))
        phase_report[phase] = dict(leaf_count=len(leaves), pass_count=len(leaves), fail=0, skip=0, missing=0, duplicate_events=0, test_nodes_with_parents=len(names), json_events=len(ev), package_events=dict(packages), stream=pin(stream_path))
    assert len(occurrences) == sum(occurrences.values()) == 1857
    assert all(value == 1 for value in occurrences.values())
    debug = [e for e in events['packages'] if e['Package'] == DEBUG]
    assert not any(e.get('Test') for e in debug)
    assert any('[no test files]' in e.get('Output', '') for e in debug)
    old_path = ROOT / 'original-failed-job113998477785-decoded.log'
    old_meta = json.loads((ROOT / 'original-log-retrieval.json').read_text())
    old_raw = old_path.read_bytes()
    # apply_patch terminates a text file with LF. Remove only that known transport
    # separator if the freshly retrieved original string had no final LF.
    adjusted = False
    if not old_meta['trailing_newline'] and len(old_raw.decode().encode('utf-16-le')) // 2 == old_meta['characters_utf16'] + 1:
        assert old_raw.endswith(b'\n')
        old_raw = old_raw[:-1]
        old_path.write_bytes(old_raw)
        adjusted = True
    assert len(old_raw.decode().encode('utf-16-le')) // 2 == old_meta['characters_utf16']
    assert old_raw.endswith(b'\n') == old_meta['trailing_newline']
    old_events, old_streams, old_seen = parse(clean(old_raw))
    assert old_seen == ['packages'] and set(old_events) == {'packages'}
    old_starts, old_terms, old_names, old_leaves = tests(old_events['packages'])
    assert len(old_leaves) == 1745 and old_leaves == phase_leaves['packages']
    assert set(old_starts) == set(old_terms) and all(n == 1 for n in old_starts.values())
    assert all(len(states) == 1 and states[0] in ['pass', 'fail'] for states in old_terms.values())
    failures = sorted(key for key in old_leaves if old_terms[key] == ['fail'])
    assert len(failures) == 4
    idna = {key for key in phase_leaves['packages'] if key[0] == 'tabmail/internal/outbound' and key[1].startswith('TestNext1010IDNA')}
    old_idna = {key for key in old_leaves if key[0] == 'tabmail/internal/outbound' and key[1].startswith('TestNext1010IDNA')}
    assert len(idna) == 26 and idna == old_idna
    assert len([key for key in phase_leaves['packages'] if key[0] == 'tabmail/internal/outbound']) == 1111
    original_stream = ROOT / 'original-failed-packages.jsonl'
    original_stream.write_text('\n'.join(old_streams['packages']) + '\n')
    manifest_path = ROOT / 'leaf-terminals.json'
    manifest_path.write_bytes(canonical(manifests))
    result['actual_source'] = dict(check_head_sha=SOURCE, actual_checkout=MERGE, complete_tree=TREE, parents=[p['sha'] for p in merge['parents']], official_go_version='go version go1.25.7 linux/amd64', public_files=source_files)
    result['steps'] = phase_report
    result['totals'] = dict(step_sum=1857, unique_package_test_leaves=1857, duplicate_leaf_executions=0, pass_count=1857, fail=0, test_skip=0, missing_or_duplicate_test_events=0, race_report=False, go_json_events=sum(len(x) for x in events.values()), test_nodes_with_parents=sum(len(tests(x)[2]) for x in events.values()))
    result['recovered_comparison'] = dict(original_failed_job_id=113998477785, original_raw=pin(old_path), original_transport_added_final_lf_removed=adjusted, original_stream=pin(original_stream), package_leaf_set_exact_match=1745, original_pass=1741, original_fail=4, failures_now_passing=[dict(package=p, test=t) for p, t in failures], original_and_final_idna_leaf_names_exact_match=26, final_idna_pass=26, final_outbound_pass=1111)
    result['package_without_tests'] = dict(package=DEBUG, actions=['start', 'skip'], explicit_no_test_files=True, test_events=0, excluded_from_test_skip_counts=True)
    result['raw_log'] = pin(raw_path)
    result['raw_log_matches_pre_loss_bytes_and_sha256'] = True
    result['leaf_manifest'] = pin(manifest_path)
    result['api_evidence'] = [pin(ROOT / 'api.json'), pin(ROOT / 'source-api.json'), pin(ROOT / 'original-log-retrieval.json')]
    result['artifact'] = dict(api_reported=api['artifacts']['artifacts'], downloaded=False, zip_bytes_or_digest_locally_verified=False)
    result['loss_boundary'] = dict(previous_acceptance_file_restored=False, previous_acceptance_recorded_sha256='a9225d444dc6e543ad41a756697754d14ae568cd084108172b15cf0f60d6aff2', native_fixed_baseline_and_candidate_packets_recovered=False, native_commit_bundle_available=False, retained_prior_summary_used_only_as_expected_values_not_raw_evidence=True, rebuilt_receipt_is_new_and_has_new_hash=True, current_proof='Current complete source and Go runtime results are freshly retrieved from GitHub. The old CI log is also freshly retrieved for actual 1745/26 leaf-set comparison. No lost native file or bundle is claimed recovered.')
    result['status'] = 'ACCEPT_RECOVERED_ORIGINAL_EXEC_GO_FOUR_STEPS'

try:
    main()
except BaseException as error:
    result['status'] = 'RECOVERY_REVIEW_FAILED'
    result['findings'].append(dict(type=type(error).__name__, message=str(error), traceback=traceback.format_exc()))
finally:
    result['reparser_sha256'] = sha(Path(__file__).read_bytes())
    (ROOT / 'recovered-acceptance.json').write_bytes(canonical(result))
    print(json.dumps({key: result[key] for key in ['status', 'totals', 'findings', 'reparser_sha256'] if key in result}, indent=2))
if result['status'] != 'ACCEPT_RECOVERED_ORIGINAL_EXEC_GO_FOUR_STEPS':
    raise SystemExit(1)
