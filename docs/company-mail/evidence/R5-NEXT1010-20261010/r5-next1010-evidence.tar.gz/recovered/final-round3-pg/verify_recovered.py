"""Re-derive acceptance from recovered original GitHub job receipts, not new tests."""
from pathlib import Path
import ast, hashlib, json, re, subprocess
from datetime import datetime, timezone
ROOT=Path(__file__).resolve().parent
# Evidence lives at scratch/tabmail-run-evidence/recovered/final-round3-pg.
REPO=ROOT.parents[2]/'tabmail-recovered'
HEAD='177ee571b194836678cc9a473f178c655326ba7c'
TREE='2d5d2c44680f6a6cb2b2d1166e2923806beafcc8'
BASE='74d5fc72f7ad2e086bd3060b78c548dc302d0408'
BASE_TREE='5cbe43bbdda6601a8bfca79e5ae9d1f83db7b95c'
RUN=37985791733
SPECS={'refresh':('refresh-issuance',114007324480,6,3), 'audit':('permission-audit',114007324789,4,6), 'sponsor':('activation-sponsor',114007324804,6,5), 'errors':('activation-errors',114007324765,2,18)}
def no_duplicates(pairs):
    d={}
    for key,value in pairs:
        assert key not in d, ('duplicate key',key)
        d[key]=value
    return d
def loads(text): return json.loads(text,object_pairs_hook=no_duplicates)
def read(name): return loads((ROOT/name).read_text())
def git_file(path): return subprocess.check_output(['git','-C',str(REPO),'show',HEAD+':'+path])
runner=git_file('scripts/run_r5_next1010_pg.py')
CASES=next(ast.literal_eval(n.value) for n in ast.parse(runner).body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='CASES' for t in n.targets))
run=read('run-api.json');assert run['id']==RUN and run['head_sha']==HEAD and run['status']=='completed' and run['conclusion']=='success'
api_commit=read('source-commit-api.json');assert api_commit['sha']==HEAD and api_commit['tree']['sha']==TREE
jobs=read('jobs-api.json')['jobs'];assert len(jobs)==4 and {j['id'] for j in jobs}=={x[1] for x in SPECS.values()}
for j in jobs: assert j['run_id']==RUN and j['head_sha']==HEAD and j['status']=='completed' and j['conclusion']=='success'
all_leaves=set();results=[]
for name,(case,job_id,old_pass,old_fail) in SPECS.items():
    raw=(ROOT/(name+'-log.log')).read_bytes();reports=[]
    for line in raw.decode('utf-8').splitlines():
        line=re.sub(r'^\ufeff?\d{4}-\d{2}-\d{2}T\S+Z\s?','',line)
        if not line.startswith('{'):continue
        try: obj=loads(line)
        except json.JSONDecodeError:continue
        if isinstance(obj,dict) and {'baseline','candidate','case'}<=obj.keys(): reports.append(obj)
    assert len(reports)==1;report=reports[0];assert report['case']==case
    paths,package,pattern,n=CASES[case];assert n==old_pass+old_fail
    hashes={p:hashlib.sha256(git_file(p)).hexdigest() for p in paths}
    old,new=report['baseline'],report['candidate']
    for label,x,commit,tree,terminal in [('baseline',old,BASE,BASE_TREE,'fail'),('candidate',new,HEAD,TREE,'pass')]:
        before=x['source_before'];assert x['source_stable'] and before==x['source_after']
        assert before['commit']==commit and before['tree']==tree and before['regression_sha256']==hashes
        expected_status='\n'.join('?? '+p for p in sorted(paths)) if label=='baseline' else ''
        assert before['status']==expected_status
        assert x['command']==['go','test','-mod=readonly','-race','-count=1','-timeout=180s','-json',package,'-run',pattern]
        assert x['all_skips']==0 and x['missing_terminals']==[]
        assert len(x['leaves'])==n and all(s in ('pass','fail') for s in x['leaves'].values())
        assert not any(a!=b and b.startswith(a+'/') for a in x['leaves'] for b in x['leaves'])
        assert x['pass']==sum(v=='pass' for v in x['leaves'].values()) and x['fail']==sum(v=='fail' for v in x['leaves'].values())
        expected_package='tabmail/'+package.removeprefix('./')
        assert x['package_events']==[{'package':expected_package,'action':'start'},{'package':expected_package,'action':terminal}]
        assert re.fullmatch('[a-f0-9]{64}',x['log_sha256'])
    assert old['exit_code']!=0 and (old['pass'],old['fail'])==(old_pass,old_fail)
    assert set(old['leaves'])==set(new['leaves'])
    assert new['exit_code']==0 and new['pass']==n and new['fail']==0 and new['failure_output']=={}
    leaves={(package,t) for t in new['leaves']};assert not (leaves&all_leaves);all_leaves|=leaves
    (ROOT/(name+'-comparison.json')).write_text(json.dumps(report,indent=2)+'\n')
    results.append({'case':case,'job_id':job_id,'baseline':{'pass':old_pass,'fail':old_fail},'candidate':{'pass':n,'fail':0,'skip':0},'frozen_sha256':hashes,'raw_log_bytes':len(raw),'raw_log_sha256':hashlib.sha256(raw).hexdigest(),'inner_Go_JSONL_SHA256_reported_by_original_runner':{'baseline':old['log_sha256'],'candidate':new['log_sha256']}})
arts=read('artifacts-api.json')['artifacts'];assert len(arts)==4
assert {a['name'] for a in arts}=={'next1010-'+s[0] for s in SPECS.values()}
for a in arts: assert not a['expired'] and a['workflow_run']['head_sha']==HEAD and a['workflow_run']['id']==RUN and re.fullmatch('sha256:[a-f0-9]{64}',a['digest'])
assert len(all_leaves)==50
out={'schema':'recovered-original-pg50-acceptance-v1','status':'ACCEPT_REDERIVED_FROM_ORIGINAL_CI','recovered_and_reviewed_at':datetime.now(timezone.utc).isoformat(),'run_id':RUN,'candidate_commit':HEAD,'candidate_tree':TREE,'original_runner_sha256':hashlib.sha256(runner).hexdigest(),'distinct_passing_leaves':50,'groups':results,'qualifications':['No new PostgreSQL execution occurred during this recovery. Original four successful jobs and complete comparison receipts were downloaded again.','Candidate commit/tree/clean status were recorded before and after each original run. Baseline has only the explicit frozen untracked test files.','Inner Go JSONL digests and per-leaf events are reported by the unchanged original runner; original inner JSONL ZIP bytes were not independently downloaded. Artifact ZIP digests are GitHub API reported.','Prior local verifier/report was lost during the transient filesystem reset. This new verifier and report are newly derived and do not pretend to restore their exact old bytes.'],'artifacts_api':arts}
(ROOT/'acceptance.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({'status':out['status'],'leaves':len(all_leaves),'head':HEAD,'tree':TREE,'report_sha256':hashlib.sha256((ROOT/'acceptance.json').read_bytes()).hexdigest()},indent=2))
