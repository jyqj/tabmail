"""Fresh protocol-only mocks: no real subprocess, signals, Go/PG or C18 grammar tests."""
import unittest,ast
from pathlib import Path
from unittest.mock import patch
import c18_rss_protocol as p
import c18_rss_controller_prepared_only as c
class C18RSSResourceProtocolNewTests(unittest.TestCase):
 def test_first_sample_and_tail_coverage(self):
  g=p.Freshness(100,200);g.sample(200.05,100.06,200.06,8);g.sample(200.15,100.16,200.16,8);g.finalize(100.20,200.20);self.assertEqual(g.samples,2)
 def test_first_sample_missing_fails(self):
  with self.assertRaisesRegex(p.ProtocolError,'first_sample_missing'):p.Freshness(100,200).finalize(100.10,200.10)
 def test_first_sample_late_fails(self):
  with self.assertRaisesRegex(p.ProtocolError,'gap_over250'):p.Freshness(100,200).sample(200.29,100.3,200.3,8)
 def test_intersample_gap_sticky_even_later_recovery(self):
  g=p.Freshness(100,200);g.sample(200,100.01,200.01,8)
  with self.assertRaisesRegex(p.ProtocolError,'gap_over250'):g.sample(200.3,100.31,200.31,8)
  with self.assertRaises(p.ProtocolError):g.finalize(100.32,200.32)
  self.assertIn('RSS_sample_gap_over250ms',g.failed)
 def test_single_ps_sampling_call_slow_fails(self):
  with self.assertRaisesRegex(p.ProtocolError,'call_over250'):p.Freshness(100,200).sample(200,100.26,200.26,8)
 def test_unknown_or_excess_RSS_fails(self):
  for value in (None,-1,True,2**30+1):
   with self.subTest(value=value),self.assertRaises(p.ProtocolError):p.Freshness(100,200).sample(200,100.01,200.01,value)
 def test_exact_RSS_threshold_is_sample_not_hardquota(self):
  g=p.Freshness(100,200);g.sample(200,100.01,200.01,2**30);self.assertEqual(g.samples,1)
 def test_tail_coverage_gap_fails(self):
  g=p.Freshness(100,200);g.sample(200,100.01,200.01,8)
  with self.assertRaisesRegex(p.ProtocolError,'gap_over250'):g.finalize(100.27,200.27)
 def test_wall_reversal_above_origin_sticky(self):
  g=p.Freshness(100,200);g.sample(200,100.10,200.10,8)
  with self.assertRaisesRegex(p.ProtocolError,'clock_reversal'):g.tick(100.09,200.11)
 def test_sleep_wall_mono_gap_fails(self):
  with self.assertRaisesRegex(p.ProtocolError,'wall_monotonic'):p.Freshness(100,200).tick(101,200.01)
 def test_import_handshake_all_prerequisites_failclosed(self):
  values={'audit_armed':True,'cpu_readback':[60,60],'ready_pid':123,'owned_pid':123,'sample':{'rss_bytes':8,'wall':100},'now':100.1}
  self.assertTrue(p.import_gate(**values))
  for k,v in [('audit_armed',False),('cpu_readback',[60,61]),('ready_pid',124),('sample',None),('now',100.3)]:
   with self.subTest(k=k),self.assertRaises(p.ProtocolError):p.import_gate(**(values|{k:v}))
 def test_signal_requires_unreaped_identity_UID_start_session(self):
  original={'pid':123,'uid':501,'pgid':123,'session_ps':'s','lstart':'start'}
  self.assertTrue(p.may_signal(original,original,unreaped=True,default_sigchld=True))
  for k,v in [('pid',124),('uid',502),('pgid',124),('session_ps','other'),('lstart','later')]:
   self.assertFalse(p.may_signal(original,original|{k:v},unreaped=True,default_sigchld=True))
  self.assertFalse(p.may_signal(original,original,unreaped=False,default_sigchld=True))
  self.assertFalse(p.may_signal(original,original,unreaped=True,default_sigchld=False))
 def test_ps_PID_parser_KiB_to_bytes_and_exact_exception_argv(self):
  class Reply:returncode=0;stdout='123 501 123 abc Fri Oct 3 01:02:03 2026 2048 S\n'
  with patch.object(c.subprocess,'run',return_value=Reply()) as m:
   value=c.owned_identity(123,.12);self.assertEqual(value['rss_bytes'],2048*1024)
   self.assertEqual(m.call_args.args[0],['/bin/ps','-p','123','-o','pid=,uid=,pgid=,sess=,lstart=,rss=,stat='])
 def test_unknown_ps_never_implies_gone(self):
  class Reply:returncode=1;stdout=''
  with patch.object(c.subprocess,'run',return_value=Reply()):
   with self.assertRaises(p.ProtocolError):c.group_observation(123,.12)
 def test_source_order_guard_noAS_and_no_runtime_import(self):
  child=(Path(__file__).parent/'c18_audited_child.py').read_text();outer=(Path(__file__).parent/'c18_rss_controller_prepared_only.py').read_text()
  self.assertLess(child.index('sys.addaudithook(hook)'),child.index('resource.setrlimit(resource.RLIMIT_CPU')))
  self.assertLess(child.index("permit=wait_permit('import-permit.json')"),child.index('import unittest'))
  self.assertNotIn('RLIMIT_AS',child);self.assertNotIn('RLIMIT_DATA',child)
  self.assertIn("TABMAIL_C18_RSS_RUNTIME_APPROVED",outer)
  self.assertLess(outer.index('signal.SIGTERM'),outer.index('grace_end='))
  self.assertLess(outer.index('signal.SIGKILL'),outer.index('returncode=process.wait',outer.index('finally:')))
  ast.parse(child);ast.parse(outer)
