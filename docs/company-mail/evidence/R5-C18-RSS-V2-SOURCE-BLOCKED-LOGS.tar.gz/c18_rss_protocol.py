"""Pure decision machinery. No process or filesystem side effects."""
RSS_LIMIT_BYTES=1024**3
INTERVAL_SECONDS=.100
MAX_GAP_SECONDS=.250
class ProtocolError(RuntimeError):pass
class Freshness:
 def __init__(self,wall,mono):
  self.origin_wall=wall;self.origin_mono=mono;self.previous_wall=wall;self.previous_mono=mono
  self.last_sample=None;self.first_sample=None;self.samples=0;self.max_gap=0.;self.failed=[]
 def reject(self,why):
  if why not in self.failed:self.failed.append(why)
  raise ProtocolError(why)
 def clock(self,wall,mono):
  if wall<self.previous_wall or mono<self.previous_mono:self.reject('clock_reversal')
  if abs((wall-self.origin_wall)-(mono-self.origin_mono))>.100:self.reject('wall_monotonic_anomaly')
  self.previous_wall=wall;self.previous_mono=mono
 def sample(self,start,wall,mono,rss_bytes):
  self.clock(wall,mono)
  if mono-start>MAX_GAP_SECONDS:self.reject('RSS_sample_call_over250ms')
  prior=self.origin_mono if self.last_sample is None else self.last_sample
  gap=mono-prior;self.max_gap=max(self.max_gap,gap)
  if gap>MAX_GAP_SECONDS:self.reject('RSS_sample_gap_over250ms')
  if type(rss_bytes) is not int or rss_bytes<0:self.reject('RSS_sample_unknown')
  if rss_bytes>RSS_LIMIT_BYTES:self.reject('RSS_over1GiB')
  self.samples+=1;self.last_sample=mono
  if self.first_sample is None:self.first_sample=mono
 def tick(self,wall,mono):
  self.clock(wall,mono)
  prior=self.origin_mono if self.last_sample is None else self.last_sample
  if mono-prior>MAX_GAP_SECONDS:self.reject('RSS_sample_gap_over250ms')
 def finalize(self,wall,mono):
  self.tick(wall,mono)
  if self.samples==0:self.reject('RSS_first_sample_missing')
  if self.failed:self.reject('RSS_previous_sticky_failure')
def identity_equal(original,current):
 return all(current.get(k)==original.get(k) for k in ('pid','uid','pgid','session_ps','lstart')) and original['pid']==original['pgid']
def may_signal(original,current,*,unreaped,default_sigchld):
 return unreaped and default_sigchld and identity_equal(original,current)
def import_gate(*,audit_armed,cpu_readback,ready_pid,owned_pid,sample,now):
 if not audit_armed or cpu_readback!=[60,60] or ready_pid!=owned_pid:raise ProtocolError('bootstrap_handshake_unknown')
 if sample is None or sample['rss_bytes']>RSS_LIMIT_BYTES or now-sample['wall']>MAX_GAP_SECONDS:raise ProtocolError('bootstrap_first_RSS_unknown_or_stale')
 return True
