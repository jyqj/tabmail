"""Read-only source-only preflight policy; never connects to or stops any service."""
import pathlib
APPROVED={'pid':13082,'uid':501,'lstart':'Wed Sep 30 08:26:12 2026','comm':'/opt/homebrew/opt/redis/bin/redis-server 127.0.0.1:6379'}
def classify_runtime_rows(raw, identity_reader):
 excluded=[];blocked=[]
 for line in raw.splitlines():
  parts=line.strip().split(maxsplit=3)
  if not parts:continue
  if len(parts)!=4:raise ValueError('process_inventory_parse_unknown')
  pid,uid,pgid=map(int,parts[:3]);comm=parts[3];first=comm.split()[0];basename=pathlib.Path(first).name
  heavy=basename in {'postgres','postmaster','redis-server'} or basename.endswith('.test') or basename=='go'
  if not heavy:continue
  row={'pid':pid,'uid':uid,'pgid':pgid,'comm':comm}
  if pid==APPROVED['pid'] and uid==APPROVED['uid'] and comm==APPROVED['comm']:
   actual=identity_reader(pid)
   if actual==APPROVED:excluded.append(row|{'approval':'root bounded read-only unrelated Redis exception','identity':actual,'no_connect_stop_env_or_endpoint_inheritance':True});continue
  blocked.append(row)
 return {'exact_external_Redis_observed_excluded':excluded,'unknown_heavy_rows_block':blocked,'no_blanket_Redis_exclusion':True}
def parse_approved_start_identity(text):
 p=text.strip().split(maxsplit=7)
 if len(p)!=8:raise ValueError('external_Redis_start_identity_unknown')
 return {'pid':int(p[0]),'uid':int(p[1]),'lstart':' '.join(p[2:7]),'comm':p[7]}
