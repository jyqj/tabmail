"""Bounded read-only observer, no actions on import; fixture no-network probes."""
import os,signal,subprocess,time,ipaddress,pathlib,re,threading
PS='/bin/ps';LSOF='/usr/sbin/lsof';QUERY_CAP=.150;INTERVAL=.010;MAX_GAP=.250
class Unknown(RuntimeError):pass

def parse_identity(raw):
 p=raw.strip().split()
 if len(p)!=8:raise Unknown('PID_UID_group_start_unknown')
 return {'pid':int(p[0]),'uid':int(p[1]),'pgid':int(p[2]),'start':' '.join(p[3:])}
def parse_members(raw):
 rows=[]
 for l in raw.splitlines():
  if not l.strip():continue
  p=l.strip().split(maxsplit=9)
  if len(p)!=10:raise Unknown('group_member_unknown_fields')
  rows.append({'pid':int(p[0]),'uid':int(p[1]),'pgid':int(p[2]),'start':' '.join(p[3:8]),'stat':p[8],'comm':p[9]})
 return rows

def parse_listeners(raw,pid):
 bound=None;out=[]
 for l in raw.splitlines():
  if not l:continue
  if l[0]=='p':
   bound=int(l[1:])
   if bound!=pid:raise Unknown('lsof_otherPID')
  elif l[0]=='n':
   if bound!=pid:raise Unknown('unbound_listener')
   host,port=l[1:].rsplit(':',1);ip=ipaddress.ip_address(host.strip('[]'));port=int(port)
   if not ip.is_loopback or not 1<=port<=65535 or port==6379:raise Unknown('nonloopback_or6379')
   out.append((str(ip),port))
  else:raise Unknown('lsof_unknownfield')
 if len(out)!=len(set(out)):raise Unknown('duplicate_listener')
 return sorted(out)

class ListenerLedger:
 def __init__(self):self.smtp=None;self.redis=None;self.solo=None;self.solo_count=0;self.closed=False;self.failures=[]
 def observe(self,addresses):
  try:
   if self.failures:raise Unknown('previous_listener_failure')
   if self.closed and addresses:raise Unknown('listener_reappeared_after_closed')
   if len(addresses)>2:raise Unknown('extra_listener')
   if self.redis is not None and any(a not in {self.smtp,self.redis} for a in addresses):raise Unknown('listener_outside_identified_set')
   if len(addresses)==1 and self.redis is None:
    if self.solo is None:self.solo=addresses[0]
    if addresses[0]!=self.solo:raise Unknown('solo_listener_changed')
    self.solo_count+=1
    if self.solo_count>=2:self.smtp=self.solo
   if len(addresses)==2:
    if self.smtp is None or self.smtp not in addresses:raise Unknown('no_prior_two_solo_SMTP_witness')
    other=next(a for a in addresses if a!=self.smtp)
    if self.redis is None:self.redis=other
    if other!=self.redis:raise Unknown('miniredis_changed')
   if not addresses and self.smtp and self.redis:self.closed=True
  except BaseException as e:self.failures.append(str(e));raise
 def qualified(self):return bool(self.smtp and self.redis and self.closed and not self.failures)

class Observer:
 def __init__(self,leader,identity,deadline_wall,deadline_mono,go_binary,owned_tmp,query=None,wall=None,mono=None):
  self.leader=leader;self.identity=identity;self.dw=deadline_wall;self.dm=deadline_mono;self.go=go_binary;self.tmp=owned_tmp;self.wall=wall or time.time;self.mono=mono or time.monotonic;self.query_fn=query or self._query
  self.failures=[];self.samples=[];self.rejected_members_safe=[];self.child=None;self.child_comm=None;self.done=False;self.stop_event=threading.Event();self.thread=None;self.last_wall=None;self.last_mono=None;self.last_tick=None;self.max_gap=0;self.ledger=ListenerLedger()
  tool=str(pathlib.Path(go_binary).parent.parent/'pkg/tool/darwin_arm64');self.compiler_paths={tool+'/'+n for n in ['compile','asm','cgo','link','pack','vet']}
  self.compiler_paths|={'/usr/bin/cc','/usr/bin/clang','/usr/bin/ar','/Library/Developer/CommandLineTools/usr/bin/clang','/Library/Developer/CommandLineTools/usr/bin/cc','/Library/Developer/CommandLineTools/usr/bin/ar'}
 def check(self):
  w=self.wall();m=self.mono()
  if self.last_wall is not None and (w<self.last_wall or m<self.last_mono):raise Unknown('observer_clock_backwards')
  self.last_wall=w;self.last_mono=m
  if w>=self.dw or m>=self.dm:raise Unknown('original_observer_deadline')
  if self.failures:raise Unknown('sticky_observer_failure')
  return min(self.dw-w,self.dm-m)
 def _query(self,argv,timeout):return subprocess.run(argv,capture_output=True,text=True,timeout=timeout,env={'PATH':'/usr/bin:/bin','LC_ALL':'C'})
 def query(self,argv):
  try:
   timeout=min(QUERY_CAP,self.check());r=self.query_fn(argv,timeout);self.check()
   if r.stderr.strip():raise Unknown('query_stderr_unknown')
   return r
  except BaseException as e:self.failures.append(type(e).__name__+':'+str(e));raise
 def record_rejected_member_safe(self,row):
  # Ownership confirmed by the just-read group snapshot, not a new identity oracle.
  if row['uid']!=self.identity['uid'] or row['pgid']!=self.leader.pid:raise Unknown('reject_diagnostic_not_owned_group')
  value={k:row[k] for k in ['pid','uid','pgid','start']}
  value.update(identity_status='UNKNOWN',sid=None,executable_basename=None,basename_source='confirmed_owned_group_ps_snapshot_first_executable_token',snapshot_basename_status='UNKNOWN',sid_status='UNKNOWN')
  # Pure memory sanitization happens before fallible independent SID lookup.
  try:
   token=row['comm'].split()[0] if row['comm'].split() else ''
   name=pathlib.PurePosixPath(token).name
   if not re.fullmatch('[A-Za-z0-9._+-]{1,80}',name):raise Unknown('reject_diagnostic_basename_unknown')
   value.update(executable_basename=name,snapshot_basename_status='SAFE_SNAPSHOT_NAME_ONLY_NOT_CURRENT_IDENTITY')
  except BaseException as e:value['basename_unknown_class']=type(e).__name__
  try:
   sid=os.getsid(row['pid']);self.check()
   if sid!=self.leader.pid:raise Unknown('reject_diagnostic_session_unknown')
   value.update(sid=sid,sid_status='OWNED_SESSION_OBSERVED')
  except BaseException as e:value['identity_unknown_class']=type(e).__name__
  if value['sid'] is not None and value['executable_basename'] is not None:value['identity_status']='owned_group_UID_start_and_session_observed_nonatomic'
  self.rejected_members_safe.append(value)
 def group(self,raw):
  rows=parse_members(raw)
  testpattern=re.compile(re.escape(str(pathlib.Path(self.tmp)))+r'/go-build[0-9]+/b[0-9]+/postgres\.test$')
  tests=[]
  for r in rows:
   if r['uid']!=self.identity['uid'] or r['pgid']!=self.leader.pid:raise Unknown('group_UID_or_PGID_mismatch')
   if r['pid']==self.leader.pid:
    if {k:r[k] for k in ['pid','uid','pgid','start']}!=self.identity:raise Unknown('leader_start_changed')
    if r['comm'] not in {self.go,'go'}:raise Unknown('leader_executable_unknown')
    continue
   is_test=r['comm']=='postgres.test' or bool(testpattern.fullmatch(r['comm']))
   if self.child is None:
    if is_test:tests.append(r)
    elif r['comm'] not in self.compiler_paths:
     self.record_rejected_member_safe(r)
     raise Unknown('unknown_compile_group_member')
   else:
    exact_identity={k:r[k] for k in ['pid','uid','pgid','start']}==self.child
    registered_zombie=r['stat'].startswith('Z') and r['comm'] in {self.child_comm,'('+pathlib.Path(self.child_comm).name+')'}
    if not exact_identity or not (is_test or registered_zombie):raise Unknown('unknown_registered_test_group_member')
    if not registered_zombie:tests.append(r)
  if len(tests)>1:raise Unknown('multiple_test_group_members')
  if tests and self.child is None:
   self.child={k:tests[0][k] for k in ['pid','uid','pgid','start']};self.child_comm=tests[0]['comm']
  return tests
 def tick(self):
  begin=self.mono()
  try:
   self.check()
   if self.leader.returncode is not None or signal.getsignal(signal.SIGCHLD)!=signal.SIG_DFL:raise Unknown('leader_reaped_before_observer_join')
   r=self.query([PS,'-p',str(self.leader.pid),'-o','pid=,uid=,pgid=,lstart='])
   if r.returncode or parse_identity(r.stdout)!=self.identity:raise Unknown('leader_identity_unknown')
   r=self.query([PS,'-g',str(self.leader.pid),'-o','pid=,uid=,pgid=,lstart=,stat=,comm='])
   if r.returncode:raise Unknown('group_query_unknown')
   tests=self.group(r.stdout)
   if not tests:
    if self.child is not None:
     if not self.ledger.qualified():raise Unknown('test_disappeared_without_empty_listener_proof')
     self.done=True
   else:
    pid=self.child['pid'];r=self.query([PS,'-p',str(pid),'-o','pid=,uid=,pgid=,lstart='])
    if r.returncode or parse_identity(r.stdout)!=self.child:raise Unknown('test_before_lsof_identity_unknown')
    r=self.query([LSOF,'-nP','-a','-p',str(pid),'-iTCP','-sTCP:LISTEN','-Fpn'])
    if r.returncode not in {0,1} or (r.returncode==1 and r.stdout.strip()):raise Unknown('lsof_status_unknown')
    listeners=parse_listeners(r.stdout,pid) if r.returncode==0 else [];self.ledger.observe(listeners)
    r=self.query([PS,'-p',str(pid),'-o','pid=,uid=,pgid=,lstart='])
    if r.returncode or parse_identity(r.stdout)!=self.child:raise Unknown('test_after_lsof_identity_unknown')
    self.samples.append({'query_begin_mono':begin,'query_end_mono':self.mono(),'wall':self.wall(),'owned_child_identity':self.child,'numeric_TCP_LISTEN':listeners})
   end=self.mono();gap=end-begin if self.last_tick is None else end-self.last_tick;self.max_gap=max(self.max_gap,gap,end-begin);self.last_tick=end
   if self.max_gap>MAX_GAP:raise Unknown('actual_tick_or_sampling_gap_over250ms')
   self.check()
  except BaseException as e:self.failures.append(type(e).__name__+':'+str(e));raise
 def start(self):
  def loop():
   try:
    while not self.stop_event.is_set() and not self.done:
     begin=self.mono();self.tick();self.stop_event.wait(max(0,INTERVAL-(self.mono()-begin)))
   except BaseException:pass # tick/query already permanently recorded failure; never resume/reset.
  self.thread=threading.Thread(target=loop);self.thread.start()
 def stop_join(self,remaining_seconds):
  self.stop_event.set()
  if self.thread:self.thread.join(timeout=max(0,min(.800,remaining_seconds)))
  return self.thread is None or not self.thread.is_alive()
 def receipt(self,joined,groupgone):
  try:self.check()
  except BaseException as e:self.failures.append('receipt:'+str(e))
  if not joined:self.failures.append('observer_not_joined')
  if not groupgone:self.failures.append('owned_group_not_gone')
  if not self.done:self.failures.append('child_end_not_observed')
  return {'rejected_members_safe':self.rejected_members_safe,'complete':self.ledger.qualified() and self.done and joined and groupgone and not self.failures,'samples':self.samples,'failures':self.failures,'listener_failures':self.ledger.failures,'max_gap_seconds':self.max_gap,'smtp_sourceorder_solo_address':self.ledger.smtp,'owned_miniredis_sourceorder_added_address':self.ledger.redis,'closed_observed':self.ledger.closed,'observer_joined':joined,'groupgone':groupgone,'sampling_not_proof_of_no_short_external_connection':True,'source_environment_isolation_independent':True}
