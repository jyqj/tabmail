"""New memory snapshot-name ordering mocks only, no ps/SID/GoPG/main."""
import unittest,os,json
from unittest.mock import patch
import owned_listener_observer as o
import usage19_driver_prepared_only as d
class SnapshotNameOrderingNew(unittest.TestCase):
 def ob(self):
  class Leader:pid=123;returncode=None
  return o.Observer(Leader(),{'pid':123,'uid':os.getuid(),'pgid':123,'start':'Fri Oct 3 01:02:03 2026'},100,100,d.GO,'/private/tmp/owned',query=lambda *a:None,wall=lambda:10,mono=lambda:10)
 def row(self,comm='/private/secret/directory/safe-helper ARGSECRET=value'):return {'pid':124,'uid':os.getuid(),'pgid':123,'start':'Fri Oct 3 01:02:03 2026','comm':comm,'stat':'S'}
 def test_SID_disappearance_keeps_snapshot_safe_name_not_current_identity(self):
  b=self.ob()
  with patch.object(o.os,'getsid',side_effect=ProcessLookupError):b.record_rejected_member_safe(self.row())
  v=b.rejected_members_safe[0];self.assertEqual(v['executable_basename'],'safe-helper');self.assertEqual(v['identity_status'],'UNKNOWN');self.assertIsNone(v['sid']);self.assertEqual(v['sid_status'],'UNKNOWN');self.assertIn('SNAPSHOT',v['snapshot_basename_status']);wire=json.dumps(v);self.assertNotIn('/private/',wire);self.assertNotIn('ARGSECRET',wire);self.assertNotIn('comm',v)
 def test_unsafe_basename_still_null_and_identity_UNKNOWN(self):
  b=self.ob()
  with patch.object(o.os,'getsid',return_value=123):b.record_rejected_member_safe(self.row('/private/path/bad$name secret'))
  v=b.rejected_members_safe[0];self.assertIsNone(v['executable_basename']);self.assertEqual(v['identity_status'],'UNKNOWN');self.assertEqual(v['sid'],123)
 def test_uncertain_owner_no_name_extraction_or_SIDquery(self):
  for row in [self.row()|{'uid':os.getuid()+1},self.row()|{'pgid':999}]:
   b=self.ob()
   with patch.object(o.os,'getsid') as sid,self.assertRaises(o.Unknown):b.record_rejected_member_safe(row)
   sid.assert_not_called();self.assertEqual(b.rejected_members_safe,[])
