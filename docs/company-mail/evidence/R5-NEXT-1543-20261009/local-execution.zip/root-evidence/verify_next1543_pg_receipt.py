"""Independently reconcile the completed real PostgreSQL raw Go event stream."""
from pathlib import Path
from collections import Counter
import hashlib
import json
import subprocess
import sys

ROOT = Path('/workspace/scratch/472e5abb7d28')
OUT = ROOT / 'frontend-evidence/pg-local'
PIN = {
    'wave1-v2': ('559d01edd58c6af5cbc5965e1202ff575e4e2cda', '3b1b2644c7e7f05b57396afbf04daf8b8394da33', 14),
    'wave2-v2': ('7bb9b8abff9a6a53b1d0010f96cc13728a9330c5', '48f894a0417091278a9d197096d13995b9041b38', 8),
    'wave3-v2': ('17be458fb9d36e135a95962638b68ce105c16518', 'fd362eed901840f23f58b477104a642f2a6cbf51', 19),
}

def sha(b):
    return hashlib.sha256(b).hexdigest()

name = sys.argv[1]
head, tree, expected = PIN[name]
folder = OUT / name
raw_comparison = (folder / 'comparison.json').read_bytes()
comparison = json.loads(raw_comparison)
invocation = json.loads((OUT / (name + '-invocation.json')).read_text())
assert invocation['exit_code'] == 0
assert invocation['source_before'] == invocation['source_after'] == {'commit': head, 'tree': tree, 'status': ''}
assert comparison['candidate']['source_commit'] == head
assert comparison['candidate']['source_tree'] == tree
assert comparison['baseline']['source_commit'] == '30d2d05ab6ddcc23f47d9b9786885817aef50a0f'
assert comparison['baseline']['source_tree'] == 'f3de30fc777b0d9135c4ed9a75005aec8f2835c0'
frozen = subprocess.check_output(['git', '-C', str(ROOT / 'tabmail'), 'show', head + ':' + comparison['regression_path']])
assert sha(frozen) == comparison['regression_sha256']
phases = {}
for phase in ['baseline', 'candidate']:
    report = comparison[phase]
    raw = (folder / phase / 'go-test.jsonl').read_bytes()
    events = [json.loads(line) for line in raw.splitlines()]
    assert sha(raw) == report['log_sha256']
    assert not any(row['Action'] == 'skip' for row in events)
    terminal = {row['Test']: row['Action'] for row in events if row.get('Test') and row['Action'] in {'pass', 'fail', 'skip'}}
    leaves = {test: action for test, action in terminal.items() if not any(other.startswith(test + '/') for other in terminal)}
    assert len(leaves) == expected
    assert leaves == report['leaves']
    assert report['source_stable'] and report['source_before'] == report['source_after']
    assert report['source_before']['regression_sha256'] == sha(frozen)
    assert report['source_before']['tracked_diff_sha256'] == sha(b'')
    counts = Counter(leaves.values())
    assert all(counts.get(action, 0) == report[action] for action in ['pass', 'fail', 'skip'])
    package_outcomes = [row['Action'] for row in events if not row.get('Test') and row['Action'] in {'pass', 'fail', 'skip'}]
    assert package_outcomes == (['pass'] if phase == 'candidate' else ['fail'])
    if phase == 'candidate':
        assert report['exit_code'] == 0 and counts == {'pass': expected} and not report['dirty_paths']
    else:
        assert report['exit_code'] != 0 and counts['fail'] > 0
        assert report['dirty_paths'] == '?? ' + comparison['regression_path']
    phases[phase] = {'counts': dict(counts), 'exit_code': report['exit_code'], 'raw_log_sha256': sha(raw)}
assert set(comparison['baseline']['leaves']) == set(comparison['candidate']['leaves'])
runtime = json.loads((OUT / 'supervised-sql-identity.json').read_text())
assert runtime['version'].startswith('PostgreSQL 16.15 ')
assert runtime['current_role'] == 'tabmail_test' and runtime['server_address'] == '127.0.0.1' and runtime['server_port'] == 55432
assert runtime['unix_socket_directories'] == ''
result = {'wave': name, 'accepted': True, 'candidate_head': head, 'candidate_tree': tree,
          'expected_leaves': expected, 'regression_sha256': sha(frozen), 'comparison_sha256': sha(raw_comparison),
          'phases': phases, 'runtime': runtime,
          'qualification': 'Raw actual Go event streams, frozen source, exact candidate tree, all-level no-skip, full leaf identity, package exits and source stability independently reconciled. Bounded PG acceptance only.'}
(ROOT / 'root-evidence' / ('pg-root-verification-' + name + '.json')).write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result))
