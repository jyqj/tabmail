#!/usr/bin/env python3
"""Read-only verification and index of the three actual local PostgreSQL runs."""
from pathlib import Path
from collections import Counter
import hashlib
import json
import re
import subprocess

ROOT = Path('/workspace/scratch/472e5abb7d28')
OUT = ROOT/'frontend-evidence/pg-local'
RUNTIME = ROOT/'postgres-runtime'
REPO = ROOT/'tabmail'
EMPTY = hashlib.sha256(b'').hexdigest()


def digest(path):
    raw = path.read_bytes()
    return {'path':str(path),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}


def read(path):
    return json.loads(path.read_text())


def git(*args):
    return subprocess.check_output(['git','-C',str(REPO),*args])


plan = read(OUT/'supervised-plan.json')
results = read(OUT/'supervised-results.json')
final = read(OUT/'supervised-exit.json')
shutdown = read(OUT/'supervised-shutdown.json')
sql = read(OUT/'supervised-sql-identity.json')
assert final == {'exit_code':0,'completed_waves':3,'expected_waves':3}
assert shutdown['server_returncode'] == 0 and not shutdown['postmaster_pid_file_exists']
server_log = RUNTIME/'server-supervised.log'
assert digest(server_log)['sha256'] == shutdown['server_log_sha256']
server_text = server_log.read_text()
launch = json.loads(server_text.splitlines()[0])
assert launch == {'uid':65534,'euid':65534,'gid':65534,'egid':65534}
assert 'database system is ready to accept connections' in server_text
assert 'received fast shutdown request' in server_text and 'database system is shut down' in server_text
assert sql['current_user'] == sql['current_role'] == 'tabmail_test'
assert sql['server_address'] == sql['listen_addresses'] == '127.0.0.1'
assert sql['server_port'] == 55432 and sql['unix_socket_directories'] == ''
assert sql['password_encryption'] == 'scram-sha-256'
assert sql['data_directory'] == str(RUNTIME/'data')
runner = OUT/'run_r5_next1543_pg.py'
assert runner.read_bytes() == git('show',plan['runner_source_commit']+':'+plan['runner_source_path'])
assert digest(runner)['sha256'] == plan['runner_sha256']
assert digest(RUNTIME/'root/usr/lib/postgresql/16/bin/postgres')['sha256'] == plan['server_binary_sha256']
assert digest(RUNTIME/'package-manifest.json')['sha256'] == plan['package_manifest_sha256']
assert len(results) == len(plan['waves']) == 3
records=[]
for wave,summary in zip(plan['waves'],results,strict=True):
    name=wave['name']; folder=OUT/name
    comparison=read(folder/'comparison.json')
    receipt=read(OUT/(name+'-invocation.json'))
    assert summary['wave']==name and summary['runner_exit_code']==receipt['exit_code']==0
    assert receipt['source_before']==receipt['source_after']=={'commit':wave['commit'],'tree':wave['tree'],'status':''}
    assert comparison['case']==wave['case'] and comparison['regression_path']==wave['regression']
    regression=git('show',wave['commit']+':'+wave['regression'])
    assert hashlib.sha256(regression).hexdigest()==comparison['regression_sha256']==wave['regression_sha256']
    assert git('rev-parse',wave['commit']+'^{tree}').decode().strip()==wave['tree']
    assert summary['comparison_sha256']==digest(folder/'comparison.json')['sha256']
    assert comparison['baseline']['leaves'].keys()==comparison['candidate']['leaves'].keys()
    phases={}
    for phase in ['baseline','candidate']:
        result=comparison[phase]
        assert result['source_stable'] and result['source_before']==result['source_after']
        assert result['source_before']['tracked_diff_sha256']==EMPTY
        assert result['source_before']['regression_sha256']==wave['regression_sha256']
        assert result['all_skip_events']==result['skip']==0
        assert result['expected_leaves']==len(result['leaves'])==wave['expected']
        assert result['command'][:9]==['go','test','-mod=readonly','-race','-count=1','-timeout=120s','-json','./internal/store/postgres','-run']
        if phase=='candidate':
            assert result['source_commit']==wave['commit'] and result['source_tree']==wave['tree']
            assert result['dirty_paths']=='' and result['exit_code']==0
            assert result['pass']==wave['expected'] and result['fail']==0
        else:
            assert result['source_commit']==plan['baseline_commit']
            assert result['dirty_paths']=='?? '+wave['regression']
            assert result['exit_code']!=0 and result['fail']>0
        log=folder/phase/'go-test.jsonl'; err=folder/phase/'go-test.stderr'
        assert digest(log)['sha256']==result['log_sha256']
        assert err.read_bytes()==b''
        events=[json.loads(row) for row in log.read_text().splitlines()]
        assert not any(event['Action']=='skip' for event in events)
        terminals=[event for event in events if event.get('Test') and event['Action'] in {'pass','fail','skip'}]
        terminal={event['Test']:event['Action'] for event in terminals}
        assert len(terminal)==len(terminals)
        starts=Counter(event['Test'] for event in events if event.get('Test') and event['Action']=='run')
        assert set(starts)==set(terminal) and all(count==1 for count in starts.values())
        leaves={test:state for test,state in terminal.items() if not any(other.startswith(test+'/') for other in terminal)}
        assert leaves==result['leaves']
        counts=Counter(leaves.values())
        assert all(counts[state]==result[state] for state in ['pass','fail','skip'])
        package=[event for event in events if not event.get('Test') and event['Action'] in {'pass','fail','skip'}]
        assert len(package)==1 and package[0]['Action']==('pass' if phase=='candidate' else 'fail')
        phases[phase]={'pass':result['pass'],'fail':result['fail'],'skip':result['skip'],'all_skip_events':0,'exit_code':result['exit_code'],'source_before':result['source_before'],'source_after':result['source_after'],'leaf_ids':list(leaves),'failed_leaves':[test for test,state in leaves.items() if state=='fail'],'raw_log':digest(log),'stderr':digest(err),'command':result['command']}
    streams={stream:digest(OUT/(name+'-runner.'+stream)) for stream in ['stdout','stderr']}
    for stream,details in streams.items():
        assert {key:details[key] for key in ['sha256','bytes']}==receipt[stream]
    outer_stderr=(OUT/(name+'-runner.stderr')).read_text().splitlines()
    assert outer_stderr[0]=='Preparing worktree (detached HEAD 30d2d05)'
    assert all(re.fullmatch(r'Updating files:\s+\d+% \(\d+/3121\)(, done\.)?',line) for line in outer_stderr[1:])
    records.append({'name':name,'case':wave['case'],'candidate_commit':wave['commit'],'candidate_tree':wave['tree'],'regression':wave['regression'],'regression_sha256':wave['regression_sha256'],'runner_exit':0,'comparison':digest(folder/'comparison.json'),'invocation':digest(OUT/(name+'-invocation.json')),'runner_streams':streams,'baseline':phases['baseline'],'candidate':phases['candidate']})
files=[OUT/'supervised-plan.json',OUT/'supervised-results.json',OUT/'supervised-sql-identity.json',OUT/'supervised-shutdown.json',OUT/'supervised-exit.json',OUT/'service-setup.json',OUT/'metadata-collection-failure.json',RUNTIME/'package-manifest.json',server_log,runner,ROOT/'frontend-evidence/pg_local_validate.py',Path(__file__)]
handoff={'verdict':'PASS: all three original strict PostgreSQL comparison gates completed on actual PostgreSQL','scope':'41 unique candidate leaves across three frozen suites; each baseline executed the same leaf IDs. This does not add TODO completions or claim a full PostgreSQL regression suite.','go':{'path':plan['go_path'],'version':plan['go_version']},'runner':{'source_commit':plan['runner_source_commit'],'source_path':plan['runner_source_path'],'sha256':plan['runner_sha256']},'postgresql':sql,'launch_identity':launch,'normal_shutdown':True,'candidate_pass_leaves':sum(r['candidate']['pass'] for r in records),'candidate_fail_leaves':0,'all_skip_events':0,'runs':records,'retained_attempts':'Earlier successful startup/SQL followed by unavailable namespace /proc metadata and separate-invocation TCP refusal remain recorded. Actual gates only began after the single-process supervisor started. No guard, identity API, product source, fixture, assertion, or runner bytes were modified for execution.','reviewer_tool_note':'The first optional index review assumed outer runner stderr was empty. It contains only normal git worktree progress; the comparator was corrected to verify that exact scope. All six Go-test stderr files remain empty. Initial review script/diagnostic retained; original strict runner and all outputs unchanged.','artifacts':[digest(p) for p in files]}
(OUT/'handoff.json').write_text(json.dumps(handoff,indent=2)+'\n')
print(json.dumps({'verdict':handoff['verdict'],'candidate_pass_leaves':41,'candidate_fail_leaves':0,'all_skip_events':0,'normal_shutdown':True,'handoff':digest(OUT/'handoff.json'),'wave_results':[{'wave':r['name'],'baseline':[r['baseline']['pass'],r['baseline']['fail'],r['baseline']['skip']],'candidate':[r['candidate']['pass'],r['candidate']['fail'],r['candidate']['skip']]} for r in records]},indent=2))
