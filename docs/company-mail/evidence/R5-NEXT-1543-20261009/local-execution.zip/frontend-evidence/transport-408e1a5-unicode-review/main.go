package main

import (
	"encoding/json"
	"os"
	"fmt"
	"net/mail"
	"net/netip"
	"strings"
)

// addressLiteralHost returns a network host without SMTP's square brackets or
// IPv6 tag. DNS names remain DNS names, including all-digit dotted domains.
// Preserve the untagged IPv6 form net/mail has historically accepted as well.
func addressLiteralHost(domain string) (string, bool, error) {
	if !strings.ContainsAny(domain, "[]") {
		return "", false, nil
	}
	if len(domain) < 2 || domain[0] != '[' || domain[len(domain)-1] != ']' {
		return "", true, fmt.Errorf("invalid SMTP address literal")
	}
	value := domain[1 : len(domain)-1]
	tagged := len(value) >= 5 && strings.EqualFold(value[:5], "IPv6:")
	if tagged {
		value = value[5:]
	}
	ip, err := netip.ParseAddr(value)
	if err != nil || ip.Zone() != "" || (tagged && !ip.Is6()) {
		return "", true, fmt.Errorf("invalid SMTP address literal")
	}
	return ip.String(), true, nil
}

// net/mail rejects RFC 5321's IPv6 tag even though it accepts the same address
// without that tag. Validate the IP first, let net/mail validate the complete
// mailbox with only the tag removed, and restore it only when the parsed
// domain is exactly the selected literal. Quoted local parts, display names,
// comments, and rejection of trailing/multiple addresses stay with net/mail.
func parseRecipientMailbox(value string) (*mail.Address, error) {
	parsed, originalErr := mail.ParseAddress(value)
	if originalErr == nil {
		return parsed, nil
	}
	lower := strings.ToLower(value)
	for offset := 0; offset < len(value); {
		start := strings.Index(lower[offset:], "[ipv6:")
		if start < 0 {
			break
		}
		start += offset
		offset = start + 6
		end := strings.IndexByte(value[offset:], ']')
		if end < 0 {
			break
		}
		end += offset
		literal := value[start : end+1]
		if _, _, err := addressLiteralHost(literal); err != nil {
			continue
		}
		bare := "[" + value[offset:end] + "]"
		candidate, err := mail.ParseAddress(value[:start] + bare + value[end+1:])
		if err == nil && strings.HasSuffix(candidate.Address, "@"+bare) {
			candidate.Address = strings.TrimSuffix(candidate.Address, bare) + literal
			return candidate, nil
		}
	}
	return nil, originalErr
}


type probeResult struct {
    Name string `json:"name"`
    Input string `json:"input"`
    ControlAddress string `json:"untagged_control_address"`
    ControlError string `json:"untagged_control_error"`
    Address string `json:"tagged_address"`
    Error string `json:"tagged_error"`
    Panic string `json:"panic"`
}

func probe(name, value string) (result probeResult) {
    result.Name, result.Input = name, value
    defer func() {
        if caught := recover(); caught != nil {
            result.Panic = fmt.Sprint(caught)
        }
    }()
    control, controlErr := mail.ParseAddress(strings.Replace(value, "IPv6:", "", 1))
    if controlErr != nil {
        result.ControlError = controlErr.Error()
    } else {
        result.ControlAddress = control.Address
    }
    parsed, err := parseRecipientMailbox(value)
    if err != nil {
        result.Error = err.Error()
    } else {
        result.Address = parsed.Address
    }
    return result
}

func main() {
    results := []probeResult{
        probe("ascii_display", "Reader <reader@[IPv6:::1]>"),
        probe("unicode_shrinking_display", "K Reader <reader@[IPv6:::1]>"),
        probe("unicode_expanding_display", strings.Repeat("Ⱥ", 16) + " <reader@[IPv6:::1]>"),
        probe("unicode_quoted_local", "\"K\"@[IPv6:::1]"),
    }
    encoder := json.NewEncoder(os.Stdout)
    encoder.SetIndent("", "  ")
    if err := encoder.Encode(results); err != nil { panic(err) }
}
