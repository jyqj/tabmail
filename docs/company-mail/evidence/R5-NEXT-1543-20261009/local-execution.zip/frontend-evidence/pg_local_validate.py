#!/usr/bin/env python3
"""One real local execution context for owned PostgreSQL and frozen Go runs."""
from pathlib import Path
import hashlib
import json
import os
import shutil
import signal
import subprocess
import sys
import time

ROOT = Path('/workspace/scratch/472e5abb7d28')
REPO = ROOT / 'tabmail'
RUNTIME = ROOT / 'postgres-runtime'
OUT = ROOT / 'frontend-evidence/pg-local'
BIN = RUNTIME / 'root/usr/lib/postgresql/16/bin'
GO = ROOT / 'toolchain/go/bin/go'
RUNNER_SOURCE = '2dfebb7692700c14906ceba351e19893fb736656'
RUNNER_PATH = 'scripts/run_r5_next1543_pg.py'
RUNNER = OUT / 'run_r5_next1543_pg.py'
BASELINE = '30d2d05ab6ddcc23f47d9b9786885817aef50a0f'
GRANT = 'internal/store/postgres/r5_frozen_mailbox_grant_test.go'
GRANT_V2_SHA256 = '39d0360a979914e3aac33aa6541b44bd6794480dd792173ab197f3c74c5ceb1f'
WAVES = [
    {'name':'wave1-v2','case':'mailbox-grants','commit':'559d01edd58c6af5cbc5965e1202ff575e4e2cda','tree':'3b1b2644c7e7f05b57396afbf04daf8b8394da33','database':'tabmail_r5_wave1_v2','regression':GRANT,'expected':14},
    {'name':'wave2-v2','case':'derived-text','commit':'7bb9b8abff9a6a53b1d0010f96cc13728a9330c5','tree':'48f894a0417091278a9d197096d13995b9041b38','database':'tabmail_r5_wave2','regression':'internal/store/postgres/r5_derived_text_persistence_test.go','expected':8},
    {'name':'wave3-v2','case':'reconcile-ledger','commit':'17be458fb9d36e135a95962638b68ce105c16518','tree':'fd362eed901840f23f58b477104a642f2a6cbf51','database':'tabmail_r5_wave3','regression':'internal/store/postgres/r5_reconcile_ledger_coverage_test.go','expected':19},
]


def sha(value):
    return hashlib.sha256(value).hexdigest()


def save(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2) + '\n')


def git(*args):
    return subprocess.check_output(['git', '-C', str(REPO), *args])


def identity(root):
    def read(*args):
        return subprocess.check_output(['git', '-C', str(root), *args], text=True).strip()
    return {'commit':read('rev-parse','HEAD'),'tree':read('rev-parse','HEAD^{tree}'),
            'status':read('status','--porcelain','--untracked-files=all')}


def diagnostics(folder):
    result = {}
    for phase in ['baseline','candidate']:
        root = folder / phase
        if not (root / 'go-test.jsonl').exists():
            continue
        rows = [json.loads(line) for line in (root / 'go-test.jsonl').read_text().splitlines()]
        terminal = {row['Test']:row['Action'] for row in rows if row.get('Test') and row['Action'] in {'pass','fail','skip'}}
        leaves = {name:state for name,state in terminal.items() if not any(other.startswith(name + '/') for other in terminal)}
        failed = [name for name,state in leaves.items() if state == 'fail']
        names = failed + [name for name,state in terminal.items() if state in {'fail','skip'} and name not in failed]
        result[phase] = {'failed_leaves':failed,'all_skip_events':sum(row['Action']=='skip' for row in rows),
                         'terminal_tests':terminal,
                         'full_outputs':{name:''.join(row.get('Output','') for row in rows if row.get('Test')==name) for name in names},
                         'package_output':''.join(row.get('Output','') for row in rows if not row.get('Test')),
                         'stderr':(root/'go-test.stderr').read_text()}
    return result


OUT.mkdir(parents=True, exist_ok=True)
runner_raw = git('show', RUNNER_SOURCE + ':' + RUNNER_PATH)
assert RUNNER.read_bytes() == runner_raw, 'the reviewed runner bytes changed'
environment = os.environ.copy()
environment['PATH'] = str(GO.parent) + os.pathsep + environment.get('PATH','')
environment['LD_LIBRARY_PATH'] = str(RUNTIME / 'root/usr/lib/x86_64-linux-gnu')
environment['PGPASSWORD'] = (RUNTIME / 'test-password').read_text().strip()
environment['GOTOOLCHAIN'] = 'local'
environment['GOWORK'] = 'off'
assert shutil.which('go', path=environment['PATH']) == str(GO)
assert subprocess.check_output([str(GO),'version'],text=True).strip() == 'go version go1.25.7 linux/amd64'
for wave in WAVES:
    assert git('rev-parse',wave['commit']+'^{tree}').decode().strip() == wave['tree'], wave['name']
    assert sha(git('show',wave['commit']+':'+GRANT)) == GRANT_V2_SHA256, wave['name']
    wave['regression_sha256'] = sha(git('show',wave['commit']+':'+wave['regression']))
    wave['candidate_path'] = str(OUT / 'sources' / wave['name'])
    assert not Path(wave['candidate_path']).exists(), 'candidate output path already exists'
    assert not (OUT/wave['name']).exists(), 'runner output path already exists'
assert git('show',WAVES[1]['commit']+':'+WAVES[1]['regression']) == git('show','ad104624301ec1e21c2be20f6605e4dcb26e3a33:'+WAVES[1]['regression'])
assert git('show',WAVES[2]['commit']+':'+WAVES[2]['regression']) == git('show',RUNNER_SOURCE+':'+WAVES[2]['regression'])
plan = {'runner_source_commit':RUNNER_SOURCE,'runner_source_path':RUNNER_PATH,'runner_sha256':sha(runner_raw),
        'go_path':str(GO),'go_version':'go version go1.25.7 linux/amd64',
        'baseline_commit':BASELINE,'waves':WAVES,'started_at_unix':time.time(),
        'execution':'Actual PostgreSQL and all psql/Go processes share this one supervised invocation; no mock events or fixture edits.',
        'server_binary_sha256':sha((BIN/'postgres').read_bytes()),
        'package_manifest_sha256':sha((RUNTIME/'package-manifest.json').read_bytes())}
save(OUT/'supervised-plan.json',plan)

server_log = (RUNTIME/'server-supervised.log').open('w')
launch_identity = "import json,os,sys; print(json.dumps({'uid':os.getuid(),'euid':os.geteuid(),'gid':os.getgid(),'egid':os.getegid()}),flush=True); os.execv(sys.argv[1],sys.argv[1:])"
server_command = ['unshare','--user','--',sys.executable,'-c',launch_identity,str(BIN/'postgres'),
                  '-D',str(RUNTIME/'data'),'-h','127.0.0.1','-p','55432','-k','']
server = subprocess.Popen(server_command,env=environment,stdout=server_log,stderr=subprocess.STDOUT)
psql = [str(BIN/'psql'),'-X','-w','-h','127.0.0.1','-p','55432','-U','tabmail_test','-d','postgres','-A','-t','-v','ON_ERROR_STOP=1']
results = []
exit_code = 0
try:
    deadline = time.monotonic() + 15
    while True:
        ready = subprocess.run(psql+['-c','SELECT 1;'],env=environment,text=True,capture_output=True)
        if ready.returncode == 0:
            break
        if server.poll() is not None or time.monotonic() >= deadline:
            raise RuntimeError('PostgreSQL readiness failed: ' + ready.stderr)
        time.sleep(0.2)
    query = "SELECT json_build_object('version',version(),'current_user',current_user,'current_role',current_role,'server_address',inet_server_addr(),'server_port',inet_server_port(),'listen_addresses',current_setting('listen_addresses'),'unix_socket_directories',current_setting('unix_socket_directories'),'data_directory',current_setting('data_directory'),'password_encryption',current_setting('password_encryption'),'postmaster_start_time',pg_postmaster_start_time());"
    runtime_identity = json.loads(subprocess.check_output(psql+['-c',query],env=environment,text=True))
    assert runtime_identity['server_address']=='127.0.0.1' and runtime_identity['server_port']==55432
    assert runtime_identity['data_directory']==str(RUNTIME/'data') and runtime_identity['current_role']=='tabmail_test'
    assert runtime_identity['listen_addresses']=='127.0.0.1' and runtime_identity['unix_socket_directories']==''
    assert runtime_identity['password_encryption']=='scram-sha-256'
    save(OUT/'supervised-sql-identity.json',runtime_identity)
    print(json.dumps({'event':'real-postgresql-ready','identity':runtime_identity}),flush=True)
    for wave in WAVES:
        root = Path(wave['candidate_path'])
        root.parent.mkdir(parents=True,exist_ok=True)
        subprocess.run(['git','-C',str(REPO),'worktree','add','--detach',str(root),wave['commit']],check=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
        before = identity(root)
        assert before == {'commit':wave['commit'],'tree':wave['tree'],'status':''}, before
        db_command = [str(BIN/'createdb'),'-w','-h','127.0.0.1','-p','55432','-U','tabmail_test',wave['database']]
        created = subprocess.run(db_command,env=environment,text=True,capture_output=True)
        save(OUT/(wave['name']+'-database-creation.json'),{'command':db_command,'exit':created.returncode,'stdout':created.stdout,'stderr':created.stderr})
        if created.returncode:
            raise RuntimeError('Owned database creation failed: '+created.stderr)
        wave_env = environment.copy()
        wave_env['TABMAIL_TEST_DB_DSN'] = 'postgresql://tabmail_test:' + environment['PGPASSWORD'] + '@127.0.0.1:55432/' + wave['database'] + '?sslmode=disable'
        argv = [sys.executable,'-B',str(RUNNER),'--candidate',str(root),'--output',str(OUT/wave['name']),'--case',wave['case']]
        receipt = {'wave':wave,'command':argv,'cwd':str(ROOT),'source_before':before,'started_at_unix':time.time(),
                   'dsn_without_password':'postgresql://tabmail_test@127.0.0.1:55432/'+wave['database']+'?sslmode=disable'}
        save(OUT/(wave['name']+'-invocation.json'),receipt)
        print(json.dumps({'event':'wave-start','wave':wave['name'],'commit':wave['commit'],'tree':wave['tree'],'expected_leaves':wave['expected']}),flush=True)
        with (OUT/(wave['name']+'-runner.stdout')).open('w') as stdout, (OUT/(wave['name']+'-runner.stderr')).open('w') as stderr:
            run = subprocess.run(argv,cwd=ROOT,env=wave_env,stdout=stdout,stderr=stderr)
        receipt['exit_code'] = run.returncode
        receipt['completed_at_unix'] = time.time()
        receipt['source_after'] = identity(root)
        for stream in ['stdout','stderr']:
            data=(OUT/(wave['name']+'-runner.'+stream)).read_bytes()
            receipt[stream]={'sha256':sha(data),'bytes':len(data)}
        save(OUT/(wave['name']+'-invocation.json'),receipt)
        comparison_file = OUT/wave['name']/'comparison.json'
        comparison = json.loads(comparison_file.read_text()) if comparison_file.exists() else None
        summary = {'wave':wave['name'],'runner_exit_code':run.returncode,'candidate_commit':wave['commit'],'candidate_tree':wave['tree'],
                   'source_stable':receipt['source_before']==receipt['source_after'],'regression_sha256':wave['regression_sha256']}
        if comparison:
            summary['baseline'] = {key:comparison['baseline'][key] for key in ['exit_code','pass','fail','skip','all_skip_events','source_stable']}
            summary['candidate'] = {key:comparison['candidate'][key] for key in ['exit_code','pass','fail','skip','all_skip_events','source_stable']}
            summary['comparison_sha256'] = sha(comparison_file.read_bytes())
        results.append(summary)
        save(OUT/'supervised-results.json',results)
        print(json.dumps({'event':'wave-result',**summary}),flush=True)
        if run.returncode or not summary['source_stable']:
            full = diagnostics(OUT/wave['name'])
            save(OUT/(wave['name']+'-failure-full.json'),full)
            print(json.dumps({'event':'verification-failure','wave':wave['name'],'failed_leaves':{phase:data['failed_leaves'] for phase,data in full.items()},
                              'runner_stderr':(OUT/(wave['name']+'-runner.stderr')).read_text(),'full_diagnostics_path':str(OUT/(wave['name']+'-failure-full.json'))}),flush=True)
            exit_code = 1
            break
except Exception as error:
    exit_code = 1
    save(OUT/'supervised-error.json',{'type':type(error).__name__,'error':str(error),'at_unix':time.time(),'completed_waves':results})
    print(json.dumps({'event':'supervisor-error','type':type(error).__name__,'error':str(error)}),flush=True)
finally:
    if server.poll() is None:
        server.send_signal(signal.SIGINT)
        try:
            server.wait(timeout=30)
        except subprocess.TimeoutExpired:
            exit_code = 1
            print(json.dumps({'event':'server-stop-timeout','meaning':'Owned server did not finish fast shutdown within 30 seconds'}),flush=True)
    server_log.close()
    shutdown={'server_command':server_command,'server_returncode':server.poll(),'shutdown_signal':'SIGINT (normal PostgreSQL fast shutdown)',
              'postmaster_pid_file_exists':(RUNTIME/'data/postmaster.pid').exists(),'server_log':str(RUNTIME/'server-supervised.log'),
              'server_log_sha256':sha((RUNTIME/'server-supervised.log').read_bytes()),'completed_at_unix':time.time()}
    save(OUT/'supervised-shutdown.json',shutdown)
    save(OUT/'supervised-exit.json',{'exit_code':exit_code,'completed_waves':len(results),'expected_waves':len(WAVES)})
    print(json.dumps({'event':'supervised-complete','exit_code':exit_code,'completed_waves':len(results),'server_returncode':server.poll()}),flush=True)
raise SystemExit(exit_code)
