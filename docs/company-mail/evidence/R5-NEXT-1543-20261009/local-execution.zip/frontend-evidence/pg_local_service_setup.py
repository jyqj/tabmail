#!/usr/bin/env python3
"""Start only the owned scratch PostgreSQL instance and record actual identity."""
from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess
import sys
import time

ROOT = Path('/workspace/scratch/472e5abb7d28')
RUNTIME = ROOT / 'postgres-runtime'
OUT = ROOT / 'frontend-evidence/pg-local'
BIN = RUNTIME / 'root/usr/lib/postgresql/16/bin'
DATA = RUNTIME / 'data'
GO = ROOT / 'toolchain/go/bin/go'
SOURCE = '2dfebb7692700c14906ceba351e19893fb736656'
RUNNER_PATH = 'scripts/run_r5_next1543_pg.py'
OUT.mkdir(parents=True, exist_ok=True)


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def save(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2) + '\n')


packages = json.loads((RUNTIME / 'package-manifest.json').read_text())
expected = {row['sha256']: row for row in packages}
verified = []
for path in sorted((RUNTIME / 'packages').glob('*.deb')):
    checksum = digest(path)
    assert checksum in expected, 'unrecognized runtime package'
    pin = expected[checksum]
    assert path.stat().st_size == pin['bytes'], 'runtime package size differs'
    verified.append(dict(pin, local_path=str(path)))
assert len(verified) == len(packages) == 3
runner = subprocess.check_output(['git', '-C', str(ROOT / 'tabmail'), 'show', SOURCE + ':' + RUNNER_PATH])
(OUT / 'run_r5_next1543_pg.py').write_bytes(runner)
environment = os.environ.copy()
environment['LD_LIBRARY_PATH'] = str(RUNTIME / 'root/usr/lib/x86_64-linux-gnu')
environment['PGPASSWORD'] = (RUNTIME / 'test-password').read_text().strip()
environment['PATH'] = str(GO.parent) + os.pathsep + environment.get('PATH', '')
environment['GOTOOLCHAIN'] = 'local'
environment['GOWORK'] = 'off'

setup = {
    'started_at_unix': time.time(),
    'outer_uid': os.getuid(), 'outer_euid': os.geteuid(),
    'outer_user_namespace': os.readlink('/proc/self/ns/user'),
    'packages': verified,
    'package_manifest_sha256': digest(RUNTIME / 'package-manifest.json'),
    'server_binary': str(BIN / 'postgres'), 'server_binary_sha256': digest(BIN / 'postgres'),
    'pg_ctl_sha256': digest(BIN / 'pg_ctl'), 'psql_sha256': digest(BIN / 'psql'),
    'runner_source_commit': SOURCE, 'runner_source_path': RUNNER_PATH,
    'runner_sha256': hashlib.sha256(runner).hexdigest(),
    'go_path': str(GO), 'go_version': subprocess.check_output([str(GO), 'version'], text=True).strip(),
    'go_env': json.loads(subprocess.check_output([str(GO), 'env', '-json', 'GOVERSION', 'GOOS', 'GOARCH', 'GOROOT', 'GOPATH', 'GOMODCACHE', 'CGO_ENABLED', 'CC'], env=environment)),
    'ld_library_path': environment['LD_LIBRARY_PATH'],
    'data_directory': str(DATA), 'server_log': str(RUNTIME / 'server.log'),
    'endpoint': '127.0.0.1:55432', 'unix_sockets': 'disabled with normal -k configuration because this environment denies AF_UNIX',
    'authentication': 'SCRAM-SHA-256; credential remains only in the provided scratch password file/environment',
    'binary_or_identity_api_modifications': False,
    'filesystem_free_bytes': shutil.disk_usage(ROOT).free,
}
save('service-setup.json', setup)
assert not (DATA / 'postmaster.pid').exists(), 'owned instance already has a postmaster PID; refusing a duplicate start'
identity_code = "import json,os,sys; print(json.dumps({'uid':os.getuid(),'euid':os.geteuid(),'gid':os.getgid(),'egid':os.getegid(),'uid_map':open('/proc/self/uid_map').read(),'gid_map':open('/proc/self/gid_map').read(),'user_namespace':os.readlink('/proc/self/ns/user')}),flush=True); os.execv(sys.argv[1],sys.argv[1:])"
command = ['unshare', '--user', '--', sys.executable, '-c', identity_code,
           str(BIN / 'pg_ctl'), '-D', str(DATA), '-l', str(RUNTIME / 'server.log'),
           '-o', "-h 127.0.0.1 -p 55432 -k ''", '-w', 'start']
with (OUT / 'pg-start.stdout').open('w') as stdout, (OUT / 'pg-start.stderr').open('w') as stderr:
    started = subprocess.run(command, env=environment, stdout=stdout, stderr=stderr, timeout=80)
(OUT / 'pg-start.exit').write_text(str(started.returncode) + '\n')
setup['start_command'] = command
setup['start_exit_code'] = started.returncode
save('service-setup.json', setup)
if started.returncode:
    print((OUT / 'pg-start.stdout').read_text(), end='')
    print((OUT / 'pg-start.stderr').read_text(), end='', file=sys.stderr)
    if (RUNTIME / 'server.log').exists(): print((RUNTIME / 'server.log').read_text(), end='', file=sys.stderr)
    raise SystemExit(started.returncode)

psql = [str(BIN / 'psql'), '-X', '-w', '-h', '127.0.0.1', '-p', '55432', '-U', 'tabmail_test', '-d', 'postgres', '-A', '-t', '-v', 'ON_ERROR_STOP=1']
query = "SELECT json_build_object('version',version(),'current_user',current_user,'session_user',session_user,'current_role',current_role,'database',current_database(),'server_address',inet_server_addr(),'server_port',inet_server_port(),'listen_addresses',current_setting('listen_addresses'),'unix_socket_directories',current_setting('unix_socket_directories'),'data_directory',current_setting('data_directory'),'password_encryption',current_setting('password_encryption'),'is_superuser',current_setting('is_superuser'),'postmaster_start_time',pg_postmaster_start_time(),'backend_pid',pg_backend_pid());"
observed = subprocess.check_output(psql + ['-c', query], env=environment, text=True).strip()
sql_identity = json.loads(observed)
assert sql_identity['current_user'] == 'tabmail_test' and sql_identity['server_address'] == '127.0.0.1' and sql_identity['server_port'] == 55432
assert sql_identity['listen_addresses'] == '127.0.0.1' and sql_identity['unix_socket_directories'] == ''
assert sql_identity['password_encryption'] == 'scram-sha-256'
save('sql-service-identity.json', sql_identity)
pid = int((DATA / 'postmaster.pid').read_text().splitlines()[0])
launch_identity = json.loads((OUT / 'pg-start.stdout').read_text().splitlines()[0])
service_identity = {'pid': pid, 'launch_identity_inside_user_namespace': launch_identity,
                    'proc_status_from_outer_namespace': Path(f'/proc/{pid}/status').read_text(),
                    'user_namespace': os.readlink(f'/proc/{pid}/ns/user'),
                    'uid_map': Path(f'/proc/{pid}/uid_map').read_text(),
                    'gid_map': Path(f'/proc/{pid}/gid_map').read_text(),
                    'cmdline': Path(f'/proc/{pid}/cmdline').read_bytes().decode().split('\0')}
assert launch_identity['uid'] == launch_identity['euid'] == 65534
assert service_identity['user_namespace'] == launch_identity['user_namespace']
save('process-service-identity.json', service_identity)

created = []
for name in ['tabmail_r5_wave1_v2', 'tabmail_r5_wave2', 'tabmail_r5_wave3']:
    exists = subprocess.check_output(psql + ['-c', "SELECT count(*) FROM pg_database WHERE datname='" + name + "';"], env=environment, text=True).strip()
    assert exists == '0', 'refusing to reuse an existing database for this new validation'
    subprocess.run([str(BIN / 'createdb'), '-w', '-h', '127.0.0.1', '-p', '55432', '-U', 'tabmail_test', name], env=environment, check=True)
    created.append({'database': name, 'dsn_without_password': 'postgresql://tabmail_test@127.0.0.1:55432/' + name + '?sslmode=disable'})
save('disposable-databases.json', created)
setup['completed_at_unix'] = time.time()
setup['server_pid'] = pid
setup['databases'] = [row['database'] for row in created]
save('service-setup.json', setup)
print(json.dumps({'postgres_started': True, 'server_version': sql_identity['version'], 'role': sql_identity['current_role'],
                  'endpoint': setup['endpoint'], 'server_pid': pid, 'inner_uid': launch_identity['uid'],
                  'runner_sha256': setup['runner_sha256'], 'go_version': setup['go_version'],
                  'databases': setup['databases']}, indent=2))
