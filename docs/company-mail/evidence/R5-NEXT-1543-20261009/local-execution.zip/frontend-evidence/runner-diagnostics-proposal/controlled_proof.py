#!/usr/bin/env python3
"""Read pinned product code; exercise protocol with synthetic events only."""
import contextlib
import hashlib
import io
import json
import os
from pathlib import Path
import subprocess
import sys
import types
from unittest.mock import patch

ROOT = Path('/workspace/scratch/472e5abb7d28/tabmail')
OUT = Path('/workspace/scratch/472e5abb7d28/frontend-evidence')
RUNNER = '57b319526b99f7c5ec8d061e8b920e5cf05ec361'
TRANSPORT = '408e1a57c7108abefc87c4ee61c310fdc60301ab'


def blob(commit, path):
    return subprocess.check_output(['git', '-C', str(ROOT), 'show', f'{commit}:{path}'])


runner_bytes = Path(__file__).with_name('run_r5_next1543_pg.py').read_bytes()
review_dir = Path(__file__).with_name('controlled-proof-v2')
review_dir.mkdir(exist_ok=False)
regression = 'internal/store/postgres/r5_frozen_mailbox_grant_test.go'
root_test = 'TestR5FrozenMailboxGrantRevocation'


def scenario(kind):
    module = types.ModuleType('pinned_runner_review')
    exec(compile(runner_bytes, f'git:{RUNNER}:run_r5_next1543_pg.py', 'exec'), module.__dict__)
    case_dir = review_dir / kind
    candidate = case_dir / 'candidate-source'
    (candidate / regression).parent.mkdir(parents=True)
    (candidate / regression).write_bytes(b'// synthetic frozen regression bytes, no Go execution\n')
    output = case_dir / 'run-output'
    snapshot_counts = {}
    commands = []

    def fake_snapshot(root, path):
        key = str(root)
        snapshot_counts[key] = snapshot_counts.get(key, 0) + 1
        candidate_run = root == candidate
        result = {
            'commit': RUNNER if candidate_run else module.BASELINE,
            'commit_tree': 'synthetic-candidate-tree' if candidate_run else 'synthetic-baseline-tree',
            'dirty_paths': '' if candidate_run else '?? ' + regression,
            'tracked_diff_sha256': hashlib.sha256(b'').hexdigest(),
            'regression_sha256': hashlib.sha256((root / path).read_bytes()).hexdigest(),
        }
        if candidate_run and kind == 'dirty_candidate':
            result['dirty_paths'] = ' M internal/store/postgres/synthetic-product.go'
        if candidate_run and kind == 'source_drift' and snapshot_counts[key] > 1:
            result['tracked_diff_sha256'] = hashlib.sha256(b'synthetic observed source mutation').hexdigest()
        return result

    def fake_git(root, *args):
        if args == ('rev-parse', 'HEAD'):
            return RUNNER if root == candidate else module.BASELINE
        if args == ('rev-parse', 'HEAD^{tree}'):
            return 'synthetic-candidate-tree' if root == candidate else 'synthetic-baseline-tree'
        if args == ('status', '--porcelain'):
            return '' if root == candidate else '?? ' + regression
        raise AssertionError(f'unexpected git command: {args!r}')

    def fake_run(command, **kwargs):
        commands.append({'command': command, 'cwd': str(kwargs.get('cwd', ''))})
        if command[0] == 'git':
            if command[4] == 'add':
                target = Path(command[-2])
                (target / regression).parent.mkdir(parents=True)
            elif command[4] != 'remove':
                raise AssertionError(command)
            return subprocess.CompletedProcess(command, 0)
        assert command[0:2] == ['go', 'test'], command
        is_candidate = Path(kwargs['cwd']) == candidate
        terminal = 'pass' if is_candidate and kind != 'failed_candidate' else 'fail'
        rows = []
        for i in range(14):
            name = f'{root_test}/leaf_{i:02d}'
            diagnostic = ''.join(f'DIAGNOSTIC_{kind}_{i:02d}_{line:02d}: ' + 'x' * 250 + '\n' for line in range(20))
            rows.append({'Action': 'output', 'Package': 'synthetic/package', 'Test': name, 'Output': diagnostic})
            rows.append({'Action': terminal, 'Package': 'synthetic/package', 'Test': name})
        parent_action = 'skip' if is_candidate and kind == 'parent_skip' else terminal
        rows.append({'Action': 'output', 'Package': 'synthetic/package', 'Test': root_test, 'Output': 'DIAGNOSTIC_PARENT_' + parent_action + '\n'})
        rows.append({'Action': parent_action, 'Package': 'synthetic/package', 'Test': root_test})
        rows.append({'Action': terminal, 'Package': 'synthetic/package'})
        if not is_candidate and kind == 'baseline_setup_failure':
            rows = [
                {'Action': 'output', 'Package': 'synthetic/package', 'Test': root_test, 'Output': 'DIAGNOSTIC_BASELINE_SETUP: owned database was unavailable\n'},
                {'Action': 'fail', 'Package': 'synthetic/package', 'Test': root_test},
                {'Action': 'fail', 'Package': 'synthetic/package'},
            ]
        kwargs['stdout'].write(''.join(json.dumps(row) + '\n' for row in rows))
        if terminal == 'fail':
            kwargs['stderr'].write('DIAGNOSTIC_STDERR\n' + 'e' * 2500)
        return subprocess.CompletedProcess(command, 0 if terminal == 'pass' else 1)

    module.snapshot = fake_snapshot
    module.git = fake_git
    module.subprocess = types.SimpleNamespace(run=fake_run)
    stdout = io.StringIO()
    error = None
    with patch.object(sys, 'argv', ['pinned-runner', '--candidate', str(candidate), '--output', str(output), '--case', 'mailbox-grants']), patch.dict(os.environ, {'TABMAIL_TEST_DB_DSN': 'synthetic://no-database'}), contextlib.redirect_stdout(stdout):
        try:
            module.main()
        except ValueError as caught:
            error = str(caught)
    (case_dir / 'stdout.txt').write_text(stdout.getvalue())
    candidate_summary_path = output / 'candidate' / 'summary.json'
    candidate_summary = json.loads(candidate_summary_path.read_text()) if candidate_summary_path.exists() else None
    result = {
        'kind': kind,
        'synthetic_only': True,
        'actual_go_or_postgresql_execution': False,
        'main_rejected': error is not None,
        'error': error,
        'candidate_go_invocations': sum(row['command'][0] == 'go' and row['cwd'] == str(candidate) for row in commands),
        'candidate_summary': candidate_summary,
        'full_comparison_printed': bool(stdout.getvalue()) and json.loads(stdout.getvalue()) == json.loads((output / 'comparison.json').read_text()),
    }
    if kind == 'parent_skip':
        assert error == 'candidate did not pass every expected regression leaf', result
        assert candidate_summary['pass'] == 14 and candidate_summary['skip'] == 0 and candidate_summary['all_skip_events'] == 1, result
        assert result['full_comparison_printed'], result
        assert candidate_summary['failure_output_preview']['tests'][0]['text'] == 'DIAGNOSTIC_PARENT_skip', result
    elif kind == 'failed_candidate':
        assert error == 'candidate did not pass every expected regression leaf', result
        assert result['full_comparison_printed'], result
        preview = candidate_summary['failure_output_preview']
        assert len(preview['tests']) == 8 and preview['omitted_tests'] == 7, result
        assert all(len(item['text']) <= 2000 and len(item['text'].splitlines()) <= 12 and item['truncated'] for item in preview['tests']), result
        assert candidate_summary['stderr_preview']['truncated'] and len(candidate_summary['stderr_preview']['text']) == 2000, result
    elif kind == 'baseline_setup_failure':
        assert error == 'baseline did not execute the expected failing regression', result
        assert result['full_comparison_printed'], result
        baseline_summary = json.loads((output / 'baseline' / 'summary.json').read_text())
        assert len(baseline_summary['leaves']) == 1 and baseline_summary['fail'] == 1, result
        assert baseline_summary['failure_output_preview']['tests'][0]['text'] == 'DIAGNOSTIC_BASELINE_SETUP: owned database was unavailable', result
    elif kind == 'source_drift':
        assert error == 'execution source changed while the tests ran', result
        assert candidate_summary['source_stable'] is False, result
    elif kind == 'dirty_candidate':
        assert error == 'candidate must be the exact clean committed source', result
        assert result['candidate_go_invocations'] == 0, result
    else:
        assert error is None and result['full_comparison_printed'], result
    return result


results = [scenario(kind) for kind in ['parent_skip', 'failed_candidate', 'baseline_setup_failure', 'source_drift', 'dirty_candidate', 'clean_control']]
(review_dir / 'review.json').write_text(json.dumps({
    'proposal_base_commit': RUNNER,
    'uncommitted_proposed_script': True,
    'runner_sha256': hashlib.sha256(runner_bytes).hexdigest(),
    'scope': 'Uncommitted proposed runner actual main control flow with synthetic Go event streams, snapshots, and intercepted subprocesses. No actual Go or PostgreSQL ran in these six scenarios.',
    'results': results,
}, indent=2) + '\n')
print(json.dumps({'runner_review': str(review_dir / 'review.json'), 'scenarios': [{'kind': r['kind'], 'rejected': r['main_rejected'], 'error': r['error']} for r in results]}, indent=2))
