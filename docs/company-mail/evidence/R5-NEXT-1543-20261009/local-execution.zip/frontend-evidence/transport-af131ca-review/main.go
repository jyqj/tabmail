package main

import (
	"encoding/json"
	"os"
	"fmt"
	"net/mail"
	"net/netip"
	"strings"
)

// addressLiteralHost returns a network host without SMTP's square brackets or
// IPv6 tag. DNS names remain DNS names, including all-digit dotted domains.
// Preserve the untagged IPv6 form net/mail has historically accepted as well.
func addressLiteralHost(domain string) (string, bool, error) {
	if !strings.ContainsAny(domain, "[]") {
		return "", false, nil
	}
	if len(domain) < 2 || domain[0] != '[' || domain[len(domain)-1] != ']' {
		return "", true, fmt.Errorf("invalid SMTP address literal")
	}
	value := domain[1 : len(domain)-1]
	tagged := len(value) >= 5 && strings.EqualFold(value[:5], "IPv6:")
	if tagged {
		value = value[5:]
	}
	ip, err := netip.ParseAddr(value)
	if err != nil || ip.Zone() != "" || (tagged && !ip.Is6()) {
		return "", true, fmt.Errorf("invalid SMTP address literal")
	}
	return ip.String(), true, nil
}

// net/mail rejects RFC 5321's IPv6 tag even though it accepts the same address
// without that tag. Validate the IP first, let net/mail validate the complete
// mailbox with only the tag removed, and restore it only when the parsed
// domain is exactly the selected literal. Quoted local parts, display names,
// comments, and rejection of trailing/multiple addresses stay with net/mail.
func parseRecipientMailbox(value string) (*mail.Address, error) {
	parsed, originalErr := mail.ParseAddress(value)
	if originalErr == nil {
		return parsed, nil
	}
	// Select the actual domain once. Decoy tags in a display name, quoted
	// local part or comment must not cause a complete reparse for every tag.
	start := recipientDomainStart(value)
	if start < 0 || len(value)-start < 6 || !strings.EqualFold(value[start:start+6], "[IPv6:") {
		return nil, originalErr
	}
	end := strings.IndexByte(value[start+6:], ']')
	if end < 0 {
		return nil, originalErr
	}
	end += start + 6
	literal := value[start : end+1]
	if _, _, err := addressLiteralHost(literal); err != nil {
		return nil, originalErr
	}
	bare := "[" + value[start+6:end] + "]"
	candidate, err := mail.ParseAddress(value[:start] + bare + value[end+1:])
	if err == nil && strings.HasSuffix(candidate.Address, "@"+bare) {
		candidate.Address = strings.TrimSuffix(candidate.Address, bare) + literal
		return candidate, nil
	}
	return nil, originalErr
}

// This scan only locates a possible domain. net/mail remains responsible for
// accepting the complete syntax, including mismatched quotes and comments.
func recipientDomainStart(value string) int {
	at, comments := -1, 0
	quoted, escaped := false, false
	for i := 0; i < len(value); i++ {
		c := value[i]
		if escaped {
			escaped = false
			continue
		}
		if (quoted || comments > 0) && c == '\\' {
			escaped = true
			continue
		}
		if comments > 0 {
			if c == '(' {
				comments++
			} else if c == ')' {
				comments--
			}
			continue
		}
		if c == '"' {
			quoted = !quoted
			continue
		}
		if quoted {
			continue
		}
		if c == '(' {
			comments++
		} else if c == '@' {
			at = i
		}
	}
	if at < 0 {
		return -1
	}
	start := at + 1
	for start < len(value) && (value[start] == ' ' || value[start] == '\t') {
		start++
	}
	return start
}


type probeResult struct {
    Name string `json:"name"`
    Input string `json:"input"`
    ControlInput string `json:"control_input"`
    ControlAddress string `json:"untagged_control_address"`
    ControlError string `json:"untagged_control_error"`
    Address string `json:"tagged_address"`
    Error string `json:"tagged_error"`
    Panic string `json:"panic"`
}

func probe(name, value, controlValue string) (result probeResult) {
    result.Name, result.Input, result.ControlInput = name, value, controlValue
    defer func() {
        if caught := recover(); caught != nil { result.Panic = fmt.Sprint(caught) }
    }()
    control, controlErr := mail.ParseAddress(controlValue)
    if controlErr != nil { result.ControlError = controlErr.Error() } else { result.ControlAddress = control.Address }
    parsed, err := parseRecipientMailbox(value)
    if err != nil { result.Error = err.Error() } else { result.Address = parsed.Address }
    return result
}

func main() {
    results := []probeResult{
        probe("ascii_display", "Reader <reader@[IPv6:::1]>", "Reader <reader@[::1]>"),
        probe("unicode_shrinking_display", "K Reader <reader@[IPv6:::1]>", "K Reader <reader@[::1]>"),
        probe("unicode_expanding_display", strings.Repeat("Ⱥ", 16) + " <reader@[IPv6:::1]>", strings.Repeat("Ⱥ", 16) + " <reader@[::1]>"),
        probe("unicode_quoted_local", "\"K\"@[IPv6:::1]", "\"K\"@[::1]"),
        probe("unicode_unquoted_local", "Ⱥ@[IPv6:::1]", "Ⱥ@[::1]"),
        probe("decoy_in_quoted_local", "\"[IPv6:::2] @ K\"@[IPv6:::1]", "\"[IPv6:::2] @ K\"@[::1]"),
        probe("decoy_in_quoted_display", "\"[IPv6:::2] @ Ⱥ\" <reader@[IPv6:::1]>", "\"[IPv6:::2] @ Ⱥ\" <reader@[::1]>"),
        probe("decoy_in_trailing_comment", "reader@[IPv6:::1] (note [IPv6:::2] @ ignored)", "reader@[::1] (note [IPv6:::2] @ ignored)"),
        probe("domain_comment", "user@(comment)[IPv6:::1]", "user@(comment)[::1]"),
        probe("domain_spaced_comment", "user@ (comment) [IPv6:::1]", "user@ (comment) [::1]"),
        probe("domain_nested_decoy_comment", "user@ (outer (nested) @ decoy [IPv6:::2]) [IPv6:::1]", "user@ (outer (nested) @ decoy [IPv6:::2]) [::1]"),
        probe("domain_escaped_comment", "user@(a\\)b) [IPv6:::1]", "user@(a\\)b) [::1]"),
        probe("domain_folded_space", "user@\r\n [IPv6:::1]", "user@\r\n [::1]"),
        probe("domain_tab", "user@\t[IPv6:::1]", "user@\t[::1]"),
    }
    encoder := json.NewEncoder(os.Stdout)
    encoder.SetIndent("", "  ")
    if err := encoder.Encode(results); err != nil { panic(err) }
}
