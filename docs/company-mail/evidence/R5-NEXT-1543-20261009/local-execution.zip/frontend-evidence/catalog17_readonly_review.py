#!/usr/bin/env python3
"""Independent Git/AST/JSON review. Never imports or executes candidate code."""
import argparse
import ast
import functools
import hashlib
import json
from pathlib import Path
import subprocess

ROOT = Path('/workspace/scratch/472e5abb7d28/tabmail')
BASE = '30d2d05ab6ddcc23f47d9b9786885817aef50a0f'
BASE_TREE = 'f3de30fc777b0d9135c4ed9a75005aec8f2835c0'
SOURCE = '2dfebb7692700c14906ceba351e19893fb736656'
SOURCE_TREE = '56c22d9dce089d399e2f58abfa732c045b7ef1c1'
PREVIOUS_SOURCE = 'b6516f9ac873f4464894933b5c3a0e046bc9a4a5'
TEST = 'scripts/tests/test_r5_catalog_reconciliation.py'
DIRECTORY = 'docs/company-mail/evidence/R5-CATALOG-REVISION17-20261009'
UTILITY = 'scripts/prepare_r5_catalog_revision17.py'
CURRENT = 'test_old_pins_reject_and_current_revision_passes_same_actual_facts'
FROZEN = {
    'test_revision16_binds_actual_source_facts_and_preserves_manual_reviews',
    'test_revision16_preserves_public_history_collectors_and_original_rejections',
}
ADDED = {name.replace('revision16', 'revision17') for name in FROZEN}
CURRENT_REPLACEMENTS = [
    ('REVISION16_EXPECTED', 'REVISION17_EXPECTED'),
    ("('revision15', self.rev15_tx, self.rev15_compat)]", "('revision15', self.rev15_tx, self.rev15_compat), ('revision16', self.rev16_tx, self.rev16_compat)]"),
    ('pin = REVISION15_SNAPSHOTS[name]', 'pin = REVISION16_SNAPSHOTS[name]'),
    ("revision['revision'], 16", "revision['revision'], 17"),
    ("revision['previous_snapshot_commit'], REVISION15_COMMIT", "revision['previous_snapshot_commit'], REVISION16_COMMIT"),
]
FIVE_MODULES = [TEST, 'scripts/tests/test_r5_transactions.py', 'scripts/tests/test_r5_compatibility.py',
                'scripts/tests/test_r5_current_source_inventory.py', 'scripts/tests/test_r5_reviewed_web_locks.py']
PRODUCERS = ['scripts/check_r5_transactions.py', 'scripts/check_r5_compatibility.py',
             'scripts/collect_api_calls.cjs', 'cmd/r5txinventory/main.go', 'internal/architecture/route_inventory_test.go']


def git(*args):
    return subprocess.check_output(['git', '-C', str(ROOT), *args])


@functools.lru_cache(maxsize=None)
def raw(commit, path):
    return git('show', commit + ':' + path)


@functools.lru_cache(maxsize=None)
def tree(commit):
    result = {}
    for row in git('ls-tree', '-r', '-z', commit).split(b'\x00'):
        if row:
            fields, path = row.split(b'\t', 1)
            mode, kind, blob = fields.decode().split()
            result[path.decode()] = {'mode': mode, 'kind': kind, 'blob': blob}
    return result


def sha(value):
    return hashlib.sha256(value).hexdigest()


def canonical(value):
    return (json.dumps(value, ensure_ascii=False, indent=2) + '\n').encode()


def dump(value):
    return ast.dump(value, include_attributes=False)


def functions(nodes):
    values = [node for node in nodes if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))]
    assert len(values) == len({node.name for node in values}), 'duplicate function names'
    return {node.name: node for node in values}


def assignments(module):
    values = {}
    for node in module.body:
        if isinstance(node, ast.Assign):
            for target in node.targets:
                if isinstance(target, ast.Name):
                    assert target.id not in values, 'duplicate module assignment'
                    values[target.id] = node.value
    return values


def check(name, condition, detail=None):
    checks.append({'check': name, 'pass': bool(condition), **({'detail': detail} if detail is not None else {})})


def segment(source, node):
    return ast.get_source_segment(source, node)


def pin_check(label, commit, pin, read_bytes=True):
    path = pin['path']
    actual = tree(commit).get(path, {})
    if 'blob' in pin and pin['blob'] is None:
        check(label + ': explicit prior absence', not actual and pin['sha256'] is None and pin['bytes'] is None)
        return
    check(label + ': blob', actual.get('blob') == pin.get('blob', actual.get('blob')))
    if read_bytes:
        value = raw(commit, path)
        check(label + ': sha256/bytes', sha(value) == pin['sha256'] and len(value) == pin['bytes'])


parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--candidate', required=True)
parser.add_argument('--output', type=Path, required=True)
args = parser.parse_args()
candidate = git('rev-parse', '--verify', args.candidate + '^{commit}').decode().strip()
checks = []
candidate_tree = git('rev-parse', candidate + '^{tree}').decode().strip()
check('public product tree', git('rev-parse', SOURCE + '^{tree}').decode().strip() == SOURCE_TREE)
check('previous catalog tree', git('rev-parse', BASE + '^{tree}').decode().strip() == BASE_TREE)
check('frontend proof source subtree equality', git('rev-parse', SOURCE + ':web') == git('rev-parse', 'c4ccf0aca37e3c8f00f94911f608dbd817747fab:web'))

before = raw(BASE, TEST).decode()
after = raw(candidate, TEST).decode()
old_ast, new_ast = ast.parse(before), ast.parse(after)
old_classes = [node for node in old_ast.body if isinstance(node, ast.ClassDef)]
new_classes = [node for node in new_ast.body if isinstance(node, ast.ClassDef)]
check('single unchanged test class identity', len(old_classes) == len(new_classes) == 1 and old_classes[0].name == new_classes[0].name)
old_class, new_class = old_classes[0], new_classes[0]
old_functions, new_functions = functions(old_class.body), functions(new_class.body)
old_tests = {name: node for name, node in old_functions.items() if name.startswith('test_')}
new_tests = {name: node for name, node in new_functions.items() if name.startswith('test_')}
check('35 old / 37 final exact test method set', len(old_tests) == 35 and len(new_tests) == 37 and set(new_tests) == set(old_tests) | ADDED)
for name, node in old_tests.items():
    next_node = new_tests[name]
    if name in FROZEN:
        wrapper = next_node.body[0]
        check(name + ': sole exact historical context', len(next_node.body) == 1 and isinstance(wrapper, ast.With)
              and len(wrapper.items) == 1 and wrapper.items[0].optional_vars is None
              and dump(wrapper.items[0].context_expr) == dump(ast.parse('self.revision16_context()', mode='eval').body))
        check(name + ': original body AST', [dump(item) for item in node.body] == [dump(item) for item in wrapper.body])
        old_lines = before.splitlines(keepends=True)[node.lineno:node.end_lineno]
        wrapped_lines = after.splitlines(keepends=True)[next_node.lineno + 1:next_node.end_lineno]
        unindented = [line[4:] if line.strip() else line for line in wrapped_lines]
        check(name + ': original body bytes', old_lines == unindented)
    elif name == CURRENT:
        expected = segment(before, node)
        for old, new in CURRENT_REPLACEMENTS:
            check('current positive exact single replacement: ' + old, expected.count(old) == 1)
            expected = expected.replace(old, new, 1)
        check('current positive only five approved replacements', segment(after, next_node) == expected)
    else:
        check(name + ': original AST and bytes', dump(node) == dump(next_node) and segment(before, node) == segment(after, next_node))

old_values, new_values = assignments(old_ast), assignments(new_ast)
check('90 old assignments all retained', len(old_values) == 90 and set(old_values) <= set(new_values))
current_globals = {'CURRENT_EVIDENCE', 'SOURCE_COMMIT', 'SOURCE_TREE'}
for name, value in old_values.items():
    if name not in current_globals:
        check('old assignment ' + name, dump(value) == dump(new_values[name]) and segment(before, value) == segment(after, new_values[name]))
check('current source global', ast.literal_eval(new_values['SOURCE_COMMIT']) == SOURCE)
check('current source tree global', ast.literal_eval(new_values['SOURCE_TREE']) == SOURCE_TREE)
check('current evidence global', dump(new_values['CURRENT_EVIDENCE']) == dump(ast.parse("ROOT / '" + DIRECTORY + "'", mode='eval').body))
expected_new_assignments = {'REVISION16_COMMIT', 'REVISION16_TREE', 'REVISION16_SOURCE_COMMIT', 'REVISION16_SOURCE_TREE', 'REVISION16_SNAPSHOTS', 'REVISION17_EXPECTED'}
check('only six expected literal assignments added', set(new_values) - set(old_values) == expected_new_assignments)
for name in expected_new_assignments:
    ast.literal_eval(new_values[name])
check('new revision16 historical commit/tree', ast.literal_eval(new_values['REVISION16_COMMIT']) == BASE
      and ast.literal_eval(new_values['REVISION16_TREE']) == BASE_TREE)
check('new historical product identity', ast.literal_eval(new_values['REVISION16_SOURCE_COMMIT']) == PREVIOUS_SOURCE
      and ast.literal_eval(new_values['REVISION16_SOURCE_TREE']) == git('rev-parse', PREVIOUS_SOURCE + '^{tree}').decode().strip())

old_top_functions, new_top_functions = functions(old_ast.body), functions(new_ast.body)
check('top function additions restricted', set(new_top_functions) - set(old_top_functions) == {'revision16_snapshot'})
for name, node in old_top_functions.items():
    check('unchanged top helper ' + name, dump(node) == dump(new_top_functions[name]) and segment(before, node) == segment(after, new_top_functions[name]))
for name, node in old_functions.items():
    if name.startswith('test_'):
        continue
    next_node = new_functions[name]
    expected = segment(before, node)
    if name == 'setUpClass':
        needle = '        cls.ast = tx.extract()\n'
        addition = "        cls.revision16 = {name: revision16_snapshot(name) for name in REVISION16_SNAPSHOTS}\n        cls.rev16_tx = cls.revision16['transaction']\n        cls.rev16_compat = cls.revision16['compatibility']\n"
        check('setUpClass single historical collection insertion', expected.count(needle) == 1)
        expected = expected.replace(needle, addition + needle, 1)
    check('existing class helper ' + name, segment(after, next_node) == expected)
for name in ['frozen_revision16_root', 'revision16_context']:
    predecessor = old_functions[name.replace('revision16', 'revision15')]
    expected = segment(before, predecessor).replace('revision15', 'revision16').replace('REVISION15', 'REVISION16')
    expected = expected.replace('self.rev15_tx', 'self.rev16_tx').replace('self.rev15_compat', 'self.rev16_compat')
    actual = segment(after, new_functions[name])
    check('same historical helper pattern ' + name, dump(ast.parse(expected.strip()).body[0]) == dump(ast.parse(actual.strip()).body[0]))
    check('same historical helper decorators ' + name, [dump(n) for n in predecessor.decorator_list] == [dump(n) for n in new_functions[name].decorator_list])
expected = segment(before, old_top_functions['revision15_snapshot']).replace('revision15', 'revision16').replace('REVISION15', 'REVISION16')
check('same snapshot byte-validation pattern', dump(ast.parse(expected).body[0]) == dump(new_top_functions['revision16_snapshot']))
check('class method additions restricted', set(new_functions) - set(old_functions) == ADDED | {'frozen_revision16_root', 'revision16_context'})
check('class bases/keywords/decorators unchanged', [dump(n) for n in old_class.bases + old_class.keywords + old_class.decorator_list] == [dump(n) for n in new_class.bases + new_class.keywords + new_class.decorator_list])
check('class non-function executable statements unchanged', [dump(n) for n in old_class.body if not isinstance(n, ast.FunctionDef)] == [dump(n) for n in new_class.body if not isinstance(n, ast.FunctionDef)])
def remainder(module):
    return [dump(node) for node in module.body if not isinstance(node, (ast.Assign, ast.FunctionDef, ast.ClassDef))
            and not (isinstance(node, ast.Expr) and isinstance(node.value, ast.Constant) and isinstance(node.value.value, str))]
check('imports and other top-level executable statements unchanged', remainder(old_ast) == remainder(new_ast))

review = json.loads(raw(candidate, DIRECTORY + '/reconciliation.json'))
expected = ast.literal_eval(new_values['REVISION17_EXPECTED'])
check('review public source identity', review['source_commit'] == SOURCE and review['source_tree'] == SOURCE_TREE)
check('review previous catalog/product identity', review['previous_catalog_commit'] == BASE and review['previous_product_source_commit'] == PREVIOUS_SOURCE)
check('maintenance grants no completion/runtime acceptance', review['implementation_todos_completed'] == 0
      and all(review[key] is False for key in ['runtime_verified', 'product_green', 'task_complete'])
      and review['parent_tasks'] == {'accepted': 10, 'total': 171, 'remaining': 161})
check('expected transaction/compatibility match review', expected['transaction'] == review['transaction'] and expected['compatibility'] == review['compatibility'])
for key, value in review.items():
    if key.endswith('_sha256') and key[:-7] in review:
        check('review canonical digest ' + key, sha(canonical(review[key[:-7]])) == value)

catalog_paths = set()
for name, pin in review['revision16_snapshots'].items():
    check('snapshot old commit ' + name, pin['commit'] == BASE)
    pin_check('revision16 ' + name, BASE, pin)
    expected_pin = {key: value for key, value in pin.items() if key != 'commit'}
    check('test literal same old snapshot ' + name, ast.literal_eval(new_values['REVISION16_SNAPSHOTS'])[name] == expected_pin)
for name, pin in review['generated_catalogs'].items():
    catalog_paths.add(pin['path'])
    pin_check('generated ' + name, candidate, pin)
    document = json.loads(raw(candidate, pin['path']))
    if isinstance(document, dict):
        revision = document['inventory_revision']
        check('generated revision pins ' + name, revision['revision'] == 17 and revision['source_commit'] == SOURCE
              and revision['previous_snapshot_commit'] == BASE and revision['previous_snapshot_blob'] == tree(BASE)[pin['path']]['blob'])
        check('generated qualification remains false ' + name, document['task_complete'] is False
              and all(document.get(key, False) is False for key in ['runtime_verified', 'product_green']))

allowed_changed = catalog_paths | {TEST, 'scripts/tests/test_r5_transactions.py', 'scripts/tests/test_r5_compatibility.py', UTILITY,
                                  DIRECTORY + '/README.md', DIRECTORY + '/reconciliation.json'}
changed_paths = set(git('diff', '--name-only', SOURCE, candidate).decode().splitlines())
check('only catalog/author/test-maintenance files changed from public product', changed_paths <= allowed_changed,
      sorted(changed_paths - allowed_changed))
for path in FIVE_MODULES + PRODUCERS:
    check('original source unchanged before maintenance ' + path, raw(BASE, path) == raw(SOURCE, path))
for path in PRODUCERS:
    check('original producer candidate bytes ' + path, raw(SOURCE, path) == raw(candidate, path)
          and sha(raw(candidate, path)) == review['unchanged_validators_and_collectors'][path])
for path in FIVE_MODULES:
    if path == TEST:
        continue
    original = raw(BASE, path).decode()
    if path.endswith('test_r5_transactions.py'):
        original = original.replace("result['functions'], 405", "result['functions'], %d" % review['transaction']['functions'], 1)
        original = original.replace("result['postgres_files'], 64", "result['postgres_files'], %d" % review['transaction']['postgres_files'], 1)
    elif path.endswith('test_r5_compatibility.py'):
        original = original.replace("result['routes'],133", "result['routes'],%d" % review['compatibility']['routes'], 1)
        original = original.replace("result['client_branches'],136", "result['client_branches'],%d" % review['compatibility']['client_branches'], 1)
    check('original five-module scope only allowed current counts ' + path, raw(candidate, path).decode() == original)
check('workflow qualification unchanged', raw(SOURCE, '.github/workflows/catalog-reconciliation.yml') == raw(candidate, '.github/workflows/catalog-reconciliation.yml'))

for pin in review['historical_manifest']:
    check('historical blob retained ' + pin['path'], tree(BASE)[pin['path']]['blob'] == tree(candidate)[pin['path']]['blob'] == pin['blob'])
    pin_check('historical pin ' + pin['path'], candidate, pin)
protected = {path for path in tree(SOURCE) if path.startswith(('scripts/', '.github/workflows/', 'cmd/r5txinventory/'))
             or path == 'internal/architecture/route_inventory_test.go'}
mutable = {TEST, 'scripts/tests/test_r5_transactions.py', 'scripts/tests/test_r5_compatibility.py'}
check('complete protected source manifest path set', {pin['path'] for pin in review['protected_source_manifest']} == (protected - mutable) | {UTILITY})
for pin in review['protected_source_manifest']:
    path = pin['path']
    commit = candidate if path == UTILITY else SOURCE
    check('protected candidate blob equals reviewed source ' + path, tree(candidate)[path]['blob'] == tree(commit)[path]['blob'])
    pin_check('protected pin ' + path, commit, pin)
for row in review['source_changes']:
    check('product source change commits ' + row['path'], row['before_commit'] == PREVIOUS_SOURCE and row['after_commit'] == SOURCE)
    for prefix, commit in [('before', PREVIOUS_SOURCE), ('after', SOURCE)]:
        pin = {'path': row['path'], 'blob': row[prefix + '_blob'], 'sha256': row[prefix + '_sha256'], 'bytes': row[prefix + '_bytes']}
        pin_check('product change ' + prefix + ' ' + row['path'], commit, pin)

actual_product_changes = [path for path in git('diff', '--name-only', PREVIOUS_SOURCE, SOURCE, '--', 'internal', 'cmd', 'web').decode().splitlines()
                          if (path.endswith('.go') and not path.endswith('_test.go'))
                          or (path.endswith(('.ts', '.tsx', '.css')) and '.test.' not in path)
                          or (path.startswith('web/locales/') and path.endswith('.json'))]
check('complete changed product path enumeration', actual_product_changes == [row['path'] for row in review['source_changes']])
tx_path = review['generated_catalogs']['transaction']['path']
old_tx, new_tx = json.loads(raw(BASE, tx_path)), json.loads(raw(candidate, tx_path))
check('transaction migrations and previous review metadata unchanged', old_tx['migrations'] == new_tx['migrations']
      and old_tx['historical_review_metadata'] == new_tx['historical_review_metadata'])
actual_pg_files = {path for path in tree(SOURCE) if path.startswith('internal/store/postgres/') and path.endswith('.go') and not path.endswith('_test.go')}
check('all 64 PostgreSQL files enumerated', len(actual_pg_files) == 64 and actual_pg_files == {row['path'] for row in new_tx['postgres_files']})
for row in new_tx['postgres_files']:
    check('PostgreSQL source digest ' + row['path'], sha(raw(SOURCE, row['path'])) == row['sha256'])
old_entries = {row['id']: row for row in old_tx['entries']}
new_entries = {row['id']: row for row in new_tx['entries']}
check('one exact new ledger function / no removals', len(old_entries) == 405 and len(new_entries) == 406
      and set(new_entries) - set(old_entries) == {'internal/store/postgres/company_ops.go::lockReconciliationLedger'}
      and set(old_entries) <= set(new_entries))
manual_fields = ('lock_fk_wait_fence', 'evidence', 'unverified_risks', 'file_family_context', 'source_review')
reviewed_ids = {row['id'] for row in review['transaction_body_changes']}
check('only the three reviewed product bodies changed', reviewed_ids == {
    'internal/store/postgres/company_members.go:*PgStore:SetWorkGrant',
    'internal/store/postgres/company_ops.go:*PgStore:ReconcileOutbound',
    'internal/store/postgres/postgres.go::New',
})
for identity, entry in old_entries.items():
    prior_manual = {key: entry[key] for key in manual_fields if key in entry}
    current_entry = new_entries[identity]
    if identity in reviewed_ids:
        check('reviewed prior manual fields archived exactly ' + identity, current_entry['historical_revision16_review'] == prior_manual)
        check('new manual review/source pin ' + identity, {key: current_entry[key] for key in manual_fields} == review['manual_review_fields'][identity]
              and current_entry['source_review']['base_commit'] == SOURCE
              and current_entry['source_review']['source_sha256'] == current_entry['syntax']['sha256'])
    else:
        check('unmodified function manual fields retained ' + identity, prior_manual == {key: current_entry[key] for key in manual_fields if key in current_entry})
for path, old_review in old_tx['reviewed_file_types'].items():
    new_review = new_tx['reviewed_file_types'][path]
    if path in review['transaction_file_review_additions']:
        check('file review exact append ' + path, set(new_review) == set(old_review) | {'revision17_additions'}
              and {key: value for key, value in new_review.items() if key != 'revision17_additions'} == old_review
              and new_review['revision17_additions'] == review['transaction_file_review_additions'][path])
    else:
        check('unchanged file review ' + path, new_review == old_review)

compat_path = review['generated_catalogs']['compatibility']['path']
old_compat, new_compat = json.loads(raw(BASE, compat_path)), json.loads(raw(candidate, compat_path))
allowed_compat = {'inventory_revision', 'acquisition', 'routes', 'source_closure'}
check('compatibility manual/qualification metadata retained', {key: value for key, value in old_compat.items() if key not in allowed_compat}
      == {key: value for key, value in new_compat.items() if key not in allowed_compat})
old_routes = {row['route']: row for row in old_compat['routes']}
new_routes = {row['route']: row for row in new_compat['routes']}
check('all 133 original routes retained', len(old_routes) == len(new_routes) == 133 and set(old_routes) == set(new_routes))
for identity, old_route in old_routes.items():
    current_route = new_routes[identity]
    check('route fields other than current client facts retained ' + identity,
          {key: value for key, value in old_route.items() if key != 'clients'} == {key: value for key, value in current_route.items() if key != 'clients'})
check('finite closure count remains bound', len(new_compat['source_closure']) == review['compatibility']['source_files'] == 97)
for path, digest in new_compat['source_closure'].items():
    check('finite closure actual candidate SHA ' + path, sha(raw(candidate, path)) == digest)

guards = {name for name in old_tests if name.startswith('test_unapproved_')}
check('five original negative controls retained in report', len(guards) == 5 and set(review['original_unapproved_methods']) == guards)
for name in guards:
    recorded = review['original_unapproved_methods'][name]
    check('negative control evidence hash ' + name, recorded == {'source_sha256': sha(segment(before, old_tests[name]).encode()), 'ast_sha256': sha(dump(old_tests[name]).encode())})

result = {
    'scope': 'Independent read-only Git object, AST, and JSON review; no candidate imports, producer reruns, product tests, databases, or worktree writes.',
    'candidate_commit': candidate, 'candidate_tree': candidate_tree,
    'public_product_commit': SOURCE, 'public_product_tree': SOURCE_TREE,
    'previous_catalog_commit': BASE, 'previous_catalog_tree': BASE_TREE,
    'old_methods': len(old_tests), 'candidate_methods': len(new_tests), 'old_assignments': len(old_values),
    'changed_paths': sorted(changed_paths),
    'historical_files': len(review['historical_manifest']),
    'protected_source_files': len(review['protected_source_manifest']),
    'reconciliation_module_sha256': sha(raw(candidate, TEST)),
    'review_json_sha256': sha(raw(candidate, DIRECTORY + '/reconciliation.json')),
    'checks_passed': sum(row['pass'] for row in checks),
    'checks_failed': sum(not row['pass'] for row in checks),
    'checks': checks,
}
args.output.parent.mkdir(parents=True, exist_ok=True)
args.output.write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({key: value for key, value in result.items() if key != 'checks'}, indent=2))
if result['checks_failed']:
    print(json.dumps([row for row in checks if not row['pass']], indent=2))
    raise SystemExit(1)
