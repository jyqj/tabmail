"""Preserve observed source-validation records without rerunning or upgrading them."""
from pathlib import Path
import hashlib
import json
import re
import subprocess

BASE = Path('/workspace/scratch/472e5abb7d28')
ROOT = BASE / 'tabmail-catalog17'
EVIDENCE = BASE / 'backend-evidence'
OUTPUT = EVIDENCE / 'catalog17-validation-packet-v2'
OLD = dict(commit='72f3f93301584513e8e2c2c9dc66653f7cea8fc0', tree='fdf1cefafa4fd943f67b38b9ec3d7a3b2852efcf', status='')
NEW = dict(commit='85f99510ad805390c0b2dcf34a6b4b45909d82ae', tree='e84e389228cc19bedc7dee81adff2e024cb10d46', status='')
OLD_PRODUCT = dict(commit='2dfebb7692700c14906ceba351e19893fb736656', tree='56c22d9dce089d399e2f58abfa732c045b7ef1c1', status='')
NEW_PRODUCT = dict(commit='17be458fb9d36e135a95962638b68ce105c16518', tree='fd362eed901840f23f58b477104a642f2a6cbf51', status='')

def canonical(value):
    return (json.dumps(value, ensure_ascii=False, indent=2) + '\n').encode()

def pin(raw):
    return dict(bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())

def git(*args):
    return subprocess.check_output(['git', '-C', str(ROOT), *args])

def load(path):
    return json.loads(path.read_text())

assert not OUTPUT.exists()
assert git('rev-parse', 'HEAD').decode().strip() == NEW['commit']
assert git('rev-parse', 'HEAD^{tree}').decode().strip() == NEW['tree']
assert not git('status', '--porcelain', '--untracked-files=all').strip()
for identity in (OLD, NEW, OLD_PRODUCT, NEW_PRODUCT):
    assert git('rev-parse', identity['commit'] + '^{tree}').decode().strip() == identity['tree']
OUTPUT.mkdir()
artifacts = {}

def copy(source, relative):
    raw = source.read_bytes()
    destination = OUTPUT / relative
    assert destination.resolve().is_relative_to(OUTPUT)
    assert not destination.exists()
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_bytes(raw)
    artifacts[relative] = dict(original_local_path=str(source), **pin(raw))

observations = {}
for label, folder, identity, full_exit in (
        ('previous-candidate', 'catalog17-validation-01', OLD, 1),
        ('current-candidate', 'catalog17-validation-06', NEW, None)):
    source = EVIDENCE / folder
    names = ['transactions', 'compatibility', 'clients', 'five-modules']
    if full_exit is not None:
        names.append('source-version')
    commands = {}
    for name in names:
        receipt = load(source / (name + '.receipt.json'))
        expected_exit = full_exit if name == 'source-version' else 0
        assert receipt['exit_code'] == expected_exit
        assert receipt['before'] == receipt['after'] == identity
        assert (source / (name + '.exit')).read_text() == str(expected_exit) + '\n'
        for stream in ('stdout', 'stderr'):
            assert receipt[stream] == pin((source / (name + '.' + stream)).read_bytes())
        for suffix in ('stdout', 'stderr', 'exit', 'receipt.json'):
            copy(source / (name + '.' + suffix), label + '/' + name + '.' + suffix)
        commands[name] = receipt
    raw = (source / 'five-modules.stderr').read_text()
    assert re.search(r'^Ran 104 tests in [0-9.]+s$', raw, re.M)
    assert raw.rstrip().endswith('OK')
    assert not re.search(r'\.\.\. (?:FAIL|ERROR|skipped|expected failure)', raw)
    for name in ('source-before.json', 'typescript-preparation.json', 'original-commands.json'):
        copy(source / name, label + '/' + name)
    observations[label] = dict(source=identity, command_exit_codes={name: row['exit_code'] for name, row in commands.items()},
        five_original_modules=dict(tests_run=104, passed=104, failures=0, errors=0, skips=0),
        complete_source_version_executed=(full_exit is not None))

old_records = EVIDENCE / 'catalog17-validation-01'
full = load(old_records / 'source-version.json')
assert full['status'] == 'failed'
assert full['no_missing'] and full['no_overlap'] and full['dispatch_no_missing'] and full['dispatch_no_overlap']
assert not full['missing_test_ids']
assert len(full['groups']) == 2
actual = []
groups = []
for group in full['groups']:
    report = group['report']
    expected_sha = OLD['commit'] if group['group'] == 'current' else '41b015c30c66b3ba58a3c1395e8559ebcd27a65f'
    assert group['source_sha'] == report['source_sha'] == expected_sha
    assert report['actual_test_ids'] == report['loaded_test_ids'] == group['requested_test_ids']
    assert report['tests_run'] == len(report['actual_test_ids'])
    assert not any(report[key] for key in ('skips', 'expected_failures', 'unexpected_successes', 'missing_test_ids'))
    if group['group'] == 'current':
        assert group['exit'] == 1 and report['tests_run'] == 869
        assert len(report['failures']) == 4 and len(report['errors']) == 6
    else:
        assert group['exit'] == 0 and report['tests_run'] == 4
        assert not report['failures'] and not report['errors']
    actual.extend(report['actual_test_ids'])
    groups.append(dict(group=group['group'], source_sha=expected_sha, tests_run=report['tests_run'],
        exit_code=group['exit'], failures=report['failures'], error_entries=report['errors'], skips=report['skips']))
assert len(actual) == len(set(actual)) == len(full['discovered_test_ids']) == 873
assert set(actual) == set(full['discovered_test_ids'])
assert full['preparation']['source_sha'] == OLD['commit'] and full['preparation']['go_selection_unchanged']
observations['previous-candidate']['complete_source_version'] = dict(status='failed', discovered_tests=873, actual_tests=873,
    groups=groups, skips=0, missing=0, overlap=0, accepted=False,
    interpretation='Four failure IDs and six error entries remain red. Error entries include subtests; no pass total is inferred by subtracting entries.')
copy(old_records / 'source-version.json', 'previous-candidate/source-version.json')
preparation = Path(full['preparation_output'])
for path in sorted(preparation.rglob('*')):
    if path.is_file() and (path.suffix in {'.json', '.jsonl', '.stdout', '.stderr', '.txt'} or path.name.endswith('.log')):
        copy(path, 'previous-candidate/source-preparation/' + str(path.relative_to(preparation)))
observations['current-candidate']['complete_source_version'] = dict(status='pending-original-ci', executed=False,
    accepted=False, reason='The original full runner is required in its supported CI environment; local checks are not weakened or substituted.')

for label, folder, product in (
        ('previous-generation', 'catalog17-generation-01', OLD_PRODUCT),
        ('current-generation', 'catalog17-generation-03', NEW_PRODUCT)):
    source = EVIDENCE / folder
    assert load(source / 'source-before.json') == load(source / 'source-after-original-collection.json') == product
    for stage, expected_exit in (('baseline', 1), ('generated', 0)):
        for name in ('transactions', 'compatibility', 'clients'):
            receipt = load(source / stage / (name + '.receipt.json'))
            assert receipt['exit_code'] == expected_exit and receipt['before'] == receipt['after']
            assert receipt['before']['commit'] == product['commit'] and receipt['before']['tree'] == product['tree']
            assert bool(receipt['before']['status']) == (stage == 'generated')
            assert (source / stage / (name + '.exit')).read_text() == str(expected_exit) + '\n'
            for stream in ('stdout', 'stderr'):
                assert receipt[stream] == pin((source / stage / (name + '.' + stream)).read_bytes())
            for suffix in ('stdout', 'stderr', 'exit', 'receipt.json'):
                copy(source / stage / (name + '.' + suffix), label + '/' + stage + '/' + name + '.' + suffix)
    for name in ('invocation-before.json', 'invocation-after.json', 'source-before.json',
                 'source-after-original-collection.json', 'candidate-generation-source.json',
                 'baseline-validation.json', 'generated-cli-validation.json', 'result.json'):
        copy(source / name, label + '/' + name)

for name in ('catalog17-generation-02', 'catalog17-validation-02', 'catalog17-validation-03', 'catalog17-validation-04', 'catalog17-validation-05'):
    copy(EVIDENCE / (name + '.log'), 'preparation-attempts/' + name + '.log')
    for detail in ('invocation-before.json', 'author-failure.json', 'source-before.json', 'observed-source-diagnostic.json'):
        path = EVIDENCE / name / detail
        if path.is_file():
            copy(path, 'preparation-attempts/' + name + '/' + detail)
for path in sorted((EVIDENCE / 'catalog17-validation-05').iterdir()):
    if path.is_file() and (path.suffix in {'.stdout', '.stderr', '.exit'} or path.name.endswith('.receipt.json')):
        copy(path, 'preparation-attempts/catalog17-validation-05/' + path.name)

oracle_path = 'internal/store/postgres/r5_frozen_mailbox_grant_test.go'
oracle_old = git('show', OLD_PRODUCT['commit'] + ':' + oracle_path)
oracle_new = git('show', NEW_PRODUCT['commit'] + ':' + oracle_path)
old_predicate = b"FROM outbox_events WHERE tenant_id=$1"
new_predicate = b"FROM outbox_events WHERE payload->>'tenant_id'=$1::text"
assert oracle_old.count(old_predicate) == oracle_new.count(new_predicate) == 1
assert oracle_new.replace(new_predicate, old_predicate, 1) == oracle_old
assert pin(oracle_old)['sha256'] == 'b7a101baab0b031f6dd803aabdac79dff5c36210094c5c5c6ae49db05c0f48f6'
assert pin(oracle_new)['sha256'] == '39d0360a979914e3aac33aa6541b44bd6794480dd792173ab197f3c74c5ceb1f'
for name, raw in (('oracle-v1.go.txt', oracle_old), ('oracle-v2.go.txt', oracle_new)):
    source = EVIDENCE / 'frozen-mailbox-grant-corrigendum' / name
    assert source.read_bytes() == raw
    copy(source, 'oracle-corrigendum/' + name)
corrigendum = dict(path=oracle_path, previous_product_source=OLD_PRODUCT, corrected_product_source=NEW_PRODUCT,
    old_oracle=pin(oracle_old), corrected_oracle=pin(oracle_new),
    old_predicate=old_predicate.decode(), corrected_predicate=new_predicate.decode(),
    inverse_single_replacement_reproduces_original_bytes=True,
    assertion_bodies_other_than_snapshot_predicate_unchanged=True,
    original_oracle_qualified=False,
    original_pg_failure_evidence=dict(
        job_url='https://github.com/jyqj/tabmail/actions/runs/37903966166/job/113732833358',
        artifact_id=11604646928,
        original_local_json=str(BASE / 'pr-audit-artifacts/pg-wave2-mailbox-result.json'),
        json_sha256='f196d85277822af58e2dd71c90053276d05150ffb6bf10e1be5dca0f1f77bbf1',
        original_local_job_log=str(BASE / 'pr-audit-artifacts/pg-wave2-mailbox-113732833358.log'),
        job_log_sha256='f9c26cc6479fc085834c4ef05493a68baab47132e7a7c930fdc5e14be401408d',
        stored_in_this_packet=False,
        intended_product_evidence_directory='docs/company-mail/evidence/R5-NEXT-1543-20261009/',
        directory_publication_asserted=False,
        baseline=dict(passed=1, failed=13, skipped=0, exit_code=1),
        candidate=dict(passed=2, failed=12, skipped=0, exit_code=1)))
(OUTPUT / 'oracle-corrigendum/proof.json').write_bytes(canonical(corrigendum))

for source, name in (
        (BASE / 'frontend-evidence/catalog17-independent/review.json', 'previous-static-review.json'),
        (BASE / 'frontend-evidence/catalog17-independent/source-version-failure-review.json', 'previous-full-failure-review.json'),
        (BASE / 'pr-audit-artifacts/catalog-v2-incremental-review.json', 'current-incremental-static-review.json')):
    copy(source, 'independent-reviews/' + name)

summary = dict(schema_version=1, previous_product_source=OLD_PRODUCT, current_product_source=NEW_PRODUCT,
    observations=observations, artifacts=artifacts,
    preparation_attempts='Original clean-source and absent-node_modules checks refused setup/source-recording attempts. Exact error logs are preserved; none executed product acceptance or upgrades a result.',
    current_candidate_isolation=dict(ordinary_git_clone=True, shared_git_objects=False,
        local_path=str(EVIDENCE / 'catalog17-clean-validation-checkout'),
        python_bytecode_suppressed=True, original_checks_unchanged=True),
    preservation=dict(old_methods=35, unchanged_whole_methods=32, unchanged_historical_bodies_in_frozen_context=2,
        current_positive_exact_pin_replacements=5, new_current_methods=2, old_assignments=90,
        unchanged_assignment_values=87, original_rejection_guards_unchanged=5),
    implementation_todos_completed=0, runtime_verified=False, product_green=False, task_complete=False,
    parent_tasks=dict(accepted=10, total=171, remaining=161),
    qualification='Observed local source checks at explicitly identified committed candidates. The enclosing evidence commit was not executed by these receipts. Full original source-version CI and product PostgreSQL acceptance retain separate identities and results.')
(OUTPUT / 'receipt.json').write_bytes(canonical(summary))
(OUTPUT / 'README.md').write_text('''# Observed catalog source validation

This packet preserves both local catalog candidates. Raw receipts retain their original paths, stdout, stderr, exit codes, and clean before/after Git identities. Adding this evidence afterward does not claim the enclosing commit was executed.

| Observed candidate | Bound product source | Original three CLIs | Original five modules | Full original source-version runner |
| --- | --- | --- | --- | --- |
| `72f3f93301584513e8e2c2c9dc66653f7cea8fc0` | `2dfebb7692700c14906ceba351e19893fb736656` | All exit 0 | 104 passed, zero skips | Exit 1; 873 unique tests executed, four failure IDs and six error entries; no skips, omissions or overlap |
| `85f99510ad805390c0b2dcf34a6b4b45909d82ae` | `17be458fb9d36e135a95962638b68ce105c16518` | All exit 0 | 104 passed, zero skips | Pending execution by the original CI; not run locally on this candidate |

The first full run remains a failure. Its current-source group ran 869 tests at `72f3f93`; four failures concern process cleanup and the fake Node-version diagnostic. Its six error entries comprise three fake Node-version command errors and three AF_UNIX socket EPERM entries. Only the socket errors establish an explicit permission restriction; the cleanup/version results remain failed assertions or commands without assuming their cause. Its four frozen-v1 tests passed at their original source `41b015c30c66b3ba58a3c1395e8559ebcd27a65f`. The exact failing tracebacks and original complete report are retained. Error entries include subtests, so subtracting them from the executed count would not produce a justified pass count. No process-group, Unix-socket, cleanup, toolchain, or historical guard was weakened.

Both generations ran the unchanged original three CLIs against their exact clean product checkout with revision-16 catalogs and observed exit 1 from actual catalog drift. After changing only the four proposed catalog files in a disposable generation clone, all three exited 0. These dirty generation results remain distinct from the later clean committed-candidate checks. Preparation attempts rejected by the original clean-source or absent-node_modules requirements are also retained as failed setup attempts.

The public product-source correction changed only the outbox tenant predicate in the mailbox-grant regression fixture. `oracle-corrigendum/` retains both complete frozen oracle versions and proves that reverting this one predicate reproduces the original bytes. The original PostgreSQL run failed: baseline 1 pass / 13 failures and candidate 2 passes / 12 failures, with zero skips and exit 1 for both. Twelve candidate cases were blocked by the nonexistent `outbox_events.tenant_id` fixture query. The separate product evidence owner retains those original CI logs; their fixed references and hashes are recorded here without claiming that the intended `R5-NEXT-1543-20261009` directory was already published when this packet was assembled. New PostgreSQL acceptance must use the newly frozen oracle on both source versions.

This maintenance completes zero implementation TODOs. `runtime_verified`, `product_green`, and `task_complete` remain false; original parent acceptance remains 10/171 with 161 remaining. Complete source-version CI and PostgreSQL product acceptance are separate gates with their own observed source identities.
''', encoding='utf-8')
print(json.dumps(dict(output=str(OUTPUT), copied_artifacts=len(artifacts), receipt=pin((OUTPUT / 'receipt.json').read_bytes()))))
