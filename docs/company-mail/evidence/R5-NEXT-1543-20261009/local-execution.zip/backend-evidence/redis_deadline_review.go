package main

import (
    "context"
    "fmt"
    "strings"
    "sync"
    "sync/atomic"
    "time"

    "github.com/alicebob/miniredis/v2"
    "github.com/alicebob/miniredis/v2/server"
    "github.com/redis/go-redis/v9"
)

func probe(enabled bool) {
    mr, err := miniredis.Run()
    if err != nil { panic(err) }
    defer mr.Close()
    client := redis.NewClient(&redis.Options{Addr: mr.Addr(), ContextTimeoutEnabled: enabled})
    defer client.Close()
    if err := client.Ping(context.Background()).Err(); err != nil { panic(err) }
    unblock := make(chan struct{})
    var attempts atomic.Int64
    mr.Server().SetPreHook(func(peer *server.Peer, cmd string, args ...string) bool {
        if strings.EqualFold(cmd, "eval") {
            attempts.Add(1)
            <-unblock
            peer.WriteInt(1)
            return true
        }
        return false
    })
    time.AfterFunc(7*time.Second, func(){ close(unblock) })
    parent, cancelParent := context.WithCancel(context.Background())
    cancelParent()
    cleanup, cancel := context.WithTimeout(context.WithoutCancel(parent), 5*time.Second)
    defer cancel()
    started := time.Now()
    _, err = client.Eval(cleanup, `return 1`, nil).Result()
    fmt.Printf("ContextTimeoutEnabled=%v elapsed=%v ctx=%v result=%v socket_EVAL_attempts=%d\n", enabled, time.Since(started), cleanup.Err(), err, attempts.Load())
}

func main() {
    var joined sync.WaitGroup
    for _, enabled := range []bool{false, true} {
        joined.Add(1)
        go func(enabled bool){ defer joined.Done(); probe(enabled) }(enabled)
    }
    joined.Wait()
}
