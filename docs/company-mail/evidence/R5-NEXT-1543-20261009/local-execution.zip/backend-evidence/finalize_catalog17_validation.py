from pathlib import Path
import datetime
import hashlib
import json
import re
import subprocess

root = Path('/workspace/scratch/472e5abb7d28/tabmail-catalog17')
records = Path('/workspace/scratch/472e5abb7d28/backend-evidence/catalog17-validation-01')
generation = Path('/workspace/scratch/472e5abb7d28/backend-evidence/catalog17-generation-01')
destination = root / 'docs/company-mail/evidence/R5-CATALOG-REVISION17-20261009/validation'
source_sha = '72f3f93301584513e8e2c2c9dc66653f7cea8fc0'
source_tree = 'fdf1cefafa4fd943f67b38b9ec3d7a3b2852efcf'
product_sha = '2dfebb7692700c14906ceba351e19893fb736656'
product_tree = '56c22d9dce089d399e2f58abfa732c045b7ef1c1'

def git(*args):
    return subprocess.check_output(['git', '-C', str(root), *args], text=True).strip()

def pin(raw):
    return {'sha256': hashlib.sha256(raw).hexdigest(), 'bytes': len(raw)}

def canonical(value):
    return (json.dumps(value, ensure_ascii=False, indent=2) + '\n').encode()

assert git('rev-parse', 'HEAD') == source_sha
assert git('rev-parse', 'HEAD^{tree}') == source_tree
assert not git('status', '--porcelain', '--untracked-files=all')
assert not destination.exists()
identity = {'commit': source_sha, 'tree': source_tree, 'status': ''}
commands = {}
for name in ('transactions', 'compatibility', 'clients', 'five-modules', 'source-version'):
    receipt = json.loads((records / (name + '.receipt.json')).read_text())
    assert receipt['exit_code'] == 0
    assert receipt['before'] == receipt['after'] == identity
    for stream in ('stdout', 'stderr'):
        raw = (records / (name + '.' + stream)).read_bytes()
        assert receipt[stream] == pin(raw)
    assert (records / (name + '.exit')).read_text() == '0\n'
    commands[name] = receipt
five_output = (records / 'five-modules.stderr').read_text()
assert re.search(r'^Ran 104 tests in [0-9.]+s$', five_output, re.M)
assert five_output.rstrip().endswith('OK')
assert not re.search(r'\.\.\. (?:FAIL|ERROR|skipped|expected failure)', five_output)
full = json.loads((records / 'source-version.json').read_text())
assert full['status'] == 'pass' and full['no_missing'] and full['no_overlap']
assert full['dispatch_no_missing'] and full['dispatch_no_overlap'] and not full['missing_test_ids']
assert len(full['groups']) == 2
actual = []
groups = []
for group in full['groups']:
    report = group['report']
    assert group['exit'] == 0
    assert report['actual_test_ids'] == report['loaded_test_ids'] == group['requested_test_ids']
    assert report['tests_run'] == len(report['actual_test_ids'])
    assert not any(report[key] for key in ('failures', 'errors', 'skips', 'expected_failures', 'unexpected_successes', 'missing_test_ids'))
    expected_sha = source_sha if group['group'] == 'current' else '41b015c30c66b3ba58a3c1395e8559ebcd27a65f'
    assert group['source_sha'] == report['source_sha'] == expected_sha
    if group['group'] == 'frozen-v1':
        assert report['tests_run'] == 4
    actual.extend(report['actual_test_ids'])
    groups.append({'group': group['group'], 'source_sha': expected_sha, 'tests_run': report['tests_run'], 'exit_code': 0})
assert len(actual) == len(set(actual)) == len(full['discovered_test_ids'])
assert set(actual) == set(full['discovered_test_ids'])
assert full['preparation']['source_sha'] == source_sha
assert full['preparation']['go_selection_unchanged']

copied = {}
def copy(source, name):
    raw = source.read_bytes()
    target = destination / name
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(raw)
    copied[name] = pin(raw)

for name in ('transactions', 'compatibility', 'clients'):
    for suffix in ('stdout', 'stderr', 'exit', 'receipt.json'):
        copy(generation / 'baseline' / (name + '.' + suffix), 'baseline/' + name + '.' + suffix)
for name in ('transactions', 'compatibility', 'clients', 'five-modules', 'source-version'):
    for suffix in ('stdout', 'stderr', 'exit', 'receipt.json'):
        copy(records / (name + '.' + suffix), 'candidate/' + name + '.' + suffix)
for name in ('source-before.json', 'typescript-preparation.json', 'source-version.json'):
    copy(records / name, 'candidate/' + name)
copy(generation / 'baseline-validation.json', 'baseline/baseline-validation.json')
copy(generation / 'source-before.json', 'baseline/source-before.json')
copy(generation / 'source-after-original-collection.json', 'baseline/source-after-original-collection.json')

receipt = {
    'schema_version': 1,
    'observed_at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'product_source': {'commit': product_sha, 'tree': product_tree},
    'tested_catalog_candidate': identity,
    'catalog_generation_invocation': json.loads((generation / 'invocation-before.json').read_text()),
    'baseline_original_cli_exits': {name: 1 for name in ('transactions', 'compatibility', 'clients')},
    'committed_candidate_exits': {name: row['exit_code'] for name, row in commands.items()},
    'five_original_modules': {'tests_run': 104, 'passed': 104, 'failures': 0, 'errors': 0, 'skips': 0},
    'complete_original_source_version_runner': {
        'status': full['status'], 'discovered_tests': len(full['discovered_test_ids']),
        'actual_tests': len(actual), 'groups': groups,
        'failures': 0, 'errors': 0, 'skips': 0, 'missing': 0, 'duplicates': 0,
    },
    'source_unchanged_clean': True,
    'preservation': {
        'old_methods': 35, 'whole_methods_byte_and_ast_unchanged': 32,
        'historical_bodies_unchanged_in_frozen_context': 2,
        'current_positive_exact_pin_replacements': 5, 'new_current_methods': 2,
        'old_assignments': 90, 'unchanged_assignment_values': 87,
        'advanced_current_source_globals': ['CURRENT_EVIDENCE', 'SOURCE_COMMIT', 'SOURCE_TREE'],
        'original_unapproved_rejection_guards_unchanged': 5,
    },
    'artifacts': copied,
    'implementation_todos_completed': 0,
    'runtime_verified': False,
    'product_green': False,
    'task_complete': False,
    'parent_tasks': {'accepted': 10, 'total': 171, 'remaining': 161},
    'qualification': 'Original source-validation and preservation checks on the explicitly identified clean local catalog candidate. This packet is added afterward as documentation only; it does not claim that a later public commit was executed, that PostgreSQL acceptance ran, or that product/release/parent acceptance is complete.',
}
(destination / 'receipt.json').write_bytes(canonical(receipt))
(destination / 'README.md').write_text(
    '# Observed local catalog validation\n\n'
    f'All commands below ran on clean committed candidate `{source_sha}` / tree `{source_tree}`. '
    'The enclosing evidence-only commit is later than the tested candidate.\n\n'
    f'Its product source is the published wave-3 head `{product_sha}` / tree `{product_tree}`. '
    'The original three CLIs reject that product with revision-16 catalogs and accept the committed revision-17 catalogs. '
    'Every original stdout/stderr, exit code and before/after identity is retained below.\n\n'
    f'The five original modules pass 104 tests. The full original source-version runner executes '
    f'{len(actual)} unique discovered tests, with no failures, errors, skips, omissions or overlap. '
    'Its four original v1 tests run in the frozen baseline; the current group runs in its own exact clean clone. '
    'Original preparation also builds and executes fresh typed wire fixtures.\n\n'
    'These are source-validation results. Maintenance completes zero implementation TODOs; '
    'runtime_verified, product_green and task_complete remain false, and original parent acceptance '
    'remains 10/171 with 161 outstanding. PostgreSQL acceptance and any later public candidate execution '
    'retain their own source identities and results.\n', encoding='utf-8')
print(json.dumps({'copied_artifacts': len(copied), 'full_tests': len(actual), 'groups': groups, 'receipt_sha256': pin((destination / 'receipt.json').read_bytes())['sha256']}))
