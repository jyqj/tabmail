from __future__ import annotations

import argparse
import importlib.util
import json
import os
from pathlib import Path
import re
import sys

parser = argparse.ArgumentParser()
parser.add_argument('--root', type=Path, required=True)
parser.add_argument('--output', type=Path, required=True)
parser.add_argument('--commit', required=True)
parser.add_argument('--tree', required=True)
parser.add_argument('--typescript-archive', type=Path, required=True)
args = parser.parse_args()
root = args.root.resolve()
output = args.output.resolve()
assert not output.exists()
output.mkdir(parents=True)
spec = importlib.util.spec_from_file_location('catalog17_author', root / 'scripts/prepare_r5_catalog_revision17.py')
author = importlib.util.module_from_spec(spec)
spec.loader.exec_module(author)
identity = dict(commit=args.commit, tree=args.tree, status='')
assert author.identity(root) == identity
author.write_raw(output, 'source-before.json', author.canonical(identity))
sys.path.insert(0, str(root / 'scripts'))
import r5_source_runner_prepare as preparation
assert Path(preparation.__file__).resolve() == root / 'scripts/r5_source_runner_prepare.py'
prepared = preparation.prepare_typescript(root, archive=args.typescript_archive.read_bytes())
author.write_raw(output, 'typescript-preparation.json', author.canonical(prepared))
assert author.identity(root) == identity
os.environ['PYTHONPATH'] = str(root / 'scripts') + os.pathsep + str(root / 'scripts/tests')
commands = [
    ('transactions', [sys.executable, '-B', 'scripts/check_r5_transactions.py']),
    ('compatibility', [sys.executable, '-B', 'scripts/check_r5_compatibility.py']),
    ('clients', ['node', 'scripts/collect_api_calls.cjs', '--check']),
    ('five-modules', [sys.executable, '-B', '-m', 'unittest',
        'test_r5_transactions', 'test_r5_compatibility', 'test_r5_catalog_reconciliation',
        'test_r5_current_source_inventory', 'test_r5_reviewed_web_locks', '-v']),
]
records = []
for label, argv in commands:
    _, record = author.record_command(root, output, label, argv)
    records.append(record)
author.write_raw(output, 'original-commands.json', author.canonical(records))
assert all(record['exit_code'] == 0 for record in records)
assert all(record['before'] == record['after'] == identity for record in records)
raw = (output / 'five-modules.stderr').read_text()
assert re.search(r'^Ran 104 tests in [0-9.]+s$', raw, re.M)
assert raw.rstrip().endswith('OK')
assert not re.search(r'\.\.\. (?:FAIL|ERROR|skipped|expected failure)', raw)
assert author.identity(root) == identity
result = dict(status='three_original_clis_and_five_original_modules_passed',
    source=identity, commands={row['label']: row['exit_code'] for row in records},
    five_module_tests_run=104, failures=0, errors=0, skips=0,
    full_source_version_executed_on_this_candidate=False,
    implementation_todos_completed=0, runtime_verified=False,
    product_green=False, task_complete=False)
author.write_raw(output, 'result.json', author.canonical(result))
print(json.dumps(result), flush=True)
