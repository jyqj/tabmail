import json,pathlib,hashlib,collections,datetime,sys
P=pathlib.Path;root=P(sys.argv[1]);src=root/'src';identity=json.loads((root/'source-receipt.json').read_text());raw=(root/'phases/receipt5-race-compileinput-GoList/stdout').read_text();decoder=json.JSONDecoder();packages=[];position=0
while position<len(raw):
 while position<len(raw) and raw[position].isspace():position+=1
 if position>=len(raw):break
 item,position=decoder.raw_decode(raw,position);packages.append(item)
fields=['GoFiles','CgoFiles','CFiles','CXXFiles','MFiles','HFiles','FFiles','SFiles','SwigFiles','SwigCXXFiles','SysoFiles','EmbedFiles'];declared_test_inputs=[];own={};external=[];generated=[];modules={};missing=[];errors=[];embed={}
for pkg in packages:
 label=pkg.get('ImportPath');directory=P(pkg.get('Dir',str(src))).resolve()
 if pkg.get('Error') or pkg.get('DepsErrors') or pkg.get('Incomplete'):errors.append({'package':label,'Error':pkg.get('Error'),'DepsErrors':pkg.get('DepsErrors'),'Incomplete':pkg.get('Incomplete')})
 mod=pkg.get('Module')
 if mod:modules[(mod.get('Path'),mod.get('Version'))]=mod
 for tf in ['TestGoFiles','XTestGoFiles','TestEmbedFiles','XTestEmbedFiles']:
  if pkg.get(tf):declared_test_inputs.append({'package':label,'field':tf,'names':pkg[tf],'classification':'declarations not automatically transitive compilation; -test variants GoFiles/EmbedFiles determine actual selection'})
 for field in fields:
  for filename in pkg.get(field,[]):
   p=P(filename);p=(directory/p).resolve() if not p.is_absolute() else p.resolve()
   if p.is_relative_to(src):
    rel=str(p.relative_to(src));row=own.setdefault(rel,{'fields':[],'packages':[],'manifest_sha256':identity['files'].get(rel)})
    if field not in row['fields']:row['fields'].append(field)
    if label not in row['packages']:row['packages'].append(label)
    if rel not in identity['files'] or not p.is_file():missing.append({'package':label,'field':field,'relative_path':rel,'captured':rel in identity['files'],'exists':p.is_file()})
    if 'Embed' in field:embed.setdefault(rel,[]).append({'package':label,'field':field,'patterns':pkg.get('EmbedPatterns',[])})
   else:
    x={'package':label,'field':field,'path':str(p),'exists':p.is_file(),'Goroot':bool(pkg.get('Goroot')),'module_path':mod.get('Path') if mod else None,'module_version':mod.get('Version') if mod else None,'module_Sum':mod.get('Sum') if mod else None}
    if pkg.get('ImportPath','').endswith('.test') and str(p).startswith('/Users/jin/Library/Caches/go-build/'):
     x.update(kind='GoList_generated_testmain_not_handwritten_input',generated_bytes_sha256=hashlib.sha256(p.read_bytes()).hexdigest() if p.is_file() else None);generated.append(x)
    else:x['kind']='pinned_toolchain_standard_library' if pkg.get('Goroot') else 'pinned_cached_go_module_input';external.append(x)
    if not p.is_file():errors.append({'missing_external_compile_input':x})
localfork={k:v for k,v in own.items() if k.startswith('third_party/enmime-v2.3.0/')};assert 'third_party/enmime-v2.3.0/go.mod' in identity['files'];assert 'third_party/enmime-v2.3.0/go.sum' in identity['files']
result={'scope':'receipt5 currentroot/default race/CGO1 metadata only; actual5tests separately captured','UTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_sha':identity['source_sha'],'actual_source_closure_sha256':identity['actual_source_closure_sha256'],'GoList_exit':int((root/'phases/receipt5-race-compileinput-GoList/go.exit').read_text()),'package_rows':len(packages),'input_fields_audited':fields,'declared_test_input_fields_not_misclassified_as_selected':declared_test_inputs,'own_distinct_actual_compile_and_embed_inputs':len(own),'own_input_rows':own,'own_missing_not_captured':missing,'actual_own_embed_inputs':embed,'actual_localfork_selected_files':localfork,'localfork_root_go_mod_and_sum_sourcebound':True,'localfork_versioned_module_binding_captured_not_all_stages_import_it':True,'external_compile_input_rows':external,'generated_testmain_rows':generated,'transitive_module_provenance':list(modules.values()),'errors_or_unknown':errors,'source_certification_layers':{'private_current_source':'actual current Go/cmd/third_party ordinary files + root/fork go.mod/go.sum + actualembed; signed2test fixturepins matched; schema18; NOT old853/7091','selected_transitive_compile_inputs':'all file classes and actual EmbedFiles verified in candidate, not onlyGoFiles','external_standard_library_modules':'actual GoList paths/versions/moduleSum/GoModSum and cachedGo1.25.7 provenance; existing dependency cache bytes not freshly rehashed or claimed within private490','generated_testmain':'GoList-generated source actualbytes hash; generated metadata artifact not product manuallycopied input','runtime':'receipt5 boundedscope; GoList0 itself never runtime evidence'},'BC05_metadataseparate_from_actual_runtimePASS':True,'local_replace_expected_version':'github.com/jhillyerd/enmime/v2 v2.3.0 => ./third_party/enmime-v2.3.0'};(root/'receipt5-actual-race-transitive-compile-input-audit.json').write_text(json.dumps(result,sort_keys=True,indent=2)+'\n');print(json.dumps({k:result[k] for k in ['source_sha','GoList_exit','package_rows','own_distinct_actual_compile_and_embed_inputs','own_missing_not_captured','errors_or_unknown']}));print('embedunique',len(embed),'external',len(external),'generated',len(generated),'modules',len(modules));print('externaltypes',collections.Counter(x['kind'] for x in external))

assert not missing and not errors,"selected compileinput source incomplete"
