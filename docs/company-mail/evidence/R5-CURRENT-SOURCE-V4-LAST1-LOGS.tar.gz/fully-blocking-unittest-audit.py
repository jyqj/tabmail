import os,sys,json
import unittest,pathlib
root=pathlib.Path(sys.argv[1]);output=pathlib.Path(sys.argv[2]);sys.path[:0]=[str(root),str(root/'scripts')]
def audit(event,args):
 if event.startswith('subprocess.') or event in ('os.system','os.posix_spawn','os.posix_spawnp'):
  output.with_name('forbidden-dispatch.json').write_text(json.dumps({'event':event,'blocked_before_actual_subprocess':True,'no_arguments_exported':True}));os._exit(97)
sys.addaudithook(audit)
# Invoke the exact authorized unittest CLI program only after installing audit.
sys.argv=['unittest',*sys.argv[3:]]
class Recorded(unittest.TextTestResult):
 def __init__(self,*a,**k):super().__init__(*a,**k);self.events=[]
 def startTest(self,t):self.events.append({'action':'start','test':t.id()});super().startTest(t)
 def addSuccess(self,t):self.events.append({'action':'pass','test':t.id()});super().addSuccess(t)
 def addError(self,t,e):self.events.append({'action':'error','test':t.id(),'class':e[0].__name__});super().addError(t,e)
 def addFailure(self,t,e):self.events.append({'action':'fail','test':t.id(),'class':e[0].__name__});super().addFailure(t,e)
 def addSkip(self,t,r):self.events.append({'action':'skip','test':t.id()});super().addSkip(t,r)
program=unittest.main(module=None,testRunner=unittest.TextTestRunner(verbosity=2,resultclass=Recorded),exit=False)
r=program.result;output.write_text(json.dumps({'testsRun':r.testsRun,'errors':len(r.errors),'failures':len(r.failures),'skips':len(r.skipped),'events':r.events,'actualrootcapture_repeated':False},sort_keys=True,indent=2))
sys.exit(0 if r.wasSuccessful() else 1)
