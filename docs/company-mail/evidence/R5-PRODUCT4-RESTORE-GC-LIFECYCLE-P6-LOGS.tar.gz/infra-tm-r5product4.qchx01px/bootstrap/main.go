package main
import("context";"fmt";"os";"time";"tabmail/internal/config";"tabmail/internal/store/postgres")
func main(){ctx,c:=context.WithTimeout(context.Background(),30*time.Second);defer c();s,e:=postgres.New(ctx,config.DB{DSN:os.Getenv("TABMAIL_TEST_DB_DSN"),MaxOpenConns:2,MaxIdleConns:1});if e!=nil{fmt.Fprintln(os.Stderr,e);os.Exit(1)};s.Close();fmt.Println("official PgStore.New/Migrate completed")}
