import os,sys,json,hashlib,time,tempfile,pathlib,importlib.util,shutil,subprocess,tarfile
P=pathlib.Path; ORIGIN=time.time(); DEADLINE=ORIGIN+90
CAP=P('/tmp/r5-c18-contract-evidence-source-v2-20261003'); PY='/private/tmp/tabmail-r5-enqueue.LUPWmvR1/tooling/venv/bin/python3'
OUT=P(tempfile.mkdtemp(prefix='tm-r5C18V2-pure21.',dir='/private/tmp')); os.chmod(OUT,0o700)
(OUT/'tmp').mkdir(mode=0o700); (OUT/'home').mkdir(mode=0o700); SRC=OUT/'src'; SRC.mkdir(mode=0o700)
def write(n,x): (OUT/n).write_text(json.dumps(x,sort_keys=True,indent=2)+'\n')
scope=json.loads((CAP/'source-delta.json').read_text()); selectors=json.loads((CAP/'fresh-selectors.json').read_text())['targets']; assert len(selectors)==21 and len(set(selectors))==21
files={}
for row in scope['files']:
 rel=row['path']; raw=(CAP/'after'/rel).read_bytes(); assert hashlib.sha256(raw).hexdigest()==row['after_sha256']
 assert (P('/Users/jin/Desktop/tabmail')/rel).read_bytes()==raw, 'current signed source drift: '+rel
 dst=SRC/rel; dst.parent.mkdir(parents=True,exist_ok=True); dst.write_bytes(raw); files[rel]=hashlib.sha256(raw).hexdigest()
canonical=json.dumps(files,sort_keys=True,separators=(',',':')).encode(); write('source-receipt.json',{'files':files,'source_identity_kind':'canonical_scoped_C18_contract_dependency_closure_sha1','source_sha':hashlib.sha1(canonical).hexdigest(),'actual_source_closure_sha256':hashlib.sha256(canonical).hexdigest(),'scope':'7 signed pure-contract dependencies only; no runtime source capture','capsule':str(CAP),'snapshot_root':str(SRC),'capture_origin_unix':ORIGIN})
write('selectors.json',selectors)
for f in SRC.rglob('*'):
 if f.is_file():f.chmod(0o444)
for d in sorted([SRC]+[p for p in SRC.rglob('*') if p.is_dir()],key=lambda x:len(x.parts),reverse=True):d.chmod(0o555)
wrapper=OUT/'audit-unittest-wrapper.py'
wrapper.write_text(r'''import os,sys,json,time,resource,pathlib,unittest,math
P=pathlib.Path; ROOT=P(sys.argv[1]).resolve(); OUT=P(sys.argv[2]).resolve(); TMP=OUT/'tmp'
LIMIT=1024**3
resource.setrlimit(resource.RLIMIT_CPU,(60,60))
resource.setrlimit(resource.RLIMIT_AS,(LIMIT,LIMIT))
resource.setrlimit(resource.RLIMIT_DATA,(LIMIT,LIMIT))
audit=open(OUT/'audit.jsonl','w',buffering=1); events=open(OUT/'test-events.jsonl','w',buffering=1); resultfile=open(OUT/'test-result.json','w'); limits=open(OUT/'resource-limits.json','w')
json.dump({'CPU':resource.getrlimit(resource.RLIMIT_CPU),'AS':resource.getrlimit(resource.RLIMIT_AS),'DATA':resource.getrlimit(resource.RLIMIT_DATA),'memory_scope':'per-process address/data cap; sampled RSS is not a hard memory quota'},limits);limits.close()
blocked=[]; observed=0; writes=0
def record(e,reason):
 blocked.append(e); audit.write(json.dumps({'event':e,'reason':reason,'time_ns':time.time_ns()})+'\n'); audit.flush()
def in_tmp(v):
 if isinstance(v,int):return False
 try:return P(os.fsdecode(v)).resolve().is_relative_to(TMP)
 except Exception:return False
def hook(e,a):
 global observed,writes
 observed+=1
 if e.startswith('subprocess.') or e in {'os.system','os.fork','os.forkpty','os.posix_spawn','os.posix_spawnp','os.exec','pty.spawn'} or e.startswith('os.exec') or e in {'socket.connect','socket.bind','socket.listen'}:
  record(e,'forbidden real process/network action');raise RuntimeError('C18 audit denied '+e)
 if e=='open':
  mode=a[1];flags=a[2]; iswrite=(isinstance(mode,str) and any(c in mode for c in 'wax+')) or (isinstance(flags,int) and bool(flags & (os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC|os.O_APPEND)))
  if iswrite:
   if not in_tmp(a[0]):record(e,'write outside owned fixture tempdir');raise RuntimeError('C18 audit write denied')
   writes+=1
 if e in {'os.remove','os.rmdir','os.mkdir','os.chmod','os.chown','os.utime','os.truncate'}:
  if not in_tmp(a[0]):record(e,'mutation outside owned fixture tempdir');raise RuntimeError('C18 audit mutation denied')
 if e in {'os.rename','os.link','os.symlink'}:
  if not all(in_tmp(v) for v in a[:2]):record(e,'mutation outside owned fixture tempdir');raise RuntimeError('C18 audit mutation denied')
sys.addaudithook(hook); sys.path.insert(0,str(ROOT)); os.chdir(ROOT)
class Result(unittest.TextTestResult):
 def event(self,t,status):events.write(json.dumps({'test':t.id(),'status':status,'wall_ns':time.time_ns()})+'\n')
 def startTest(self,t):self.event(t,'start');super().startTest(t)
 def addSuccess(self,t):self.event(t,'pass');super().addSuccess(t)
 def addError(self,t,e):self.event(t,'error');super().addError(t,e)
 def addFailure(self,t,e):self.event(t,'fail');super().addFailure(t,e)
 def addSkip(self,t,r):self.event(t,'skip');super().addSkip(t,r)
 def addSubTest(self,t,s,e):self.event(s,'subtest_pass' if e is None else 'subtest_fail');super().addSubTest(t,s,e)
names=json.loads((OUT/'selectors.json').read_text()); suite=unittest.defaultTestLoader.loadTestsFromNames(names)
discovered=[]
def discover(s):
 for t in s:
  if isinstance(t,unittest.TestSuite):discover(t)
  else:discovered.append(t.id())
discover(suite)
if discovered!=names:raise RuntimeError('exact discovery mismatch')
res=unittest.TextTestRunner(verbosity=2,resultclass=Result).run(suite)
audit.write(json.dumps({'summary':True,'audit_events_observed':observed,'blocked_events':blocked,'owned_fixture_write_events':writes,'actual_process_dispatches':0,'actual_network_dispatches':0})+'\n')
json.dump({'discovered':discovered,'testsRun':res.testsRun,'failures':[t.id() for t,_ in res.failures],'errors':[t.id() for t,_ in res.errors],'skipped':[t.id() for t,_ in res.skipped],'successful':res.wasSuccessful(),'audit_denials':blocked,'runtime_qualification':False,'boundary':'synthetic pure grammar only; partial historical catalog cannot qualify runtime'},resultfile);resultfile.close();events.close();audit.close()
sys.exit(0 if res.wasSuccessful() and not blocked else 1)
''')
env={'PATH':'/usr/bin:/bin','HOME':str(OUT/'home'),'TMPDIR':str(OUT/'tmp'),'PYTHONDONTWRITEBYTECODE':'1','PYTHONNOUSERSITE':'1','LC_ALL':'C'}
argv=[PY,'-B',str(wrapper),str(SRC),str(OUT)]
write('runtime-command.json',{'argv':argv,'cwd':str(SRC),'environment_allowlist':env,'selector_argv_equivalent':[PY,'-B','-m','unittest',*selectors,'-v'],'limits':{'whole_wall_seconds':90,'CPU_seconds':60,'memory_bytes':1024**3},'wrapper_reason':'install subprocess/network/write audit and exact unittest event capture in same process before any test import','Go_PG_capture_benchmark':False})
helperpath=P('/private/tmp/tm-r5M-final.TdhqAxe8/src/scripts/run_r5_benchmark.py'); spec=importlib.util.spec_from_file_location('owned_process_helper',helperpath);helper=importlib.util.module_from_spec(spec);spec.loader.exec_module(helper); helper.ROOT=SRC
receipt={}; rss=[]; returncode=None; errors=[]
# Budget work ends 15s before the original90 cleanup deadline. Native services never start.
remaining=DEADLINE-time.time()-15
try:
 if remaining<=0:raise RuntimeError('capture exhausted original budget')
 with (OUT/'tests.stdout').open('w') as stdout,(OUT/'tests.stderr').open('w') as stderr:
  returncode=helper.run_owned_process(argv,env=env,stdout=stdout,stderr=stderr,timeout=remaining,receipt=receipt)
except BaseException as e:errors.append({'kind':type(e).__name__,'message':str(e)[:240]})
group=receipt.get('owned_process_group'); observation=helper.owned_group_observation(group) if group else {'status':'not_started','non_zombie_live_pids':[]}
write('owned-process-receipt.json',receipt);write('cleanup.json',{'owned_group':group,'observation':observation,'Go_PG_native_network_services_started':False,'fixture_tmp_files':[str(p.relative_to(OUT)) for p in (OUT/'tmp').rglob('*') if p.is_file()]})
post={rel:hashlib.sha256((SRC/rel).read_bytes()).hexdigest() for rel in files};write('source-after.json',{'files':post,'before_after_equal':post==files})
if returncode is not None:(OUT/'tests.exit').write_text(str(returncode)+'\n')
result=json.loads((OUT/'test-result.json').read_text()) if (OUT/'test-result.json').exists() else None
complete=returncode==0 and result and result['testsRun']==21 and result['successful'] and not result['audit_denials'] and post==files and observation['status']=='observed' and not observation['non_zombie_live_pids'] and not errors
elapsed=time.time()-ORIGIN
if elapsed>=90:complete=False;errors.append({'kind':'whole_absolute_budget_exceeded'})
review={'status':'BOUNDED_PURE_GRAMMAR_PASS' if complete else 'FAILED_OR_UNKNOWN','result':result,'source_sha':hashlib.sha1(canonical).hexdigest(),'source_closure_sha256':hashlib.sha256(canonical).hexdigest(),'original_origin_unix':ORIGIN,'original_deadline_unix':DEADLINE,'elapsed_seconds':elapsed,'Go_PG_capture_benchmark_native_dispatches':0,'cleanup':observation,'errors':errors,'not_runtime_qualification':True,'no_current_METHOD_migration_or_fullcatalog_admission':True}
write('C18-V2-pure21-runtime-review.json',review)
members=[p for p in OUT.rglob('*') if p.is_file() and not p.is_relative_to(OUT/'tmp') and not p.is_relative_to(OUT/'home')]; arc=OUT/'C18-V2-pure21-evidence.tar.gz'
with tarfile.open(arc,'w:gz') as t:
 for f in sorted(members):t.add(f,arcname=str(f.relative_to(OUT)),recursive=False)
write('delivery-receipt.json',{'archive':str(arc),'archive_sha256':hashlib.sha256(arc.read_bytes()).hexdigest(),'members':len(members),'root':str(OUT),'runtime_review':str(OUT/'C18-V2-pure21-runtime-review.json'),'scope':'21 fresh pure tests only','total_delivery_elapsed_seconds':time.time()-ORIGIN})
print(json.dumps({'root':str(OUT),'status':review['status'],'exit':returncode,'testsRun':result['testsRun'] if result else None,'elapsed':elapsed,'archive_sha256':hashlib.sha256(arc.read_bytes()).hexdigest()}))
sys.exit(0 if complete else 1)
