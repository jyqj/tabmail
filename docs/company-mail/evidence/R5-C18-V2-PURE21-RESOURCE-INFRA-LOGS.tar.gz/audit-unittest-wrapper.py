import os,sys,json,time,resource,pathlib,unittest,math
P=pathlib.Path; ROOT=P(sys.argv[1]).resolve(); OUT=P(sys.argv[2]).resolve(); TMP=OUT/'tmp'
LIMIT=1024**3
resource.setrlimit(resource.RLIMIT_CPU,(60,60))
resource.setrlimit(resource.RLIMIT_AS,(LIMIT,LIMIT))
resource.setrlimit(resource.RLIMIT_DATA,(LIMIT,LIMIT))
audit=open(OUT/'audit.jsonl','w',buffering=1); events=open(OUT/'test-events.jsonl','w',buffering=1); resultfile=open(OUT/'test-result.json','w'); limits=open(OUT/'resource-limits.json','w')
json.dump({'CPU':resource.getrlimit(resource.RLIMIT_CPU),'AS':resource.getrlimit(resource.RLIMIT_AS),'DATA':resource.getrlimit(resource.RLIMIT_DATA),'memory_scope':'per-process address/data cap; sampled RSS is not a hard memory quota'},limits);limits.close()
blocked=[]; observed=0; writes=0
def record(e,reason):
 blocked.append(e); audit.write(json.dumps({'event':e,'reason':reason,'time_ns':time.time_ns()})+'\n'); audit.flush()
def in_tmp(v):
 if isinstance(v,int):return False
 try:return P(os.fsdecode(v)).resolve().is_relative_to(TMP)
 except Exception:return False
def hook(e,a):
 global observed,writes
 observed+=1
 if e.startswith('subprocess.') or e in {'os.system','os.fork','os.forkpty','os.posix_spawn','os.posix_spawnp','os.exec','pty.spawn'} or e.startswith('os.exec') or e in {'socket.connect','socket.bind','socket.listen'}:
  record(e,'forbidden real process/network action');raise RuntimeError('C18 audit denied '+e)
 if e=='open':
  mode=a[1];flags=a[2]; iswrite=(isinstance(mode,str) and any(c in mode for c in 'wax+')) or (isinstance(flags,int) and bool(flags & (os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC|os.O_APPEND)))
  if iswrite:
   if not in_tmp(a[0]):record(e,'write outside owned fixture tempdir');raise RuntimeError('C18 audit write denied')
   writes+=1
 if e in {'os.remove','os.rmdir','os.mkdir','os.chmod','os.chown','os.utime','os.truncate'}:
  if not in_tmp(a[0]):record(e,'mutation outside owned fixture tempdir');raise RuntimeError('C18 audit mutation denied')
 if e in {'os.rename','os.link','os.symlink'}:
  if not all(in_tmp(v) for v in a[:2]):record(e,'mutation outside owned fixture tempdir');raise RuntimeError('C18 audit mutation denied')
sys.addaudithook(hook); sys.path.insert(0,str(ROOT)); os.chdir(ROOT)
class Result(unittest.TextTestResult):
 def event(self,t,status):events.write(json.dumps({'test':t.id(),'status':status,'wall_ns':time.time_ns()})+'\n')
 def startTest(self,t):self.event(t,'start');super().startTest(t)
 def addSuccess(self,t):self.event(t,'pass');super().addSuccess(t)
 def addError(self,t,e):self.event(t,'error');super().addError(t,e)
 def addFailure(self,t,e):self.event(t,'fail');super().addFailure(t,e)
 def addSkip(self,t,r):self.event(t,'skip');super().addSkip(t,r)
 def addSubTest(self,t,s,e):self.event(s,'subtest_pass' if e is None else 'subtest_fail');super().addSubTest(t,s,e)
names=json.loads((OUT/'selectors.json').read_text()); suite=unittest.defaultTestLoader.loadTestsFromNames(names)
discovered=[]
def discover(s):
 for t in s:
  if isinstance(t,unittest.TestSuite):discover(t)
  else:discovered.append(t.id())
discover(suite)
if discovered!=names:raise RuntimeError('exact discovery mismatch')
res=unittest.TextTestRunner(verbosity=2,resultclass=Result).run(suite)
audit.write(json.dumps({'summary':True,'audit_events_observed':observed,'blocked_events':blocked,'owned_fixture_write_events':writes,'actual_process_dispatches':0,'actual_network_dispatches':0})+'\n')
json.dump({'discovered':discovered,'testsRun':res.testsRun,'failures':[t.id() for t,_ in res.failures],'errors':[t.id() for t,_ in res.errors],'skipped':[t.id() for t,_ in res.skipped],'successful':res.wasSuccessful(),'audit_denials':blocked,'runtime_qualification':False,'boundary':'synthetic pure grammar only; partial historical catalog cannot qualify runtime'},resultfile);resultfile.close();events.close();audit.close()
sys.exit(0 if res.wasSuccessful() and not blocked else 1)
