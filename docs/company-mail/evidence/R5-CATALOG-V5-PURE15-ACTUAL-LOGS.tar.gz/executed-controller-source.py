import os,sys,json,pathlib,hashlib,tempfile,time,subprocess,signal,threading,importlib.util,shutil,re
P=pathlib.Path;origin=time.time();deadline=origin+300;workstop=deadline-30;prepared=P('/private/tmp/tm-r5current18-complete-SOURCE.7vf5gy3_');src=prepared/'editable-source-tree';root=P(tempfile.mkdtemp(prefix='tm-r5catalog15pure.',dir='/private/tmp'));root.chmod(0o700)
for n in ['home','tmp','phases']:(root/n).mkdir(mode=0o700)
def dump(n,x):(root/n).write_text(json.dumps(x,sort_keys=True,indent=2)+'\n')
identity=json.loads((prepared/'SOURCE18-checkpoint-receipt.json').read_text());manifest=json.loads((prepared/'canonical-source-manifest.json').read_text())['files'];plan=json.loads((prepared/'CATALOG15-pure-RESOURCE-PREPARED-NOT-RUN.json').read_text());names=plan['exact15names'];regex=plan['exact_regex'];collector='internal/store/postgres/r5_current_benchmark_catalog_test.go';assert hashlib.sha256((src/collector).read_bytes()).hexdigest()=='cbc7b296edd81836a6268c2d8fa9d7ad0721344d5b4c28d4d89f308c81f9acb8'
go='/Users/jin/.cache/go-mod/golang.org/toolchain@v0.0.1-go1.25.7.darwin-arm64/bin/go';env={'HOME':str(root/'home'),'TMPDIR':str(root/'tmp')+'/','PATH':str(P(go).parent)+':/usr/bin:/bin:/usr/sbin:/sbin','LANG':'en_US.UTF-8','GOTOOLCHAIN':'local','GOMODCACHE':'/Users/jin/.cache/go-mod','GOCACHE':'/Users/jin/Library/Caches/go-build','GOPROXY':'off','GOSUMDB':'sum.golang.org','GOWORK':'off','GOMAXPROCS':'2','GOFLAGS':'-mod=readonly -p=1','CGO_ENABLED':'1','CC':'/usr/bin/cc','SDKROOT':'/Library/Developer/CommandLineTools/SDKs/MacOSX15.4.sdk'}
profile=root/'fixture-no-network.sb';profile.write_text('(version 1)\n(allow default)\n(deny network*)\n')
parentSpec=importlib.util.spec_from_file_location('owned','/private/tmp/tm-r5M-final.TdhqAxe8/src/scripts/run_r5_benchmark.py');owned=importlib.util.module_from_spec(parentSpec);parentSpec.loader.exec_module(owned)
phase_receipts={};resource_samples={};lastwall=origin

def run(name,argv,cap):
 global lastwall
 d=root/'phases'/name;d.mkdir(mode=0o700);command=['/usr/bin/sandbox-exec','-f',str(profile),*argv];(d/'command.json').write_text(json.dumps({'argv':command,'underlying_argv':argv,'cwd':str(src),'actual_env_allowlist':env,'no_inherited_DSN_owner_externalref_credential_environment':True,'original300_origin':origin,'original300_deadline':deadline,'phase_deadline':min(workstop,time.time()+cap),'GOMAXPROCS_actual_child':2,'sandbox_profile_sha256':hashlib.sha256(profile.read_bytes()).hexdigest()},sort_keys=True,indent=2)+'\n');rec={'status':'pending_unknown','source_sha':identity['source_sha'],'exit':None,'errors':[]};samples=[];proc=None;beg=time.time();end=min(workstop,beg+cap);stop=threading.Event();fault=threading.Event();thread=None
 def monitor():
  prev=beg
  while not stop.is_set():
   t0=time.time()
   try:
    r=subprocess.run(['/bin/ps','-axo','pid=,uid=,pgid=,rss=,%cpu=,stat='],capture_output=True,text=True,timeout=min(.120,max(.001,end-time.time())),env={'PATH':'/usr/bin:/bin','LC_ALL':'C'})
    if r.returncode!=0:raise RuntimeError('ps_exit_unknown')
    rows=[]
    for l in r.stdout.splitlines():
     p=l.split()
     if len(p)!=6:raise RuntimeError('RSS_CPU_units_or_fields_unknown')
     if int(p[2])==proc.pid:rows.append({'pid':int(p[0]),'uid':int(p[1]),'pgid':int(p[2]),'rss_bytes':int(p[3])*1024,'ps_percent_CPU':float(p[4]),'stat':p[5]})
    now=time.time();gap=now-prev;prev=now
    if now<t0 or gap<0 or gap>.250 or now-t0>.250:raise RuntimeError('RSS_sampling_gap_or_clock_unknown_over250ms')
    if any(x['uid']!=os.getuid() for x in rows):raise RuntimeError('owned_group_UID_unknown')
    rss=sum(x['rss_bytes'] for x in rows if not x['stat'].startswith('Z'));samples.append({'query_begin_wall':t0,'wall':now,'gap_seconds':gap,'owned_group':proc.pid,'members':rows,'owned_group_RSS_sum_bytes':rss,'CPU_percent_sum_observed':sum(x['ps_percent_CPU'] for x in rows)})
    if rss>2*(1<<30):raise RuntimeError('RSS_sum_over2GiB')
   except BaseException as e:rec['errors'].append({'resource_fault_class':type(e).__name__,'reason':str(e)[:180]});fault.set();return
   stop.wait(max(0,.100-(time.time()-t0)))
 with (d/'stdout').open('w') as out,(d/'stderr').open('w') as err:
  try:
   if end-time.time()<=0:raise RuntimeError('original300deadline cannot admit phase')
   proc=subprocess.Popen(command,cwd=src,env=env,stdout=out,stderr=err,start_new_session=True);rec.update(pid=proc.pid,pgid=proc.pid,expected_uid=os.getuid());thread=threading.Thread(target=monitor);thread.start()
   while True:
    now=time.time()
    if now<lastwall:raise RuntimeError('outer_wall_clock_reversal')
    lastwall=now
    if now>=end or fault.is_set():raise RuntimeError('phase_or_resource_guard_failed')
    code=proc.poll()
    if code is not None:rec['exit']=code;break
    time.sleep(min(.05,end-now))
  except BaseException as e:
   rec['errors'].append({'outer_error_class':type(e).__name__,'reason':str(e)[:180]})
   if proc is not None and proc.returncode is None:
    cleanup={};owned.cleanup_owned_process(proc,cleanup,already_reaped=False,leader_unreaped=True);rec['guard_owned_cleanup']=cleanup;rec['exit']=cleanup.get('process_returncode')
  finally:
   stop.set()
   if thread:thread.join(timeout=min(1.,max(.001,deadline-time.time())))
   if thread and thread.is_alive():rec['errors'].append({'RSS_observer_joined':False})
   if proc is not None:
    rec['group_final']=owned.owned_group_observation(proc.pid)
    if rec['group_final']['status']!='observed' or rec['group_final']['non_zombie_live_pids']:rec['errors'].append({'owned_group_not_proved_gone':True})
   if not samples:rec['errors'].append({'RSS_first_sample_unknown':True})
   if samples and time.time()-samples[-1]['wall']>.250:rec['errors'].append({'RSS_final_sample_gap_over250ms':True})
   rec.update(elapsed_seconds=time.time()-beg,status='terminal_observed' if type(rec['exit']) is int else 'unknown',RSS_unit='psKiB*1024 bytes groupSUM, sampling nothardquota',RSS_sample_count=len(samples),RSS_peak_observed=max([s['owned_group_RSS_sum_bytes'] for s in samples] or [0]),RSS_max_gap=max([s['gap_seconds'] for s in samples] or [0]),CPU_scope='GOMAXPROCS2 actualenv, sampled ps%CPU lowerbound; no CPU time hardlimit requested')
   (d/'process-resource-receipt.json').write_text(json.dumps(rec,sort_keys=True,indent=2)+'\n');(d/'RSS-CPU-samples.json').write_text(json.dumps(samples,sort_keys=True,indent=2)+'\n')
   if type(rec['exit']) is int:(d/'go.exit').write_text(str(rec['exit'])+'\n')
   phase_receipts[name]=rec;resource_samples[name]=samples
 return rec['exit'] if not rec['errors'] else None
try:
 dump('source-and-runtime-admission.json',{'SOURCEcheckpoint':str(prepared),'source_sha':identity['source_sha'],'actual_source_closure_sha256':identity['actual_source_closure_sha256'],'collectorV5cbc7pinmatched':True,'original300origin_precompile':origin,'exact15names':names,'ownedtop_not_selected':plan['ownedtop_explicitly_not_selected'],'noDSN_owner_or_signedexternalref_admission':True,'OS_network_denied_to_Go_and_all_testfixtures':True,'fixture_sqlqualification':False,'noPGnative_or_realGoCatalog':True})
 assert run('catalog-r5benchmark-actual-race-rootMVS-GoList',[go,'list','-mod=readonly','-race','-tags=r5benchmark','-deps','-test','-json','./internal/store/postgres'],120)==0,'first setupmetadata/resource failed; no puretestsafter'
 # Verify actual compiler file classes against immutable fullSOURCE manifest; metadata only.
 raw=(root/'phases/catalog-r5benchmark-actual-race-rootMVS-GoList/stdout').read_text();pos=0;dec=json.JSONDecoder();pkgs=[];selected={};unknown=[];external=[]
 while pos<len(raw):
  while pos<len(raw) and raw[pos].isspace():pos+=1
  if pos==len(raw):break
  q,pos=dec.raw_decode(raw,pos);pkgs.append(q)
  if q.get('Incomplete') or q.get('Error') or q.get('DepsErrors'):unknown.append(q.get('ImportPath'))
  for field in ['GoFiles','CgoFiles','CFiles','CXXFiles','MFiles','HFiles','FFiles','SFiles','SwigFiles','SwigCXXFiles','SysoFiles','EmbedFiles']:
   for f in q.get(field,[]):
    fp=P(f);fp=(P(q['Dir'])/fp).resolve() if not fp.is_absolute() else fp.resolve()
    if fp.is_relative_to(src):
     rel=str(fp.relative_to(src));selected.setdefault(rel,{'fields':[],'sha256':manifest.get(rel)})['fields'].append(field)
     if rel not in manifest or hashlib.sha256(fp.read_bytes()).hexdigest()!=manifest[rel]:unknown.append(rel)
    else:external.append({'package':q.get('ImportPath'),'field':field,'path':str(fp),'exists':fp.is_file(),'Module':q.get('Module'),'Goroot':q.get('Goroot',False),'boundary':'externalcachedversions/checksums not entirecachebytehash; generatedtestmain separate'})
 dump('actual-tagged-race-compileinput-source-audit.json',{'actual_package_rows':len(pkgs),'actual_local_selected_inputs':selected,'external_cache_toolchain_layer':external,'unknown':unknown,'context':{'GOOS':'darwin','GOARCH':'arm64','CGO_ENABLED':1,'race':True,'tags':['r5benchmark'],'rootMVS':'actual localenmimev2.3.0 rootrequire/versionreplace'},'owned_catalog_source_is_compiled_but_ownedtest_not_run':True})
 assert not unknown and collector in selected,'actualtag compile-source closure unknown'
 assert deadline-time.time()>60+30,'original300 insufficient package60+cleanup30'
 run('catalog15-pure-only',[go,'test','-mod=readonly','-race','-json','-p','1','-parallel','1','-count=1','-timeout=60s','-tags=r5benchmark','./internal/store/postgres','-run',regex],workstop-time.time())
except BaseException as e:dump('first-controller-error.json',{'class':type(e).__name__,'reason':str(e),'no_auto_retry':True})
finally:
 logs=root/'phases/catalog15-pure-only/stdout';events=[]
 if logs.exists():
  for line in logs.read_text().splitlines():
   if line.startswith('{'):events.append(json.loads(line))
 actions={}
 for e in events:
  if e.get('Test'):actions.setdefault(e['Test'],[]).append(e['Action'])
 tops=[n for n in actions if '/' not in n];unfinished=[n for n,a in actions.items() if 'run'in a and not any(x in a for x in ['pass','fail','skip'])];post={n:hashlib.sha256((src/n).read_bytes()).hexdigest() for n in [collector,'go.mod','go.sum']};dump('readonly-critical-source-after.json',{'hashes':post,'same':all(manifest[n]==h for n,h in post.items()),'rootmodsum_not_rebased_or_tidied':True})
 clean={'no_nativePG_SQL_HTTP_SMTPservices_started':True,'all_phase_groups_gone':all(p.get('group_final',{}).get('status')=='observed' and not p.get('group_final',{}).get('non_zombie_live_pids') for p in phase_receipts.values()),'all_resource_observers_joined':all(not any('RSS_observer_joined'in e for e in p['errors']) for p in phase_receipts.values()),'original300elapsed':time.time()-origin,'within300':time.time()<deadline};dump('cleanup-receipt.json',clean)
 acceptance=set(tops)==set(names) and len(tops)==15 and all('pass'in actions[n] for n in names) and not unfinished and not any('fail'in a or 'skip'in a for a in actions.values()) and phase_receipts.get('catalog15-pure-only',{}).get('exit')==0 and not any(p['errors'] for p in phase_receipts.values()) and clean['within300'] and clean['all_phase_groups_gone'] and all(post[n]==manifest[n] for n in post)
 dump('CATALOG15-PURE-first-runtime-review.json',{'status':'BOUNDED_PURE_SYNTHETIC_PASS' if acceptance else 'FAILED_OR_INFRA_UNKNOWN','source_sha':identity['source_sha'],'source_closure_sha256':identity['actual_source_closure_sha256'],'actual_top_tests':tops,'actual_test_actions':actions,'unfinished':unfinished,'PASSnodes':sum('pass'in a for a in actions.values()),'SKIPnodes':sum('skip'in a for a in actions.values()),'FAILnodes':sum('fail'in a for a in actions.values()),'phase_receipts':phase_receipts,'cleanup':clean,'runtime_reference_ready':False,'full_semantic_reference_qualified':False,'SQL_serializer_full_actual_certified':False,'owner_or_reference_producer_executed':False,'no_owned_qualification_or_SML_whole_C18Python21_repeated':True});print('ROOT',root,flush=True);print('ACCEPTANCE',acceptance,'tops',len(tops),'PASS',sum('pass'in a for a in actions.values()),flush=True)
