# Current dirty full-Go gate preparation

仅准备；未执行 build/test/vet/PG。root已正式授权一次currentdirty全Go（非M/browser）；唯一 calibration_executor 新建 owned PG 租约且验证当前negative leaf后执行。原 171 TODO、10 已验、G0/P1/P2/P6/P7 门禁不变。

- 主命令必须是默认 `go test -mod=readonly -json -race -p 1 -count=1 -timeout=180s ./...`，无 opt-in tags，不能缩为改动包 selector。
- `source-inventory.json` 为当前真实源码声明盘点，不是 Go 已运行或已通过数。原严格 backend 清单及 current-source manifest 均须验全；只允许 manifest 规定的独立 browser skip，不能把任何 PG skip 计绿。
- 运行前由执行器冻结实际 dirty+untracked源码一次；不能使用 review-source workflow 的 HEAD archive 冒充 dirty。当前原 `587ba75` 不等于被测 dirty source。记录真实 source 40hex/identity kind、命令、环境键、工具版本、raw JSONL、stderr、每步退出、资源租约与cleanup。源变化则旧证据不再归当前树。
- 代码实际默认声明、强制 old manifest、tagged tests 和精确 protocol red mapping 已由当前源码/工具提取，未用历史通过数量。包必跑集合在 inventory 内；全Go gate判定同时要求包生命周期完整，默认失败一律非预期，不接受目标红。
- tagged `r5audit`/`r5protocol` 原始 red 单独包，用原工具 exact path+marker classifier；unknown必须为0。benchmark/diagnostic/M、browser、optional tenant cascade 不在本 gate，不因额外局部绿替代。

## Schema16完整范围

默认全Go必须包含 `TestMigrateAppliesCleanly`（supplied disposable DB 空迁移+重复）、`TestR5SchemaInventoryAndRestart`（真实 catalog/sequence/trigger/CHECK、v16、重复）、`TestArchitectureUpgradeBackfillsExistingEmployeeAssets`（历史00001–00009 populated库→当前16）以及 `TestR5SuppressionScopesMigrationFreshUpgradeRepeat`（历史15 scope字节/repeat/Down拒绝→当前16）。不改历史SQL或加直接SQL伪造成功事件。00016不可逆 Down 不等于回滚验收通过。升级测试使用fixture独立数据库，不能触碰shared/admin外部数据。全量仍含真实backup/restore/object/receipt链；需 Python3.12 safe extraction 和 PG16 pg_dump/psql，不用局部schema catalog代替升级与恢复。

## 当前静态具名阻塞

1. 原negative driver的current-source兼容leaf已在唯一授权2file落实，尚待soleexecutor验证：原missing-dsn固定真实mandatory legacy PG selector而仍exit0/run-skip；原zero-tests与browserdisabled完整保留；新增named current-missing-dsn-hardfail必须exactraw/lifecycle/唯一DSNFatal marker、Go1/gate1、unknown0。它是额外counterexample而非将exit1变产品绿；checker/manifest不修改。原失败raw保留，纯unit和4真实Go结果未观察前本门禁仍未绿。
2. root已正式授权本次fullGo，executor目前无live owned lease，旧native集群都已stop。可信PG16及Python候选路径见packet.json；需新租约，不借旧DSN，不自启。
3. `/usr/bin/python3` 当前3.9.6，不能用于required backup/restore。候选已装venv Python3.12，执行器须配置child PATH并验证safe data_filter/pinned dependencies。

任何 compile/setup/timeout/panic/race/连接故障均保留为未知/非预期错误，不能label目标red；本packet不能给Go绿色结论。HTTPcaptures含测试秘密保持0700且不上传raw responses.json。最终独立G0/full runtime、cold web/browser与M新审仍日后另授权。
