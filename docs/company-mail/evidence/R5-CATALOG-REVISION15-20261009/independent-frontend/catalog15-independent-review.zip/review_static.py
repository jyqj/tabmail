from pathlib import Path
import ast
import copy
import hashlib
import json
import subprocess

ROOT = Path('/workspace/scratch/02f0b8733500/tabmail-catalog15-review')
OUT = Path('/workspace/scratch/02f0b8733500/advance-catalog15-review')
BASE = '26a30e3c6963d553efdd8a8b33c095feb924c758'
PREVIOUS = 'fdea2178759ce9842844926374ea98517bc4188b'
EVIDENCE = 'docs/company-mail/evidence/'


def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT)


def digest(value):
    return hashlib.sha256(value).hexdigest()


def from_git(commit, path):
    return git('show', f'{commit}:{path}')


def read_json(path):
    return json.loads((ROOT / path).read_bytes())


def identity():
    return {key: git(*args).decode().strip() for key, args in {
        'commit': ('rev-parse', 'HEAD'),
        'tree': ('rev-parse', 'HEAD^{tree}'),
        'status': ('status', '--porcelain'),
    }.items()}


before = identity()
assert not before['status'], before
rpath = EVIDENCE + 'R5-CATALOG-REVISION15-20261009/reconciliation.json'
r = read_json(rpath)
frozen = json.loads((OUT / 'frozen-revision14-review-inputs.json').read_bytes())
assert r['source_commit'] == BASE
assert r['source_tree'] == git('rev-parse', BASE + '^{tree}').decode().strip()
assert r['previous_catalog_commit'] == PREVIOUS
assert r['implementation_todos_completed'] == 0
assert all(r[x] is False for x in ('runtime_verified', 'product_green', 'task_complete'))

# Verify the manifest against independently frozen inputs, public Git objects,
# and the candidate bytes; a digest in the submitted report is insufficient.
assert r['historical_directories'] == frozen['historical_directories']
assert {x['path']: x for x in r['historical_manifest']} == {
    x['path']: x for x in frozen['historical_files']
}
for name in ('historical_manifest', 'protected_source_manifest'):
    rows = r[name]
    assert len({x['path'] for x in rows}) == len(rows)
    for row in rows:
        current = (ROOT / row['path']).read_bytes()
        old = from_git(BASE, row['path'])
        assert current == old, (name, row['path'])
        assert row['sha256'] == digest(old)
        assert row['bytes'] == len(old)
        assert row['blob'] == git('rev-parse', BASE + ':' + row['path']).decode().strip()
assert len(r['historical_manifest']) == 120
assert len(r['protected_source_manifest']) == 174
for row in r['revision14_snapshots'].values():
    old = from_git(PREVIOUS, row['path'])
    assert row['commit'] == PREVIOUS
    assert row['bytes'] == len(old)
    assert row['sha256'] == digest(old)
    assert row['blob'] == git('rev-parse', PREVIOUS + ':' + row['path']).decode().strip()
for row in r['generated_catalogs'].values():
    current = (ROOT / row['path']).read_bytes()
    assert len(current) == row['bytes']
    assert digest(current) == row['sha256']

txpath = EVIDENCE + 'R5-TRANSACTION-COVERAGE.json'
oldtx = json.loads(from_git(PREVIOUS, txpath))
newtx = read_json(txpath)
old = {e['id']: e for e in oldtx['entries']}
new = {e['id']: e for e in newtx['entries']}
changed_id = 'internal/store/postgres/apikeys.go:*PgStore:CreateAPIKey'
additions = {
    'internal/store/postgres/apikeys.go:*PgStore:CreateAPIKeyAuthorized',
    'internal/store/postgres/apikeys.go::insertAPIKeyRows',
}
assert set(new) - set(old) == additions
assert not set(old) - set(new)
assert len(old) == 402 and len(new) == 404
assert oldtx['migrations'] == newtx['migrations']
assert len(newtx['migrations']) == 19
assert all(newtx[x] is False for x in ('task_complete', 'runtime_verified'))
derived_fields = {'syntax', 'classification', 'assertions', 'callers'}
precise_assertion_fields = {
    'direct_sql_effects', 'direct_lock_fragments',
    'transaction_helper_calls', 'sql_execution_expressions',
}
for key, original in old.items():
    if key == changed_id:
        continue
    candidate = new[key]
    assert {k: v for k, v in original.items() if k not in derived_fields} == {
        k: v for k, v in candidate.items() if k not in derived_fields
    }, ('manual review drift', key)
    assert {k: v for k, v in original['assertions'].items() if k not in precise_assertion_fields} == {
        k: v for k, v in candidate['assertions'].items() if k not in precise_assertion_fields
    }, ('assertion review drift', key)
    assert original['classification'] == candidate['classification'], key

archived_fields = {
    'lock_fk_wait_fence', 'evidence', 'unverified_risks',
    'file_family_context', 'source_review',
}
assert new[changed_id]['historical_revision14_review'] == {
    k: old[changed_id][k] for k in archived_fields
}
for key in ('owner', 'entry', 'group', 'review_status', 'followup_tasks', 'evidence_level'):
    assert old[changed_id][key] == new[changed_id][key], key
assert old[changed_id]['classification']['kind'] == 'direct-write'
assert new[changed_id]['classification']['kind'] == 'write-call-closure'
assert new[changed_id]['classification']['transaction_calls'] is True
assert new[changed_id]['classification']['direct_write'] is False
assert new[changed_id]['classification']['explicit_lock'] is False
for key, expected in {
    'CreateAPIKey': '63d0e139223af39dcaae5e12c17ec4bd5688655b8e1ce678feb8179f71737ec0',
    'CreateAPIKeyAuthorized': '63d0d21220f001ee79261adb93a6506c3deeb6b7727bc55673fcc3ecd8cebbe2',
    'insertAPIKeyRows': '293516617d7e09d2e86cc1877d45da7ee2eba6829f4b78b8ff8f9124c66c3ddf',
}.items():
    entry = next(e for e in new.values() if e['id'].endswith(':' + key))
    assert entry['source_review']['source_sha256'] == expected
    assert entry['syntax']['sha256'] == expected
    assert entry['source_review']['base_commit'] == BASE
    assert entry['evidence_level'] == 'source-only'

file_reviews = copy.deepcopy(newtx['reviewed_file_types'])
assert file_reviews['internal/store/postgres/apikeys.go'].pop('revision15_additions') == r['transaction_file_review_additions']['internal/store/postgres/apikeys.go']
assert file_reviews == oldtx['reviewed_file_types']

gatepath = EVIDENCE + 'R5-COMPATIBILITY-GATES.json'
oldgate = json.loads(from_git(PREVIOUS, gatepath))
newgate = read_json(gatepath)
gate_derived = {'source_closure', 'acquisition', 'inventory_revision', 'routes'}
assert {k: v for k, v in oldgate.items() if k not in gate_derived} == {
    k: v for k, v in newgate.items() if k not in gate_derived
}
assert all(newgate[x] is False for x in ('task_complete', 'product_green'))
assert r['compatibility']['wire_validation_scope'] == 'not_checked_current_wire_required'
assert r['compatibility']['routes'] == 133
assert r['compatibility']['client_branches'] == 136
assert r['compatibility']['source_files'] == 95
assert len(r['compatibility_route_changes']) == 13
assert sum(x['changed_fields'] == ['clients'] for x in r['compatibility_route_changes']) == 9
assert len(r['closure_changes']) == 10

old_methods = frozen['test_methods']
test_path = 'scripts/tests/test_r5_catalog_reconciliation.py'
source = (ROOT / test_path).read_text()
syntax = ast.parse(source)
constants = {}
methods = {}
for node in syntax.body:
    if isinstance(node, (ast.Assign, ast.AnnAssign)):
        targets = node.targets if isinstance(node, ast.Assign) else [node.target]
        for target in targets:
            if isinstance(target, ast.Name) and target.id.startswith('REVISION'):
                constants[target.id] = ast.get_source_segment(source, node)
    if isinstance(node, ast.ClassDef):
        for fn in node.body:
            if isinstance(fn, (ast.FunctionDef, ast.AsyncFunctionDef)) and fn.name.startswith('test_'):
                methods[fn.name] = ast.get_source_segment(source, fn)
for key, value in frozen['revision_constants'].items():
    assert constants[key] == value['source'], key
for key, value in old_methods.items():
    if key.startswith('test_unapproved_'):
        assert methods[key] == value['source'], key
assert identity() == before
receipt = {
    'status': 'PASS', 'before': before, 'after': identity(),
    'historical_files': 120, 'protected_source_files': 174,
    'original_revision_constants_preserved': len(frozen['revision_constants']),
    'original_negative_controls_preserved': 5,
    'existing_manual_reviews_unchanged': 401,
    'changed_manual_review_preserved_in_history': changed_id,
    'added_functions': sorted(additions),
    'original_file_reviews_preserved': len(file_reviews),
    'runtime_verified': False, 'product_green': False, 'task_complete': False,
    'implementation_todos_completed': 0,
}
(OUT / 'candidate-data-static-review.json').write_text(json.dumps(receipt, ensure_ascii=False, indent=2) + '\n')
print(json.dumps(receipt, ensure_ascii=False))
