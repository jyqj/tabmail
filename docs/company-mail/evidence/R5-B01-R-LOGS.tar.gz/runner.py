import pathlib,os,json,subprocess,tarfile,hashlib,collections,time
repo=pathlib.Path.cwd()
r=json.loads((repo/'artifacts/b01r-3Kq7/runtime.json').read_text())
root=pathlib.Path(r['root']); go=r['go'];pg=r['pg_bin'];py=r['python'];base=r['base']
env={'PATH':str(pathlib.Path(go).parent)+':'+pg+':'+str(pathlib.Path(py).parent)+':/usr/bin:/bin','HOME':str(root/'home'),'TMPDIR':str(root/'tmp'),'GOPROXY':'off','GOTOOLCHAIN':'local','GOMODCACHE':'/private/tmp/tabmail-http-7a0h-6a1oo4xl/gomod','GOCACHE':'/private/tmp/tabmail-http-7a0h-6a1oo4xl/gocache','GOMAXPROCS':'4','CGO_ENABLED':'1','TABMAIL_TEST_DB_DSN':f'postgres://tabmail_test@localhost/tabmail_test?host={root}/socket&port=55439&sslmode=disable'}
def run(label,argv,cwd=None,timeout=230,custom_env=None):
    at=time.time()
    with (root/'logs'/f'{label}.out').open('wb') as out,(root/'logs'/f'{label}.err').open('wb') as err:
        p=subprocess.run(argv,cwd=cwd or repo,env=custom_env or env,stdout=out,stderr=err,timeout=timeout)
    (root/'logs'/f'{label}.command.json').write_text(json.dumps({'argv':argv,'cwd':str(cwd or repo),'exit_code':p.returncode,'duration_seconds':time.time()-at},indent=2))
    print(label,'EXIT',p.returncode,flush=True)
    return p.returncode

def events(label):
    out=[]
    for line in (root/'logs'/f'{label}.out').read_text().splitlines():
        try: item=json.loads(line)
        except ValueError: continue
        if isinstance(item,dict) and 'Action' in item:out.append(item)
    counts=dict(collections.Counter(x['Action'] for x in out if x.get('Test')))
    failed=[x['Test'] for x in out if x.get('Test') and x['Action']=='fail']
    print(label,'COUNTS',counts,'FAILED',failed,flush=True)
    notes=''.join(x.get('Output','') for x in out if '.go:' in x.get('Output',''))
    if notes: print(notes[-14000:],flush=True)
    return out,counts

def freeze(label,paths):
    index=root/(label+'.index')
    assert not index.exists()
    git_env=dict(os.environ,GIT_INDEX_FILE=str(index))
    subprocess.run(['git','read-tree','HEAD'],env=git_env,check=True)
    subprocess.run(['git','add','--']+paths,env=git_env,check=True)
    tree=subprocess.check_output(['git','write-tree'],env=git_env,text=True).strip()
    dest=root/label;dest.mkdir(mode=0o700)
    with (root/(label+'.tar')).open('wb') as fp:subprocess.run(['git','archive',tree],stdout=fp,check=True)
    with tarfile.open(root/(label+'.tar')) as tf:tf.extractall(dest,filter='data')
    hashes={str(f.relative_to(dest)):hashlib.sha256(f.read_bytes()).hexdigest() for f in dest.rglob('*') if f.is_file()}
    (root/'logs'/(label+'.manifest.json')).write_text(json.dumps({'tree':tree,'files':hashes},indent=2))
    print('FROZEN',tree,'FILES',len(hashes),flush=True)
    return dest,tree
