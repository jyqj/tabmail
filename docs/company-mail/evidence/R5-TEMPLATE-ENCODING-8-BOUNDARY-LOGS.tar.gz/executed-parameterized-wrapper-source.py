import os,sys,time,json,tempfile,pathlib,hashlib,importlib.util,re
P=pathlib.Path;origin=time.time();mono=time.monotonic();deadline=origin+300;mono_deadline=mono+300;workw=deadline-30;workm=mono_deadline-30
root=P(tempfile.mkdtemp(prefix='tm-r5template-encoding.',dir='/private/tmp'));root.chmod(0o700)
for n in ['home','tmp','phases']:(root/n).mkdir(mode=0o700)
# Reuse approved sole supervision functions unchanged; no PG driver.main invocation.
helperdir=P('/private/tmp/tm-r5usage19-driver-v8-Cexecpost-SOURCE');sys.path.insert(0,str(helperdir));spec=importlib.util.spec_from_file_location('approved_supervisor',helperdir/'usage19_driver_prepared_only.py');h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
ROOT=P('/Users/jin/Desktop/tabmail');source=None;src=root/'src';records={};errors=[]
def dump(n,x):(root/n).write_text(json.dumps(x,sort_keys=True,indent=2)+'\n')
expected={'internal/company/templates.go':'e35aecef4feb2929c4140dd75c825570e8dfd25722513f0d785c6b3e50ee6010','internal/company/r5_template_encoding_boundary_test.go':'91a28cb6c48d7f928e0461db15b468fcaef6d45588c1d6cef4261cc24f73cc74'}
go=h.GO;env={'HOME':str(root/'home'),'TMPDIR':str(root/'tmp')+'/','PATH':str(P(go).parent)+':/usr/bin:/bin:/usr/sbin:/sbin','LANG':'en_US.UTF-8','GOTOOLCHAIN':'local','GOMODCACHE':'/Users/jin/.cache/go-mod','GOCACHE':'/Users/jin/Library/Caches/go-build','GOPROXY':'off','GOSUMDB':'sum.golang.org','GOWORK':'off','GOMAXPROCS':'2','GOFLAGS':'-mod=readonly -p=1','CGO_ENABLED':'1','CC':'/usr/bin/cc','SDKROOT':'/Library/Developer/CommandLineTools/SDKs/MacOSX15.4.sdk'}
selector='^(TestR5TemplateEncodingBoundary.*|TestTemplateValidationAndDataBoundaries|TestTypedTemplateVariablesAndBoundedExpansion)$'
def run(n,argv,ceiling):
 cap=min(ceiling,h.left(workw,workm));r=h.supervise(argv,env,src,root/'phases'/n,min(workw,time.time()+cap),min(workm,time.monotonic()+cap),is_C=False,cleanup_dw=deadline,cleanup_dm=mono_deadline);records[n]=r;return r
try:
 pre=__import__('subprocess').run(['/bin/ps','-axo','pid=,uid=,pgid=,comm='],capture_output=True,text=True,timeout=min(.150,h.left(workw,workm)))
 import exact_external_redis_preflight as rp
 def identity(pid):
  q=__import__('subprocess').run(['/bin/ps','-p',str(pid),'-o','pid=,uid=,lstart=,comm='],capture_output=True,text=True,timeout=.150)
  if q.returncode:raise RuntimeError('externalexceptionidentityunknown')
  return rp.parse_approved_start_identity(q.stdout)
 resources=rp.classify_runtime_rows(pre.stdout,identity);dump('resource-preflight.json',resources)
 if pre.returncode or resources['unknown_heavy_rows_block']:raise RuntimeError('anotherheavyjob visible')
 policySpec=importlib.util.spec_from_file_location('currentSourcePolicy',ROOT/'scripts/r5_source_inventory.py');pol=importlib.util.module_from_spec(policySpec);policySpec.loader.exec_module(pol)
 context={'goos':'darwin','goarch':'arm64','cgo_enabled':1,'build_tag_sets':[[]],'race':False,'go_work':'off','go_flags':'','selection':'all_local_variants_superset'}
 # SOURCE policy currently permits protocol race only; declare its admitted superset context without claiming this run race.
 context['race']=True
 source=pol.capture_current_source(ROOT,purpose='protocol',policy=pol.POLICY,build_context=context)
 if any(source['files'].get(n)!=sha for n,sha in expected.items()):raise RuntimeError('approvedtemplate2SOURCEdrift')
 src.mkdir(mode=0o700)
 for rel,sha in source['files'].items():
  raw=(ROOT/rel).read_bytes()
  if hashlib.sha256(raw).hexdigest()!=sha:raise RuntimeError('capturebytesdrift')
  p=src/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(raw);p.chmod(0o444)
 if any(hashlib.sha256((ROOT/p).read_bytes()).hexdigest()!=sha for p,sha in source['files'].items()):raise RuntimeError('currentSOURCEchangedaftercapture')
 source.update(snapshot_root=str(src),admitted_SOURCE_superset_context_not_runtime_race=True,actual_this_runtime_context={'race':False,'tags':[],'GOMAXPROCS':2,'GOFLAGS':'-mod=readonly -p=1'},task2pins=expected,fullcompany_authz_app_delivery_models_sanitize_input_sourcecaptured=True);dump('source-receipt.json',source)
 for d,ds,fs in os.walk(src):os.chmod(d,0o555)
 r=run('actual-nonrace-company-deps-GoList',[go,'list','-mod=readonly','-deps','-test','-json','./internal/company'],60)
 if r['exit']!=0 or r['failures']:raise RuntimeError('firstmetadatafailure')
 # Compile evidence is GoList metadata only, separated from actual test runtime.
 selected={};unknown=[];modules={};objects=h.json_objects((root/'phases/actual-nonrace-company-deps-GoList/stdout').read_text())
 for pkg in objects:
  if pkg.get('Error') or pkg.get('DepsErrors') or pkg.get('Incomplete'):unknown.append(pkg.get('ImportPath'))
  if pkg.get('Module'):modules[pkg['Module']['Path']]=pkg['Module']
  for field in ['GoFiles','CgoFiles','CFiles','CXXFiles','MFiles','HFiles','FFiles','SFiles','SysoFiles','EmbedFiles']:
   for name in pkg.get(field,[]):
    p=P(name);p=(P(pkg['Dir'])/p).resolve() if not p.is_absolute() else p.resolve()
    if p.is_relative_to(src):
     rel=str(p.relative_to(src));selected[rel]=source['files'].get(rel)
     if selected[rel]!=hashlib.sha256(p.read_bytes()).hexdigest():unknown.append(rel)
 dump('actual-nonrace-rootMVS-compileinput-metadata.json',{'selected':selected,'unknown':unknown,'package_rows':len(objects),'module_provenance':list(modules.values()),'actual_context':'nonrace/defaulttags/darwinarm64/rootMVSlocalreplace','externalcache_toolchain_existingversionchecksums_not_fullbytesattestation':True})
 if unknown:raise RuntimeError('compileinputsunknown')
 if h.left(workw,workm)<120:raise RuntimeError('original300cannotadmitpackage120andcleanup30')
 run('exact-template-encoding-pure',[go,'test','-p=1','-count=1','-timeout=2m','-json','./internal/company','-run',selector],h.left(workw,workm))
except BaseException as e:errors.append({'class':type(e).__name__,'reason':str(e)[:240]})
finally:
 log=root/'phases/exact-template-encoding-pure/stdout';ev=[json.loads(l) for l in log.read_text().splitlines() if l.startswith('{')] if log.exists() else [];actions={};pk=[]
 for e in ev:
  if e.get('Test'):actions.setdefault(e['Test'],[]).append(e['Action'])
  elif e['Action']in {'pass','fail','skip'}:pk.append(e)
 tops=[n for n in actions if '/'not in n];leaves=[n for n in actions if not any(o.startswith(n+'/') for o in actions)];unfinished=[n for n,a in actions.items() if 'run'in a and not any(x in a for x in ['pass','fail','skip'])];post_same=False
 if source and src.exists():
  post={p:hashlib.sha256((src/p).read_bytes()).hexdigest() for p in source['files']};post_same=post==source['files'];dump('source-after.json',{'same':post_same,'files':post})
 cleanup={'noPG_Redis_SMTP_HTTPservices_started':True,'all_owned_phasegroups_gone':all(r['groupgone'] for r in records.values()),'original300elapsed':time.time()-origin,'within300':time.time()<deadline and time.monotonic()<mono_deadline,'source_same':post_same};dump('cleanup-receipt.json',cleanup)
 required={'TestTemplateValidationAndDataBoundaries','TestTypedTemplateVariablesAndBoundedExpansion'};exact=all(re.fullmatch(r'TestR5TemplateEncodingBoundary.*|TestTemplateValidationAndDataBoundaries|TestTypedTemplateVariablesAndBoundedExpansion',n) for n in tops) and required.issubset(tops)
 passed=len(tops)==8 and exact and records.get('exact-template-encoding-pure',{}).get('exit')==0 and not errors and not any(r['failures'] for r in records.values()) and not unfinished and all('pass'in a and 'fail'not in a and 'skip'not in a for a in actions.values()) and post_same and cleanup['all_owned_phasegroups_gone'] and cleanup['within300']
 dump('TEMPLATE-encoding-first-runtime-review.json',{'status':'BOUNDED_PURE_DOMAIN_PASS' if passed else 'FAILED_OR_INFRAUNKNOWN','source_sha':source.get('source_sha') if source else None,'source_closure':source.get('source_closure_sha256') if source else None,'actual_race':False,'actualGOMAXPROCS':2,'actual_top':tops,'actual_leaf':leaves,'actual_actions':actions,'package_terminal':pk,'unfinished':unfinished,'results':records,'errors':errors,'cleanup':cleanup,'protected_supervisor_source':str(helperdir/'usage19_driver_prepared_only.py'),'notRawHTTPPGpublishsendP5or171':True});print('ROOT',root,flush=True);print('COUNTS',len(tops),len(leaves),len(actions),'PASS',sum('pass'in a for a in actions.values()),'FAIL',sum('fail'in a for a in actions.values()),flush=True)
