import os,sys,time,json,tempfile,pathlib,hashlib,importlib.util,re
P=pathlib.Path;origin=time.time();mono=time.monotonic();deadline=origin+300;mono_deadline=mono+300;workw=deadline-30;workm=mono_deadline-30
root=P(tempfile.mkdtemp(prefix='tm-r5worker-shutdown.',dir='/private/tmp'));root.chmod(0o700)
for n in ['home','tmp','phases']:(root/n).mkdir(mode=0o700)
# Reuse approved sole supervision functions unchanged; no PG driver.main invocation.
helperdir=P('/private/tmp/tm-r5usage19-driver-v8-Cexecpost-SOURCE');sys.path.insert(0,str(helperdir));spec=importlib.util.spec_from_file_location('approved_supervisor',helperdir/'usage19_driver_prepared_only.py');h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
ROOT=P('/Users/jin/Desktop/tabmail');source=None;src=root/'src';records={};errors=[]
def dump(n,x):(root/n).write_text(json.dumps(x,sort_keys=True,indent=2)+'\n')
expected={'internal/workqueue/worker.go':'0416ecca3f5aac0af0b6c4c1d17035d7cd86548385bcb55d2be07f21b9721de6','internal/workqueue/r5_shutdown_boundary_test.go':'7e881ef0f61c3bffbcc854ab4fdbab5e1e6624bcf3dfb65c9d667bbcec1538ab'}
go=h.GO;env={'HOME':str(root/'home'),'TMPDIR':str(root/'tmp')+'/','PATH':str(P(go).parent)+':/usr/bin:/bin:/usr/sbin:/sbin','LANG':'en_US.UTF-8','GOTOOLCHAIN':'local','GOMODCACHE':'/Users/jin/.cache/go-mod','GOCACHE':'/Users/jin/Library/Caches/go-build','GOPROXY':'off','GOSUMDB':'sum.golang.org','GOWORK':'off','GOMAXPROCS':'2','GOFLAGS':'-mod=readonly -p=1','CGO_ENABLED':'1','CC':'/usr/bin/cc','SDKROOT':'/Library/Developer/CommandLineTools/SDKs/MacOSX15.4.sdk'}
selector=None
def run(n,argv,ceiling):
 cap=min(ceiling,h.left(workw,workm));r=h.supervise(argv,env,src,root/'phases'/n,min(workw,time.time()+cap),min(workm,time.monotonic()+cap),is_C=False,cleanup_dw=deadline,cleanup_dm=mono_deadline);records[n]=r;return r
dump('original-budget-serialized.json',{'origin_wall_actual_before_capture':origin,'origin_mono_actual_before_capture':mono,'original_deadline_wall':deadline,'original_deadline_mono':mono_deadline,'workstop_wall':workw,'workstop_mono':workm,'budget_seconds':300,'cleanup_reserved_seconds':30,'clock_source':'controller time.time/time.monotonic self-reported; not trusted external attestation','sequence':'origin -> resourcepreflight -> SOURCE capture -> GoList actualcontext -> go test -> cleanup/post'})
try:
 pre=__import__('subprocess').run(['/bin/ps','-axo','pid=,uid=,pgid=,comm='],capture_output=True,text=True,timeout=min(.150,h.left(workw,workm)))
 import exact_external_redis_preflight as rp
 def identity(pid):
  q=__import__('subprocess').run(['/bin/ps','-p',str(pid),'-o','pid=,uid=,lstart=,comm='],capture_output=True,text=True,timeout=.150)
  if q.returncode:raise RuntimeError('externalexceptionidentityunknown')
  return rp.parse_approved_start_identity(q.stdout)
 resources=rp.classify_runtime_rows(pre.stdout,identity);dump('resource-preflight.json',resources)
 if pre.returncode or resources['unknown_heavy_rows_block']:raise RuntimeError('anotherheavyjob visible')
 policySpec=importlib.util.spec_from_file_location('currentSourcePolicy',ROOT/'scripts/r5_source_inventory.py');pol=importlib.util.module_from_spec(policySpec);policySpec.loader.exec_module(pol)
 context={'goos':'darwin','goarch':'arm64','cgo_enabled':1,'build_tag_sets':[[]],'race':False,'go_work':'off','go_flags':'','selection':'all_local_variants_superset'}
 # SOURCE policy currently permits protocol race only; declare its admitted superset context without claiming this run race.
 context['race']=True
 source=pol.capture_current_source(ROOT,purpose='protocol',policy=pol.POLICY,build_context=context)
 if any(source['files'].get(n)!=sha for n,sha in expected.items()):raise RuntimeError('approvedtemplate2SOURCEdrift')
 src.mkdir(mode=0o700)
 for rel,sha in source['files'].items():
  raw=(ROOT/rel).read_bytes()
  if hashlib.sha256(raw).hexdigest()!=sha:raise RuntimeError('capturebytesdrift')
  p=src/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(raw);p.chmod(0o444)
 if any(hashlib.sha256((ROOT/p).read_bytes()).hexdigest()!=sha for p,sha in source['files'].items()):raise RuntimeError('currentSOURCEchangedaftercapture')
 source.update(snapshot_root=str(src),admitted_SOURCE_superset_context_not_runtime_race=True,actual_this_runtime_context={'race':False,'tags':[],'GOMAXPROCS':2,'GOFLAGS':'-mod=readonly -p=1'},task2pins=expected,fullcompany_authz_app_delivery_models_sanitize_input_sourcecaptured=True);dump('source-receipt.json',source)
 for d,ds,fs in os.walk(src):os.chmod(d,0o555)
 r=run('actual-race-workqueue-deps-GoList',[go,'list','-race','-mod=readonly','-deps','-test','-json','./internal/workqueue'],60)
 if r['exit']!=0 or r['failures']:raise RuntimeError('firstmetadatafailure')
 # Compile evidence is GoList metadata only, separated from actual test runtime.
 selected={};unknown=[];modules={};objects=h.json_objects((root/'phases/actual-race-workqueue-deps-GoList/stdout').read_text())
 for pkg in objects:
  if pkg.get('Error') or pkg.get('DepsErrors') or pkg.get('Incomplete'):unknown.append(pkg.get('ImportPath'))
  if pkg.get('Module'):modules[pkg['Module']['Path']]=pkg['Module']
  for field in ['GoFiles','CgoFiles','CFiles','CXXFiles','MFiles','HFiles','FFiles','SFiles','SysoFiles','EmbedFiles']:
   for name in pkg.get(field,[]):
    p=P(name);p=(P(pkg['Dir'])/p).resolve() if not p.is_absolute() else p.resolve()
    if p.is_relative_to(src):
     rel=str(p.relative_to(src));selected[rel]=source['files'].get(rel)
     if selected[rel]!=hashlib.sha256(p.read_bytes()).hexdigest():unknown.append(rel)
 declared=[];declared_files=[]
 for pkg in objects:
  if pkg.get('ImportPath')=='tabmail/internal/workqueue':
   for name in pkg.get('TestGoFiles',[])+pkg.get('XTestGoFiles',[]):
    p=P(pkg['Dir'])/name;declared_files.append(str(p.relative_to(src)));declared+=re.findall(r'^func\s+(Test[A-Z_][A-Za-z0-9_]*)\s*\([^)]*\*testing\.T\s*\)',p.read_text(),re.MULTILINE)
 if not declared or len(declared)!=len(set(declared)):raise RuntimeError('defaulttestdiscoverymissing/duplicate')
 dump('expected-default-workqueue-top-set.json',{'required_top_tests':declared,'actualdefaultGoList_TestGoFiles':declared_files,'declarations_not_PASS':True,'SourceContext_actual_race':True})
 dump('actual-race-workqueue-rootMVS-compileinput-metadata.json',{'selected':selected,'unknown':unknown,'package_rows':len(objects),'module_provenance':list(modules.values()),'actual_context':'race/defaulttags/darwinarm64/rootMVSlocalreplace','externalcache_toolchain_existingversionchecksums_not_fullbytesattestation':True})
 if unknown:raise RuntimeError('compileinputsunknown')
 if h.left(workw,workm)<90:raise RuntimeError('original300cannotadmitpackage90andcleanup30')
 run('whole-workqueue-race',[go,'test','-race','-p=1','-parallel=1','-count=1','-timeout=90s','-json','./internal/workqueue'],h.left(workw,workm))
except BaseException as e:errors.append({'class':type(e).__name__,'reason':str(e)[:240]})
finally:
 log=root/'phases/whole-workqueue-race/stdout';ev=[json.loads(l) for l in log.read_text().splitlines() if l.startswith('{')] if log.exists() else [];actions={};pk=[]
 for e in ev:
  if e.get('Test'):actions.setdefault(e['Test'],[]).append(e['Action'])
  elif e['Action']in {'pass','fail','skip'}:pk.append(e)
 tops=[n for n in actions if '/'not in n];leaves=[n for n in actions if not any(o.startswith(n+'/') for o in actions)];unfinished=[n for n,a in actions.items() if 'run'in a and not any(x in a for x in ['pass','fail','skip'])];post_same=False
 if source and src.exists():
  post={p:hashlib.sha256((src/p).read_bytes()).hexdigest() for p in source['files']};post_same=post==source['files'];dump('source-after.json',{'same':post_same,'files':post})
 cleanup={'noPG_Redis_SMTP_HTTPservices_started':True,'all_owned_phasegroups_gone':all(r['groupgone'] for r in records.values()),'original300elapsed':time.time()-origin,'within300':time.time()<deadline and time.monotonic()<mono_deadline,'source_same':post_same};dump('cleanup-receipt.json',cleanup)
 expected_tops=[]
 if source and (root/'expected-default-workqueue-top-set.json').exists():expected_tops=json.loads((root/'expected-default-workqueue-top-set.json').read_text())['required_top_tests']
 exact=set(tops)==set(expected_tops) and len(tops)==len(expected_tops)
 passed=exact and bool(tops) and records.get('whole-workqueue-race',{}).get('exit')==0 and not errors and not any(r['failures'] for r in records.values()) and not unfinished and all('pass'in a and 'fail'not in a and 'skip'not in a for a in actions.values()) and post_same and cleanup['all_owned_phasegroups_gone'] and cleanup['within300']
 dump('WORKER-shutdown-whole-race-first-runtime-review.json',{'status':'BOUNDED_PURE_DOMAIN_PASS' if passed else 'FAILED_OR_INFRAUNKNOWN','source_sha':source.get('source_sha') if source else None,'source_closure':source.get('source_closure_sha256') if source else None,'actual_race':True,'actualGOMAXPROCS':2,'actual_top':tops,'actual_leaf':leaves,'actual_actions':actions,'package_terminal':pk,'unfinished':unfinished,'results':records,'errors':errors,'cleanup':cleanup,'protected_supervisor_source':str(helperdir/'usage19_driver_prepared_only.py'),'notOutboundIngestHooksMain_callers_or_P6or171':True});print('ROOT',root,flush=True);print('COUNTS',len(tops),len(leaves),len(actions),'PASS',sum('pass'in a for a in actions.values()),'FAIL',sum('fail'in a for a in actions.values()),flush=True)
