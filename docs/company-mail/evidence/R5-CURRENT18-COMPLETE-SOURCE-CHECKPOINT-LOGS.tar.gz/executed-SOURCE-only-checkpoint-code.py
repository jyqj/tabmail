"""One source-only checkpoint, no Go/process/PG/tests/build or runtime qualification."""
from pathlib import Path
import os,json,hashlib,time,tempfile,re,stat,fnmatch
ROOT=Path('/Users/jin/Desktop/tabmail');OUT=Path(tempfile.mkdtemp(prefix='tm-r5current18-complete-SOURCE.',dir='/private/tmp'));OUT.chmod(0o700);SRC=OUT/'editable-source-tree';SRC.mkdir(mode=0o700);origin=time.time()
EXCLUDED_DIRS={'.git','node_modules','.next','.vercel','coverage','__pycache__','.pytest_cache','.mypy_cache','.cache','out','build','dist','.venv','venv','.vite','test-results','playwright-report'}
EXCLUDED_SUFFIXES={'.pyc','.pyo','.log','.tsbuildinfo','.prof','.pprof','.trace','.pid','.socket'}
excluded=[];source_symlinks=[]
def selected_paths():
 paths=[]
 for current,dirs,files in os.walk(ROOT,followlinks=False):
  base=Path(current)
  kept=[]
  for n in sorted(dirs):
   p=base/n;rel=p.relative_to(ROOT).as_posix()
   if n in EXCLUDED_DIRS:excluded.append({'path':rel,'reason':'generated_cache_runtime_or_git_not_source'});continue
   if p.is_symlink():source_symlinks.append(rel);continue
   kept.append(n)
  dirs[:]=kept
  for n in sorted(files):
   p=base/n;rel=p.relative_to(ROOT).as_posix()
   if p.is_symlink():source_symlinks.append(rel);continue
   if n in {'.DS_Store','.npmrc','next-env.d.ts'}:excluded.append({'path':rel,'reason':'host_config_or_generated_ambient_not_source'});continue
   if n.startswith('.env') and not (n=='.env.example' or rel=='third_party/enmime-v2.3.0/.envrc'):excluded.append({'path':rel,'reason':'production_or_secret_environment_unread'});continue
   if p.suffix in EXCLUDED_SUFFIXES:excluded.append({'path':rel,'reason':'runtime_profile_log_or_generatedfile_not_source'});continue
   if rel.startswith('docs/company-mail/evidence/') and n.endswith(('.tar.gz','.zip','.tgz','.gz')):excluded.append({'path':rel,'reason':'historical_runtime_evidence_archive_not_editable_source; retained_original_in_checkout'});continue
   if not stat.S_ISREG(p.lstat().st_mode):raise ValueError('unknown nonregular source input '+rel)
   paths.append(rel)
 return sorted(paths)
def digest(b):return hashlib.sha256(b).hexdigest()
def dump(n,x):(OUT/n).write_text(json.dumps(x,sort_keys=True,indent=2)+'\n')
paths=selected_paths()
if source_symlinks:raise ValueError('unknown selected source symlink paths '+str(source_symlinks))
files={};stats={};sizes={}
try:
 for rel in paths:
  p=ROOT/rel;before=p.stat();raw=p.read_bytes();after=p.stat()
  if (before.st_ino,before.st_size,before.st_mtime_ns)!=(after.st_ino,after.st_size,after.st_mtime_ns):raise ValueError('source changed during individual read '+rel)
  q=SRC/rel;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(raw);q.chmod(0o444);files[rel]=digest(raw);sizes[rel]=len(raw);stats[rel]={'inode':before.st_ino,'bytes':before.st_size,'mtime_ns':before.st_mtime_ns}
 if set(selected_paths())!=set(paths):raise ValueError('source path set changed during checkpoint')
 post={};changed=[]
 # One bounded after-pass verifies the same current files; never second capture/retry.
 for rel in paths:
  h=digest((ROOT/rel).read_bytes());post[rel]=h
  if h!=files[rel]:changed.append(rel)
 wire=json.dumps(files,sort_keys=True,separators=(',',':')).encode();source=hashlib.sha1(wire).hexdigest();closure=digest(wire)
 versions={int(Path(rel).name.split('_',1)[0]):rel for rel in files if rel.startswith('internal/store/postgres/migrations/') and re.match(r'[0-9]+_.*\.sql$',Path(rel).name)}
 if sorted(versions)!=list(range(1,19)):raise ValueError('current source migrations not exact1..18 '+str(sorted(versions)))
 collector='internal/store/postgres/r5_current_benchmark_catalog_test.go';assert files[collector]=='cbc7b296edd81836a6268c2d8fa9d7ad0721344d5b4c28d4d89f308c81f9acb8';assert (SRC/collector).read_text().startswith('//go:build r5benchmark\n')
 pins={'catalog_collectorV5':{collector:files[collector]},'keycausal':{'internal/store/postgres/r5_key_touch_admission_test.go':'7dfe893dbccb5fc2f46d360cb717880e9dee37d17080595c4239378c7276060f'},'receipt2':{'internal/store/postgres/r5_legacy_content_test.go':'772fee9066e24b1602f32aae87dda5d212e7b56ee9e567a5d3c5027d06ace138','internal/store/postgres/r5_outbound_receipt_test.go':'479468473933b723b8a349dd413f86a9562bee4f56811bf37e5653028fb5f7ab'}}
 web=json.loads(Path('/private/tmp/tabmail-webhook-destination-source-v2-20261003T025544/manifest.json').read_text());pins['Webhook9']={rel:files[rel] for rel in web['closure_paths']};wh=hashlib.sha256();wh.update(b'TABMAIL-SOURCE-CLOSURE-V2\0')
 for rel in sorted(web['closure_paths'],key=lambda p:p.encode()):
  pb=rel.encode();raw=(SRC/rel).read_bytes();wh.update(len(pb).to_bytes(4,'big'));wh.update(pb);wh.update(b'\1');wh.update(len(raw).to_bytes(8,'big'));wh.update(raw)
 assert wh.hexdigest()=='27f5ebd21dff09d91cfb6069ee827a0ac0ad03af4e618d5b04bd6a12e3655d84'
 mime=json.loads(Path('/private/tmp/tm-r5mime-fork-v5-source-ars222hh/capsule.json').read_text());pins['MIME224']={rel:row['sha256'] for rel,row in mime['combined_task_source_pins'].items()}
 hist=json.loads(Path('/tmp/tm-historical-identity-handler-v3-4_r8jadg/execution-packet.json').read_text());pins['historical5']={row['path']:row['released_sha256'] for row in hist['files']}
 c18=json.loads(Path('/tmp/r5-c18-contract-evidence-source-v2-20261003/source-delta.json').read_text());pins['C18grammarV2_7']={row['path']:row['after_sha256'] for row in c18['files']}
 for group,mapping in pins.items():
  for rel,h in mapping.items():assert files[rel]==h,(group,rel,'scopedpin drift')
 mod=(SRC/'go.mod').read_text();assert 'replace github.com/jhillyerd/enmime/v2 v2.3.0 => ./third_party/enmime-v2.3.0' in mod
 fork=[rel for rel in files if rel.startswith('third_party/enmime-v2.3.0/')];assert len(fork)==219,len(fork)
 for name in ['go.mod','go.sum','LICENSE','PROVENANCE.json','UPSTREAM-MANIFEST.json','UPSTREAM-DELTA.patch']:assert 'third_party/enmime-v2.3.0/'+name in files
 embeds=['internal/api/docsassets/swagger-ui.css','internal/api/docsassets/redoc.standalone.js','internal/api/docsassets/swagger-ui-bundle.js']
 for rel in embeds:assert rel in files
 checks={'source_before_after_identical':not changed,'changed_paths':changed,'path_set_before_after_identical':True,'migration_versions':sorted(versions),'actual_source_max18':max(versions),'root_entry_cmd_tabmail_main_go':files.get('cmd/tabmail/main.go'),'root_MVS_relative_replace_present':True,'rootmodsum':{n:files[n] for n in ['go.mod','go.sum']},'fork219':len(fork),'fork_license_provenance_modules_preserved':True,'router_docs3embeds':{p:files[p] for p in embeds},'all_ordinary_source_binary_assets_included_not_go_suffix_only':True,'GoList_selected_compileinputs_not_newly_attested':True,'no_runtime_object_profile_envcredential_inputs':True}
 dump('source-checkpoint-before-after.json',checks);dump('scoped-source-pins.json',pins)
 dump('source-file-stat-before.json',stats);dump('canonical-source-manifest.json',{'files':files,'byte_counts':sizes});(OUT/'canonical-source-files.json').write_bytes(wire)
 receipt={'status':'CURRENT18_PRE_MIGRATION19_SOURCE_CHECKPOINT_PASS' if not changed else 'SOURCE_DRIFT_FAIL_NO_RECAPTURE','source_identity_kind':'canonical_complete_editable_current18_source_tree_sha1_nonruntime_checkpoint','source_sha':source,'actual_source_closure_sha256':closure,'canonical_algorithm':"SHA1/SHA256(json.dumps(files,sort_keys=True,separators=(',',':')).encode('utf-8')); ensure_ascii=True/no newline",'source_root_before':str(ROOT),'readonly_editable_source_tree':str(SRC),'files':len(files),'total_source_bytes':sum(sizes.values()),'head_locator_only':'587ba75 NOT sourceidentity','origin_wall':origin,'elapsed_seconds':time.time()-origin,'generation':'SOURCE18 beforemigration19; allmigrations1..18/fullcollectorV5 SOURCE-only','boundary':'Complete ordinary source/docs/deployment/frontend/assets/localfork; excludes build/cache/Git/privateenvironment/runtimeobjects/profiles/runtime-evidence archives. No Go/PG/tests/GoList/metadata subprocess invoked; SOURCE not owner/reference/catalog qualification or method admission. Externalcache/toolchain existingversionchecksum boundary retained, bytes not freshhashed','source_before_after_stable':not changed,'external_cache_reference_only':{'Go':'go1.25.7 cachedtoolchain','enmime':'rootrequire v2.3.0 localthird_party219','module_checksums':'rootgo.sum captured; cached modules not copied or rehashed'},'excluded_entries':sorted({(e['path'],e['reason']) for e in excluded}),'old_manifests_and_failed_runtime_artifacts_preserved':True}
 dump('SOURCE18-checkpoint-receipt.json',receipt)
 selector=json.loads(Path('/private/tmp/r5-c18-fullcatalog-source-v5-20261003/fresh-selectors.json').read_text());names=selector['pure_top'];assert len(names)==15 and len(set(names))==15;regex='^('+'|'.join(names)+')$';go='/Users/jin/.cache/go-mod/golang.org/toolchain@v0.0.1-go1.25.7.darwin-arm64/bin/go'
 dump('CATALOG15-pure-RESOURCE-PREPARED-NOT-RUN.json',{'status':'PREPARED_ONLY_NOT_AUTHORIZED_RUNTIME','source_sha':source,'source_closure_sha256':closure,'cwd':str(SRC),'exact15names':names,'exact_regex':regex,'prospective_tag_metadata_argv':[go,'list','-race','-mod=readonly','-tags=r5benchmark','-deps','-test','-json','./internal/store/postgres'],'prospective_pure_test_argv':[go,'test','-race','-mod=readonly','-json','-p','1','-parallel','1','-count=1','-timeout=60s','-tags=r5benchmark','./internal/store/postgres','-run',regex],'actual_env_allowlist':{'GOTOOLCHAIN':'local','GOMAXPROCS':'2','GOFLAGS':'-mod=readonly -p=1','GOMODCACHE':'/Users/jin/.cache/go-mod','GOPROXY':'off','GOWORK':'off'},'all_TABMAIL_TEST_DB_DSN_ownedreference_owner_approval_variables_must_be_absent_before_future_pure':True,'ownedtop_explicitly_not_selected':selector['owned_top'],'newSOURCE_catalog_owner_or_reference_not_available':True,'runtime_reference_ready':False,'full_semantic_reference_qualified':False,'SQLqualification':False,'resource_proposal_only':{'outer_absolute_seconds':180,'package_timeout_seconds':60,'cleanup_reserved_seconds':30,'PG_redis_native_listener':0},'metadata_not_executed_now':True,'pure_not_executed_now':True})
 for d,ds,fs in os.walk(SRC):os.chmod(d,0o555)
 print(json.dumps({'root':str(OUT),'source_sha':source,'closure_sha256':closure,'source_files':len(files),'source_bytes':sum(sizes.values()),'stable':not changed,'collector_pin':files[collector]}))
 if changed:raise SystemExit(1)
except BaseException as e:
 dump('SOURCE-checkpoint-error.json',{'class':type(e).__name__,'reason':str(e),'partial_snapshot_preserved_no_recapture':True,'no_Go_PG_test_metadata_or_owner_catalog_qualification':True});print('SOURCE_CHECKPOINT_ERROR',str(OUT),type(e).__name__,str(e));raise
