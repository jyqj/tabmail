import os,sys,json,unittest,pathlib
ROOT=pathlib.Path(sys.argv[1]);sys.path[:0]=[str(ROOT),str(ROOT/'scripts')]
auditpath=pathlib.Path(sys.argv[2]);resultpath=pathlib.Path(sys.argv[3])
def audit(event,args):
 if event.startswith('subprocess.') or event in ('os.system','os.posix_spawn','os.posix_spawnp'):
  auditpath.write_text(json.dumps({'event':event,'real_child_dispatch_stopped_before_start':True,'command_arguments_not_dumped':True}))
  os._exit(97)
sys.addaudithook(audit)
from scripts.tests import test_r5_current_source_inventory as current
names=['scripts.tests.test_r5_current_source_inventory.CurrentSourceInventoryTests',
'scripts.tests.test_r5_protocol_source_inventory.ProtocolSourceInventoryTests.test_explicit_canonical_closure_not_head_commit',
'scripts.tests.test_r5_protocol_source_inventory.ProtocolSourceInventoryTests.test_current_missing_policy_and_git_inventory_are_not_fallback',
'scripts.tests.test_r5_benchmark.BenchmarkProcessTests.test_source_closure_tracks_dependencies_and_content_drift',
'scripts.tests.test_r5_benchmark.BenchmarkLookaheadTests.test_current_closure_blocks_legacy_method_identity_until_explicit_migration',
'scripts.tests.test_r5_benchmark.BenchmarkLookaheadTests.test_runner_default_overrides_ambient_optin_and_selected_source_must_match',
'scripts.tests.test_r5_benchmark.BenchmarkLookaheadMAdmissionTests.test_current_M_legacy_method_requires_policy_migration_without_dispatch_or_L',
'scripts.tests.test_r5_protocol.SharedInfrastructureCannotBeProductGreenTests.test_compile_panic_timeout_unknown_error_and_missing_runtime_are_not_green']
suite=unittest.defaultTestLoader.loadTestsFromNames(names)
def flatten(s):
 for x in s:
  if isinstance(x,unittest.TestSuite):yield from flatten(x)
  else:yield x
ids=[x.id() for x in flatten(suite)];assert not any('_FailedTest' in x for x in ids)
resultpath.with_name('actual-synthetic-discovery.json').write_text(json.dumps({'selected':names,'actual_method_names':ids,'actual_methods':len(ids),'CurrentSourceInventoryTests_fullclass_methods':len([x for x in ids if '.CurrentSourceInventoryTests.' in x]),'not_realGo_protocol_or_benchmark':True},sort_keys=True,indent=2))
class Recorded(unittest.TextTestResult):
 def __init__(self,*a,**kw):super().__init__(*a,**kw);self.events=[]
 def startTest(self,t):self.events.append({'test':t.id(),'action':'start'});super().startTest(t)
 def addSuccess(self,t):self.events.append({'test':t.id(),'action':'pass'});super().addSuccess(t)
 def addError(self,t,e):self.events.append({'test':t.id(),'action':'error','class':e[0].__name__});super().addError(t,e)
 def addFailure(self,t,e):self.events.append({'test':t.id(),'action':'fail','class':e[0].__name__});super().addFailure(t,e)
 def addSkip(self,t,why):self.events.append({'test':t.id(),'action':'skip'});super().addSkip(t,why)
r=unittest.TextTestRunner(verbosity=2,resultclass=Recorded).run(suite)
resultpath.write_text(json.dumps({'testsRun':r.testsRun,'errors':len(r.errors),'failures':len(r.failures),'skipped':len(r.skipped),'successes':sum(e['action']=='pass' for e in r.events),'events':r.events,'actual_real_source_capture_not_repeated_by_synthetic':True},sort_keys=True,indent=2))
sys.exit(0 if r.wasSuccessful() else 1)
