package policy

import "testing"

func TestReviewLiteralTerminalRootDotDenyIsPreserved(t *testing.T) {
    for _, pattern := range []string{`blocked.example\.`, `blocked.example[.]`} {
        t.Run(pattern, func(t *testing.T) {
            domain := "blocked.example."
            patterns := []string{pattern}
            if !ShouldRejectOrigin("sender@"+domain, patterns) {
                t.Error("existing literal-root origin deny did not match")
            }
            if ShouldAcceptDomain(domain, true, nil, patterns) {
                t.Error("existing literal-root recipient deny changed to accept")
            }
            if ShouldStoreDomain(domain, true, nil, patterns) {
                t.Error("existing literal-root discard changed to store")
            }
        })
    }
}
