package policy

import (
	"path"
	"strings"
)

func ShouldAcceptDomain(domain string, defaultAccept bool, acceptDomains, rejectDomains []string) bool {
	domain = canonicalPolicyDomain(domain)
	if domain == "" {
		return false
	}
	if defaultAccept {
		return !matchDomainList(domain, rejectDomains)
	}
	return matchDomainList(domain, acceptDomains)
}

func ShouldStoreDomain(domain string, defaultStore bool, storeDomains, discardDomains []string) bool {
	domain = canonicalPolicyDomain(domain)
	if domain == "" {
		return false
	}
	if defaultStore {
		return !matchDomainList(domain, discardDomains)
	}
	return matchDomainList(domain, storeDomains)
}

func matchDomainList(domain string, patterns []string) bool {
	for _, pattern := range patterns {
		pattern = canonicalPolicyDomain(pattern)
		if pattern == "" {
			continue
		}
		if ok, _ := path.Match(pattern, domain); ok {
			return true
		}
	}
	return false
}

// DNS names may carry one terminal root dot. Match the same spelling on both
// sides of each policy without changing resolver identities or glob semantics.
// Do not turn a root-only name into an empty origin or repair empty labels.
func canonicalPolicyDomain(domain string) string {
	domain = strings.ToLower(strings.TrimSpace(domain))
	if len(domain) > 1 && strings.HasSuffix(domain, ".") && !strings.HasSuffix(domain, "..") {
		domain = strings.TrimSuffix(domain, ".")
	}
	return domain
}
