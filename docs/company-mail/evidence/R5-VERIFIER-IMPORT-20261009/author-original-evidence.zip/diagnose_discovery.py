"""Private original-CLI import diagnosis: never execute any test method."""
import json
import os
from pathlib import Path
import subprocess
import sys

root = Path(sys.argv[1]).resolve()
expected = sys.argv[2]
output = Path(sys.argv[3]).resolve()

def identity():
    return dict(commit=subprocess.check_output(['git', '-C', str(root), 'rev-parse', 'HEAD'], text=True).strip(),
        tree=subprocess.check_output(['git', '-C', str(root), 'rev-parse', 'HEAD^{tree}'], text=True).strip(),
        status=subprocess.check_output(['git', '-C', str(root), 'status', '--porcelain', '--untracked-files=all'], text=True))

before = identity()
if before['commit'] != expected or before['status']:
    raise ValueError('diagnosis requires exact clean source')

# A script invocation puts scripts/, not the repository root, at sys.path[0].
# This is the original CLI's lookup environment; do not inject the scripts
# package's parent to make the module-style unittest invocation work.
os.chdir(root)
sys.path[0] = str(root / 'scripts')
if str(root) in sys.path or '' in sys.path:
    raise ValueError('repository root must not be on this original-CLI path')
import run_r5_source_version_tests as runner
loader = runner.unittest.TestLoader()
suite = loader.discover(str(root / 'scripts/tests'), pattern='test_*.py')
ids = [test.id() for test in runner.flatten(suite)]
after = identity()
if before != after:
    raise ValueError('source changed during import-only diagnosis')
report = dict(scope='import/discovery only; no test methods executed', before=before, after=after,
    argv=sys.argv, sys_path=sys.path, runner_file=runner.__file__,
    selected_go=os.environ.get('R5_TEST_GO'), method_count_including_failed_placeholders=len(ids),
    failed_test_ids=[identity for identity in ids if identity.startswith('unittest.loader._FailedTest')],
    loader_errors=loader.errors, tests_executed=0)
with output.open('x') as stream:
    json.dump(report, stream, indent=2)
    stream.write('\n')
print(json.dumps(report, indent=2))
