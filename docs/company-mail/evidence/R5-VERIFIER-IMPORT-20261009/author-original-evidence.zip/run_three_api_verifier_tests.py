"""Run exactly the three original verifier tests through the CLI import path."""
import importlib
import json
import os
from pathlib import Path
import subprocess
import sys
import traceback
import unittest

root = Path(sys.argv[1]).resolve()
expected_commit = sys.argv[2]
output = Path(sys.argv[3]).resolve()
expected_ids = sorted('test_r5_api_key_issuance.APIKeyIssuanceVerifierTest.' + name for name in (
    'test_accepts_only_complete_declared_execution',
    'test_rejects_missing_duplicate_and_skipped_results',
    'test_baseline_http_failure_is_not_a_stale_issuance'))

def identity():
    return dict(commit=subprocess.check_output(['git', '-C', str(root), 'rev-parse', 'HEAD'], text=True).strip(),
        tree=subprocess.check_output(['git', '-C', str(root), 'rev-parse', 'HEAD^{tree}'], text=True).strip(),
        status=subprocess.check_output(['git', '-C', str(root), 'status', '--porcelain', '--untracked-files=all'], text=True))

before = identity()
if before['commit'] != expected_commit or before['status']:
    raise ValueError('execution requires exact clean source')
os.chdir(root)
sys.path[0] = str(root / 'scripts')
sys.path.insert(0, str(root / 'scripts/tests'))
if str(root) in sys.path or '' in sys.path:
    raise ValueError('repository parent package path is not allowed')
report = dict(scope='exact three original synthetic verifier test methods; not PostgreSQL execution',
    before=before, expected_ids=expected_ids, tests_run=0, actual_ids=[], failures=[], errors=[],
    skips=[], expected_failures=[], unexpected_successes=[], argv=sys.argv, sys_path=sys.path)

class ObservedResult(unittest.TextTestResult):
    def startTest(self, test):
        report['actual_ids'].append(test.id())
        super().startTest(test)

try:
    importlib.import_module('test_r5_api_key_issuance')
    suite = unittest.TestLoader().loadTestsFromNames(expected_ids)
    result = unittest.TextTestRunner(verbosity=2, resultclass=ObservedResult).run(suite)
    report.update(tests_run=result.testsRun, failures=[(test.id(), text) for test, text in result.failures],
        errors=[(test.id(), text) for test, text in result.errors], skips=[(test.id(), reason) for test, reason in result.skipped],
        expected_failures=[(test.id(), text) for test, text in result.expectedFailures],
        unexpected_successes=[test.id() for test in result.unexpectedSuccesses])
    ok = (result.wasSuccessful() and report['actual_ids'] == expected_ids and result.testsRun == 3 and
          not result.skipped and not result.expectedFailures and not result.unexpectedSuccesses)
except Exception:
    report['import_error'] = traceback.format_exc()
    ok = False
finally:
    report['after'] = identity()
    if before != report['after']:
        raise ValueError('source changed during fixed verifier execution')

report['status'] = 'pass' if ok else 'fail'
with output.open('x') as stream:
    json.dump(report, stream, indent=2)
    stream.write('\n')
print(json.dumps(report, indent=2))
raise SystemExit(0 if ok else 1)
