"""Run the original catalog guard and reject one original API assertion mutation."""
from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys
import time


ROOT = Path('/workspace/scratch/02f0b8733500/tabmail-catalog15-review')
OUTPUT = Path('/workspace/scratch/02f0b8733500/advance-import-review')
TARGET = 'test_r5_catalog_reconciliation.ReviewedCatalogReconciliationTests.test_revision15_preserves_public_history_collectors_and_original_rejections'
API = ROOT / 'scripts/tests/test_r5_api_key_issuance.py'


def identity():
    def git(*args):
        return subprocess.check_output(['git', '-C', str(ROOT), *args], text=True).strip()
    return dict(commit=git('rev-parse', 'HEAD'), tree=git('rev-parse', 'HEAD^{tree}'),
                status=git('status', '--porcelain', '--untracked-files=all'))


def execute(label):
    before = identity()
    env = dict(os.environ, PYTHONPATH=str(ROOT / 'scripts') + ':' + str(ROOT / 'scripts/tests'),
               PYTHONDONTWRITEBYTECODE='1')
    command = [sys.executable, '-B', '-m', 'unittest', '-v', TARGET]
    started = time.time()
    run = subprocess.run(command, cwd=ROOT, env=env, capture_output=True)
    stdout = OUTPUT / (label + '.stdout.txt')
    stderr = OUTPUT / (label + '.stderr.txt')
    stdout.write_bytes(run.stdout)
    stderr.write_bytes(run.stderr)
    report = dict(boundary='One unchanged catalog preservation method; no other tests or historical clones requested.',
                  command=command, before=before, after=identity(), exit_code=run.returncode,
                  duration_seconds=time.time() - started, target_id=TARGET,
                  pythonpath=env['PYTHONPATH'], go=env['R5_TEST_GO'],
                  go_version=subprocess.check_output([env['R5_TEST_GO'], 'version'], text=True).strip(),
                  stdout=dict(path=stdout.name, bytes=len(run.stdout), sha256=hashlib.sha256(run.stdout).hexdigest()),
                  stderr=dict(path=stderr.name, bytes=len(run.stderr), sha256=hashlib.sha256(run.stderr).hexdigest()))
    (OUTPUT / (label + '.json')).write_text(json.dumps(report, indent=2) + '\n')
    return report, run.stderr.decode()


before = identity()
if before['status'] or before['commit'] != 'a5b720d1db6d1932fced4877912cca86dd86117f':
    raise ValueError('must start from exact clean independent candidate')
original = API.read_bytes()
positive, positive_log = execute('candidate-guard-positive')
if positive['exit_code'] != 0 or 'Ran 1 test in ' not in positive_log or not positive_log.endswith('\nOK\n'):
    raise ValueError('positive original guard must execute and pass')

old_assertion = b'self.assertEqual(result["leaf_count"], 18)'
new_assertion = b'self.assertEqual(result["leaf_count"], 19)'
if original.count(old_assertion) != 1:
    raise ValueError('mutation must identify one exact original assertion')
mutated = original.replace(old_assertion, new_assertion, 1)
try:
    API.write_bytes(mutated)
    negative, negative_log = execute('candidate-guard-assertion-tamper')
    rejected = (negative['exit_code'] == 1 and 'Ran 1 test in ' in negative_log
                and negative_log.endswith('\nFAILED (failures=1)\n')
                and 'self.assertEqual((ROOT / path).read_bytes(), expected)' in negative_log
                and 'AssertionError:' in negative_log)
finally:
    API.write_bytes(original)
after = identity()
if before != after or API.read_bytes() != original:
    raise ValueError('source did not restore exactly after negative control')
summary = dict(before=before, after=after, original_guard_positive=positive['exit_code'] == 0,
               actual_original_assertion_tamper_rejected=rejected,
               mutation=dict(path=str(API.relative_to(ROOT)), old=old_assertion.decode(), new=new_assertion.decode(),
                             original_sha256=hashlib.sha256(original).hexdigest(),
                             mutated_sha256=hashlib.sha256(mutated).hexdigest()),
               positive_receipt='candidate-guard-positive.json', negative_receipt='candidate-guard-assertion-tamper.json',
               restored_source_bytes=True, runtime_verified=False, product_green=False, task_complete=False)
(OUTPUT / 'guard-review.json').write_text(json.dumps(summary, indent=2) + '\n')
if not rejected:
    raise ValueError('the existing exact-source assertion did not reject the modified test assertion')
print(json.dumps(summary, indent=2))
