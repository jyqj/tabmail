# Independent review: source-runner discovery import repair

Decision: **ACCEPT**, scoped to the two-file maintenance change. This review completes no additional product TODO.

## Source identities

- Baseline: `4730c648b1c31c34588d585256ff17f417a86b3a`, tree `19dbe626627213b474bbaa54f41740976a3e6def`.
- Reviewed combined candidate: `a5b720d1db6d1932fced4877912cca86dd86117f`, tree `f3c8519ad94e09d0c0bf93e76fafe91d308a953c`.
- Independent ordinary clone: `/workspace/scratch/02f0b8733500/tabmail-catalog15-review`.
- The discovery and positive executions began and ended at this exact clean candidate. The negative control temporarily modified one assertion only in this independent clone, then restored the original bytes and the same clean identity.

## Finding and reviewed change

The original file entrypoint puts `scripts/`, rather than its repository parent, on `sys.path`. Native discovery adds `scripts/tests/`. The newly added API verifier test's former `from scripts import ...` therefore raised `ModuleNotFoundError` under that entrypoint. The unchanged source runner rejects the resulting `_FailedTest` with `ValueError('test discovery import failure')` before its preparation-report catch.

The candidate loads the same verifier module by an explicit file path derived from `__file__` using `importlib.util`. The complete original API test class through EOF, including all three test methods and helpers, is byte-identical. The original runner, workflow, verifier implementation, products and other files are unchanged.

The catalog guard permits only this one complete, explicitly fixed old import prefix to become the explicitly fixed new prefix. It asserts the old prefix starts the historical file and occurs exactly once, then compares the entire candidate file to that exact reconstructed result. It continues building the protected manifest from the original historical bytes/hash/blob. The manifest, all 173 other protected files, all 120 historical files, all 33 catalog test method names and every catalog byte outside the reviewed guard insertion remain unchanged. No broad exclusion or mutable-file allowance was added.

## Actual independent results

| Execution | Result | Receipt |
|---|---|---|
| Baseline original `runner.discover` | 819 loaded IDs, including one API `_FailedTest`; original `ValueError`; zero test methods executed | `baseline-discovery.json` |
| Candidate original `runner.discover` and `partition` | 45 modules, 821 genuine unique IDs, zero loader errors; 817 current plus 4 frozen; discovery executed zero test methods | `candidate-discovery-three.json` |
| Original API verifier methods | 3 passed, no failure/error/skip; requested and actual IDs identical | `candidate-discovery-three.json` plus its raw stderr |
| Candidate native catalog preservation method | 1 passed, no failure/error/skip | `candidate-guard-positive.json` plus raw stderr |
| Negative control: change original `leaf_count` assertion from 18 to 19 | The same guard executed and rejected it with exactly one expected failure at the complete-file byte comparison, line 6495 | `candidate-guard-assertion-tamper.json` plus raw stderr |
| Restoration after negative control | Original file bytes and exact clean HEAD/tree restored | `guard-review.json` |
| Independent full byte/AST audit | Exact two-path diff, 3 method bodies unchanged, 174 original protected paths retained, 173 others and 120 historical files byte-identical | `static-review.json` |

The receipt phrase “unchanged catalog preservation method” describes invoking the native candidate method without harness modification; the reviewed candidate contains the precise new prefix handling described above.

## Scope and environment

The discovery probe calls the unchanged `runner.discover` and `partition` under file-CLI import-path conditions, with `PYTHONPATH` removed and without adding the repository root. It observes the native loader to retain diagnostics that `discover` would otherwise discard. It does not invoke full `runner.run`, preparation or all 821 discovered methods. The only API methods executed were the original three synthetic-log verifier tests; these provide no new PostgreSQL runtime proof. The guard was invoked through native `python3 -B -m unittest -v <exact-ID>` with the same established `scripts:scripts/tests` module search path used for catalog tests.

Actual Go: `/workspace/scratch/07d33ef3a5cc/toolchains/go/bin/go`, version `go1.25.7 linux/amd64`. Cache paths remained `/workspace/scratch/07d33ef3a5cc/go-build` and `/workspace/scratch/07d33ef3a5cc/go-mod`, with `GOTOOLCHAIN=local`, `GOPROXY=off`, `GOMAXPROCS=2`, and bytecode writes disabled. No full product or source-version suite was rerun.

The first external probe invocation supplied a relative report path, which failed after its intentional `chdir`; its raw `baseline-first-launch-output-path-error.*` files are retained. It yielded no valid discovery receipt and is not used as a source FAIL-to-PASS claim. The formal baseline and candidate use the same probe bytes and absolute report paths.

All raw receipts, stdout/stderr, the exact three external review scripts and this derived summary are included. The bundle manifest records the size and SHA-256 of every other included file. No root working-tree file or remote state was changed. The independent review clone was restored to its exact initial clean candidate after the negative control.
