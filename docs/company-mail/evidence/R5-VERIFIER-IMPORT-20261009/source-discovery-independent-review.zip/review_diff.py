"""Independent byte and AST audit of the two-file discovery repair."""
import ast
import hashlib
import json
from pathlib import Path
import subprocess

ROOT = Path('/workspace/scratch/02f0b8733500/tabmail-catalog15-review')
OUT = Path('/workspace/scratch/02f0b8733500/advance-import-review/static-review.json')
BASE = '4730c648b1c31c34588d585256ff17f417a86b3a'
CANDIDATE = 'a5b720d1db6d1932fced4877912cca86dd86117f'
SOURCE = '26a30e3c6963d553efdd8a8b33c095feb924c758'
API = 'scripts/tests/test_r5_api_key_issuance.py'
CAT = 'scripts/tests/test_r5_catalog_reconciliation.py'

def git(*args):
    return subprocess.check_output(['git', '-C', str(ROOT), *args])

def raw(commit, path):
    return git('show', commit + ':' + path)

def sha(data):
    return hashlib.sha256(data).hexdigest()

assert git('rev-parse', 'HEAD').decode().strip() == CANDIDATE
assert not git('status', '--porcelain', '--untracked-files=all')
changed = git('diff', '--name-only', BASE, CANDIDATE).decode().splitlines()
assert changed == [API, CAT], changed
before = raw(BASE, API)
after = raw(CANDIDATE, API)
old_prefix = (b'"""Synthetic verifier checks, not evidence of PostgreSQL execution."""\n'
              b'import json\nfrom pathlib import Path\nimport tempfile\nimport unittest\n\n'
              b'from scripts import run_r5_api_key_issuance as runner\n\n\n')
new_prefix = (b'"""Synthetic verifier checks, not evidence of PostgreSQL execution."""\n'
              b'import importlib.util\nimport json\nfrom pathlib import Path\nimport tempfile\nimport unittest\n\n'
              b'spec = importlib.util.spec_from_file_location(\n'
              b'    "r5_api_key_issuance_runner", Path(__file__).resolve().parents[1] / "run_r5_api_key_issuance.py"\n'
              b')\nrunner = importlib.util.module_from_spec(spec)\nspec.loader.exec_module(runner)\n\n\n')
assert before.startswith(old_prefix) and before.count(old_prefix) == 1
assert after == before.replace(old_prefix, new_prefix, 1)
marker = b'class APIKeyIssuanceVerifierTest(unittest.TestCase):'
assert before.count(marker) == after.count(marker) == 1
original_class = before[before.index(marker):]
assert after[after.index(marker):] == original_class
method_pins = {}
for node in ast.walk(ast.parse(before)):
    if isinstance(node, ast.FunctionDef) and node.name.startswith('test_'):
        matching = [n for n in ast.walk(ast.parse(after)) if isinstance(n, ast.FunctionDef) and n.name == node.name]
        assert len(matching) == 1
        candidate_node = matching[0]
        old_bytes = b''.join(before.splitlines(keepends=True)[node.lineno - 1:node.end_lineno])
        new_bytes = b''.join(after.splitlines(keepends=True)[candidate_node.lineno - 1:candidate_node.end_lineno])
        assert old_bytes == new_bytes
        assert ast.dump(node, include_attributes=False) == ast.dump(candidate_node, include_attributes=False)
        method_pins[node.name] = dict(source_sha256=sha(old_bytes), ast_sha256=sha(ast.dump(node, include_attributes=False).encode()))
assert len(method_pins) == 3

cat_before, cat_after = raw(BASE, CAT), raw(CANDIDATE, CAT)
start = b'            expected = raw\n            if path == \'scripts/tests/test_r5_api_key_issuance.py\':\n'
end = b'            self.assertEqual((ROOT / path).read_bytes(), expected)\n'
assert cat_after.count(start) == cat_after.count(end) == 1
added = cat_after[cat_after.index(start):cat_after.index(end) + len(end)]
assert cat_after.replace(added, b'            self.assertEqual((ROOT / path).read_bytes(), raw)\n', 1) == cat_before
guard = next(n for n in ast.walk(ast.parse(cat_after)) if isinstance(n, ast.FunctionDef)
             and n.name == 'test_revision15_preserves_public_history_collectors_and_original_rejections')
prefixes = {n.targets[0].id: ast.literal_eval(n.value) for n in ast.walk(guard)
            if isinstance(n, ast.Assign) and isinstance(n.targets[0], ast.Name)
            and n.targets[0].id in ('old_import', 'new_import')}
assert prefixes == dict(old_import=old_prefix, new_import=new_prefix)
before_methods = [n.name for n in ast.walk(ast.parse(cat_before)) if isinstance(n, ast.FunctionDef) and n.name.startswith('test_')]
after_methods = [n.name for n in ast.walk(ast.parse(cat_after)) if isinstance(n, ast.FunctionDef) and n.name.startswith('test_')]
assert before_methods == after_methods and len(after_methods) == 33

review_path = 'docs/company-mail/evidence/R5-CATALOG-REVISION15-20261009/reconciliation.json'
assert raw(BASE, review_path) == raw(CANDIDATE, review_path)
review = json.loads(raw(CANDIDATE, review_path))
protected = review['protected_source_manifest']
assert len(protected) == 174
for item in protected:
    historic = raw(SOURCE, item['path'])
    assert sha(historic) == item['sha256'] and len(historic) == item['bytes']
    assert git('rev-parse', SOURCE + ':' + item['path']).decode().strip() == item['blob']
    expected = historic.replace(old_prefix, new_prefix, 1) if item['path'] == API else historic
    assert raw(CANDIDATE, item['path']) == expected, item['path']
assert sum(item['path'] == API for item in protected) == 1
historical = review['historical_manifest']
assert len(historical) == 120
for item in historical:
    current = raw(CANDIDATE, item['path'])
    assert raw(BASE, item['path']) == current
    assert sha(current) == item['sha256'] and len(current) == item['bytes']
assert review['mutable_current_positive_test_paths'] == [CAT, 'scripts/tests/test_r5_transactions.py', 'scripts/tests/test_r5_compatibility.py']
assert review['runtime_verified'] is False and review['product_green'] is False and review['task_complete'] is False
assert not git('status', '--porcelain', '--untracked-files=all')
result = dict(baseline=BASE, baseline_tree=git('rev-parse', BASE+'^{tree}').decode().strip(),
              candidate=CANDIDATE, candidate_tree=git('rev-parse', CANDIDATE+'^{tree}').decode().strip(),
              changed_paths=changed, before_api_sha256=sha(before), after_api_sha256=sha(after),
              original_class_through_eof_sha256=sha(original_class), original_methods=method_pins,
              catalog_before_sha256=sha(cat_before), catalog_after_sha256=sha(cat_after),
              exact_single_prefix_substitution=True, guard_prefixes_match_candidate=True,
              protected_manifest_unchanged=True, original_protected_paths=174,
              other_protected_paths_byte_identical=173, historical_files_byte_identical=120,
              catalog_method_count=33, all_other_catalog_bytes_identical=True,
              products_runner_workflows_unchanged=True, new_todo_count=0,
              runtime_verified=False, product_green=False, task_complete=False)
OUT.write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result, indent=2))
