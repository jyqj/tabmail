"""Read original runner discovery under its CLI import path; run only three selected methods."""
from pathlib import Path
import argparse
import hashlib
import importlib.util
import json
import os
import subprocess
import sys
import traceback
import unittest


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--run-api-tests', action='store_true')
    args = parser.parse_args()
    root = args.root.resolve()

    def git(*arguments):
        return subprocess.check_output(['git', '-C', str(root), *arguments], text=True).strip()

    def identity():
        return dict(commit=git('rev-parse', 'HEAD'), tree=git('rev-parse', 'HEAD^{tree}'),
                    status=git('status', '--porcelain', '--untracked-files=all'))

    before = identity()
    if before['status']:
        raise ValueError('independent source must be clean')
    os.chdir(root)
    # A file entrypoint starts with scripts/, not its parent repository root.
    # Retain the interpreter's ordinary standard-library/site-package paths.
    sys.path[0] = str(root / 'scripts')
    path_before_discovery = list(sys.path)
    if '' in sys.path or str(root) in sys.path:
        raise ValueError('probe import path unexpectedly contains repository root')
    entry = root / 'scripts/run_r5_source_version_tests.py'
    spec = importlib.util.spec_from_file_location('independent_original_source_runner', entry)
    runner = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(runner)

    # Keep the native discovery semantics. Record only the suite and the
    # original loader's diagnostics; no discovered test method is executed.
    native_loader = unittest.TestLoader
    observed = []

    class ObservedLoader(native_loader):
        def discover(self, *arguments, **keywords):
            result = super().discover(*arguments, **keywords)
            observed.append((self, result))
            return result

    unittest.TestLoader = ObservedLoader
    discovery_error = None
    ids = []
    groups = None
    try:
        ids = runner.discover(root)
        current, frozen = runner.partition(ids)
        groups = dict(current=current, frozen=frozen)
    except Exception as error:
        discovery_error = dict(type=type(error).__name__, message=str(error),
                               traceback=traceback.format_exc())
    finally:
        unittest.TestLoader = native_loader
    if len(observed) != 1:
        raise ValueError('expected one original discover invocation')
    loader, suite = observed[0]
    loaded_ids = [test.id() for test in runner.flatten(suite)]
    selected = sorted(i for i in ids if i.startswith('test_r5_api_key_issuance.APIKeyIssuanceVerifierTest.'))
    test_result = None
    if args.run_api_tests:
        if discovery_error or len(selected) != 3:
            raise ValueError('all original three verifier methods must be discovered before execution')
        actual_ids = []

        class Result(unittest.TextTestResult):
            def startTest(self, test):
                actual_ids.append(test.id())
                super().startTest(test)

        selected_suite = unittest.TestLoader().loadTestsFromNames(selected)
        result = unittest.TextTestRunner(verbosity=2, resultclass=Result).run(selected_suite)
        test_result = dict(requested_ids=selected, actual_ids=actual_ids, tests_run=result.testsRun,
                           failures=[test.id() for test, _ in result.failures],
                           errors=[test.id() for test, _ in result.errors],
                           skipped=[test.id() for test, _ in result.skipped])
        if actual_ids != selected:
            raise ValueError('selected verifier method dispatch mismatch')
    after = identity()
    if before != after:
        raise ValueError('source identity changed during probe')
    report = dict(boundary='Original discover/partition under file-CLI sys.path; only selected three methods may execute; no source-version preparation or full suite execution.',
                  before=before, after=after, entrypoint=str(entry),
                  entrypoint_sha256=hashlib.sha256(entry.read_bytes()).hexdigest(),
                  cli_sys_path=path_before_discovery,
                  go_command=os.environ.get('R5_TEST_GO'),
                  go_version=subprocess.check_output([os.environ['R5_TEST_GO'], 'version'], text=True).strip(),
                  loaded_ids=loaded_ids, loaded_count=len(loaded_ids),
                  failed_import_ids=[i for i in loaded_ids if i.startswith('unittest.loader._FailedTest')],
                  loader_errors=loader.errors, discovery_error=discovery_error,
                  discovered_ids=ids, groups=groups, selected_verifier_ids=selected,
                  selected_execution=test_result,
                  runtime_verified=False, product_green=False, task_complete=False)
    args.output.write_text(json.dumps(report, indent=2) + '\n')
    good_tests = test_result is None or not (test_result['failures'] or test_result['errors'] or test_result['skipped'])
    return 0 if not discovery_error and good_tests else 1


if __name__ == '__main__':
    raise SystemExit(main())
