#!/usr/bin/env python3
import argparse, datetime, hashlib, json, os, subprocess, time
from pathlib import Path

p=argparse.ArgumentParser()
p.add_argument('--root',type=Path,required=True)
p.add_argument('--source',required=True)
p.add_argument('--out',type=Path,required=True)
p.add_argument('--facts',action='store_true')
p.add_argument('--tests',action='store_true')
a=p.parse_args()
root=a.root.resolve(); a.out.mkdir(parents=True,exist_ok=True)
protected=['scripts/check_r5_transactions.py','scripts/check_r5_compatibility.py','scripts/collect_api_calls.cjs','cmd/r5txinventory/main.go','internal/architecture/route_inventory_test.go']
hashes={name:hashlib.sha256((root/name).read_bytes()).hexdigest() for name in protected}
env=dict(os.environ,R5_TEST_GO='/workspace/scratch/458de7991ac3/toolchains/go/bin/go',R5_TEST_CACHE='/workspace/scratch/458de7991ac3/go-cache/build',R5_TEST_MODULECACHE='/workspace/scratch/458de7991ac3/go-cache/mod',GOPROXY='off',PYTHONPATH='scripts:scripts/tests',PYTHONDONTWRITEBYTECODE='1')
commands=[('original-transactions',['python3','-B','scripts/check_r5_transactions.py']),('original-compatibility',['python3','-B','scripts/check_r5_compatibility.py']),('original-api-calls',['node','scripts/collect_api_calls.cjs','--check'])]
if a.facts:
 commands += [('actual-ast',['python3','-B','-c','import json,check_r5_transactions as tx;print(json.dumps(tx.extract(),ensure_ascii=False,indent=2))']),('actual-clients',['node','scripts/collect_api_calls.cjs'])]
if a.tests:
 commands += [('python-catalog-controls',['python3','-B','-m','unittest','test_r5_transactions','test_r5_compatibility','test_r5_catalog_reconciliation','-v']),('node-client-controls',['node','--test','scripts/tests/api_calls.test.cjs'])]
rows=[]
for name,argv in commands:
 start=time.monotonic(); began=datetime.datetime.now(datetime.timezone.utc).isoformat()
 result=subprocess.run(argv,cwd=root,env=env,capture_output=True)
 row=dict(name=name,source_commit=a.source,source_tree=subprocess.check_output(['git','rev-parse',a.source+'^{tree}'],cwd=root,text=True).strip(),argv=argv,cwd=str(root),began=began,seconds=round(time.monotonic()-start,3),exit_code=result.returncode,protected_file_sha256=hashes,environment={key:env[key] for key in ['R5_TEST_GO','R5_TEST_CACHE','R5_TEST_MODULECACHE','GOPROXY','PYTHONPATH','PYTHONDONTWRITEBYTECODE']})
 for channel,raw in [('stdout',result.stdout),('stderr',result.stderr)]:
  (a.out/(name+'.'+channel)).write_bytes(raw)
  row[channel+'_sha256']=hashlib.sha256(raw).hexdigest(); row[channel+'_bytes']=len(raw)
 (a.out/(name+'-summary.json')).write_text(json.dumps(row,indent=2)+'\n')
 rows.append(row)
 print(json.dumps({'name':name,'exit_code':result.returncode,'seconds':row['seconds']}),flush=True)
assert hashes=={name:hashlib.sha256((root/name).read_bytes()).hexdigest() for name in protected}
(a.out/'commands.json').write_text(json.dumps(rows,indent=2)+'\n')
