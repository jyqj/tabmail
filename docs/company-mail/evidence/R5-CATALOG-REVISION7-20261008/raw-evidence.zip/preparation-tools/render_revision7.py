import ast, pprint, re

from pathlib import Path


def replace_method(source, name, transform):
    nodes = [node for node in ast.walk(ast.parse(source))
             if isinstance(node, ast.FunctionDef) and node.name == name]
    if len(nodes) != 1:
        raise ValueError("expected exactly one method: " + name)
    node = nodes[0]
    lines = source.splitlines(keepends=True)
    before = "".join(lines[node.lineno - 1:node.end_lineno])
    after = transform(before)
    if not after.endswith("\n"):
        after += "\n"
    return "".join(lines[:node.lineno - 1]) + after + "".join(lines[node.end_lineno:])


def once(source, before, after):
    if source.count(before) != 1:
        raise ValueError("expected one source fragment: " + before[:100])
    return source.replace(before, after, 1)


def render_tests(original, source_commit, source_tree, review_dir, rev6, rev6_source, rev6_tree, pins, review, overrides):
    source=once(original,'"""Frozen revision-1/2/3/4/5 reviews and current revision-6 facts; original validators."""','"""Frozen revision-1/2/3/4/5/6 reviews and current revision-7 facts; original validators."""')
    source=once(source,"CURRENT_EVIDENCE = ROOT / 'docs/company-mail/evidence/R5-CATALOG-REVISION6-20261008'","REVISION6_EVIDENCE = ROOT / 'docs/company-mail/evidence/R5-CATALOG-REVISION6-20261008'\nCURRENT_EVIDENCE = ROOT / "+repr(review_dir))
    source=once(source,"SOURCE_COMMIT = "+repr(rev6_source)+"\nSOURCE_TREE = "+repr(rev6_tree)+"\n","SOURCE_COMMIT = "+repr(source_commit)+"\nSOURCE_TREE = "+repr(source_tree)+"\nREVISION6_COMMIT = "+repr(rev6)+"\nREVISION6_SOURCE_COMMIT = "+repr(rev6_source)+"\nREVISION6_SOURCE_TREE = "+repr(rev6_tree)+"\n")
    expected=dict(caller_ids=sorted(row['id'] for row in review['transaction_callers']),caller_locations=[dict(id=d['id'],**row) for d in review['transaction_callers'] for row in d['locations']],callers_added=[(d['id'],r['caller_id'],r['expression']) for d in review['transaction_callers'] for r in d['added']],callers_removed=[(d['id'],r['caller_id'],r['expression']) for d in review['transaction_callers'] for r in d['removed']],client_previous_indices=review['client_previous_indices'],client_branch_count=review['client_branch_count'],clients_added=review['clients_added'],client_changed_indices=[(r['before_index'],r['after_index']) for r in review['client_changes']],client_overrides=overrides,changed_routes=sorted(r['route'] for r in review['compatibility_routes']),closure_paths=review['closure_changes'],source_paths=[r['path'] for r in review['source_changes']])
    constants='\n\nREVISION6_SNAPSHOTS = '+pprint.pformat(pins,sort_dicts=False,width=112)+'\n\nREVISION7_EXPECTED = '+pprint.pformat(expected,sort_dicts=False,width=112)
    source=once(source,'\n\ndef git(*args):',constants+'\n\n\ndef git(*args):')
    node=next(n for n in ast.walk(ast.parse(source)) if isinstance(n,ast.FunctionDef) and n.name=='revision5_snapshot')
    snapshot='\n'.join(source.splitlines()[node.lineno-1:node.end_lineno]).replace('revision5_snapshot','revision6_snapshot').replace('REVISION5_','REVISION6_').replace('revision-5','revision-6')
    source=once(source,'\n\nclass ReviewedCatalogReconciliationTests','\n\n'+snapshot+'\n\n\nclass ReviewedCatalogReconciliationTests')
    source=once(source,'        cls.ast = tx.extract()\n',"        cls.revision6 = {name: revision6_snapshot(name) for name in REVISION6_SNAPSHOTS}\n        cls.rev6_tx = cls.revision6['transaction']\n        cls.rev6_compat = cls.revision6['compatibility']\n        cls.ast = tx.extract()\n")

    def current_rejections(method):
        method=once(method,'        # The old rows fail before the closure hash check because\n',"        with self.assertRaisesRegex(ValueError, '^caller drift:'):\n            tx.validate(self.rev6_tx, self.ast, self.migrations)\n        # The old rows fail before the closure hash check because\n")
        lines=method.splitlines(keepends=True)
        index=next(i for i,line in enumerate(lines) if 'gate.validate(self.rev5_compat, self.routes, self.clients)' in line)
        old_block=''.join(lines[index-1:index+1])
        new_block="        with self.assertRaisesRegex(ValueError, "+repr(review['old_compatibility_rejections']['revision5'])+"):\n            gate.validate(self.rev5_compat, self.routes, self.clients)\n        with self.assertRaisesRegex(ValueError, "+repr(review['old_compatibility_rejections']['revision6'])+"):\n            gate.validate(self.rev6_compat, self.routes, self.clients)\n"
        method=once(method,old_block,new_block)
        return method.replace('pin = REVISION5_SNAPSHOTS[name]','pin = REVISION6_SNAPSHOTS[name]').replace("self.assertEqual(revision['revision'], 6)","self.assertEqual(revision['revision'], 7)").replace("revision['previous_snapshot_commit'], REVISION5_COMMIT","revision['previous_snapshot_commit'], REVISION6_COMMIT")
    source=replace_method(source,'test_old_pins_reject_and_current_revision_passes_same_actual_facts',current_rejections)

    def historicalize(method):
        method=once(method,"review = json.loads((CURRENT_EVIDENCE / 'reconciliation.json').read_text())","review = json.loads(git('show', REVISION6_COMMIT + ':' + str((REVISION6_EVIDENCE / 'reconciliation.json').relative_to(ROOT))))")
        method=re.sub(r'\bSOURCE_COMMIT\b','REVISION6_SOURCE_COMMIT',method)
        method=re.sub(r'\bSOURCE_TREE\b','REVISION6_SOURCE_TREE',method)
        method=method.replace('self.tx','self.rev6_tx').replace('self.compat','self.rev6_compat').replace('self.clients',"self.revision6['clients']")
        method=method.replace("documented = json.loads((ROOT / REVISION5_SNAPSHOTS['client_routes']['path']).read_text())","documented = self.revision6['client_routes']")
        method=method.replace('self.assertEqual((ROOT / path).read_bytes(), raw)',"self.assertEqual(git('show', REVISION6_SOURCE_COMMIT + ':' + path), raw)")
        method=method.replace("hashlib.sha256((ROOT / value['path']).read_bytes()).hexdigest()","hashlib.sha256(git('show', REVISION6_COMMIT + ':' + value['path'])).hexdigest()")
        method=method.replace('methods((ROOT / test_path).read_bytes())',"methods(git('show', REVISION6_COMMIT + ':' + test_path))")
        return method
    for name in ('test_revision6_preserves_reviews_and_records_exact_caller_changes','test_revision6_client_facts_source_bytes_and_historical_guards_are_bound'):
        source=replace_method(source,name,historicalize)

    old_methods=(Path(__file__).parent/'revision6-methods.txt').read_text()
    methods=old_methods.replace('revision6','revision7').replace('REVISION6_','REVISION7_').replace('revision5','revision6').replace('REVISION5_','REVISION6_').replace('rev5_tx','rev6_tx').replace('rev5_compat','rev6_compat')
    # The predecessor of historical revision 6 remains immutable revision 5.
    methods=methods.replace("self.assertEqual(revision['revision'], 5)","self.assertEqual(revision['revision'], 6)").replace("revision['previous_snapshot_commit'], REVISION4_COMMIT","revision['previous_snapshot_commit'], REVISION5_COMMIT").replace('REVISION4_SNAPSHOTS[name][pin_field]','REVISION5_SNAPSHOTS[name][pin_field]')
    methods=methods.replace("self.assertEqual(review['inventory_revision'], 6)","self.assertEqual(review['inventory_revision'], 7)")
    methods=methods.replace("        self.assertEqual(review['source_commit'], SOURCE_COMMIT)\n","        self.assertEqual(review['source_commit'], SOURCE_COMMIT)\n        self.assertEqual(review['revision6_source_commit'], REVISION6_SOURCE_COMMIT)\n        self.assertEqual(review['revision6_source_tree'], REVISION6_SOURCE_TREE)\n",1)
    marker="        mutable = {'routes', 'source_closure', 'inventory_revision', 'acquisition'}"
    client_start=methods.index('    def test_revision7_client_facts_source_bytes_and_historical_guards_are_bound')
    tail=methods[methods.index(marker,client_start):]
    # Source facts are compared with the revision-6 product, while catalog
    # snapshots are fetched from the later public revision-6 catalog commit.
    tail=tail.replace("git('ls-tree', REVISION6_COMMIT, '--', path)","git('ls-tree', REVISION6_SOURCE_COMMIT, '--', path)")
    tail=tail.replace("git('show', REVISION6_COMMIT + ':' + path)","git('show', REVISION6_SOURCE_COMMIT + ':' + path)")
    tail=tail.replace("git('rev-parse', REVISION6_COMMIT + ':' + path)","git('rev-parse', REVISION6_SOURCE_COMMIT + ':' + path)")
    # Only the source provenance loop uses product hashes; validator/historical
    # guards below still fetch the fixed published catalog revision.
    guard_at=tail.index('        previous_review =')
    tail=tail[:guard_at]+tail[guard_at:].replace("git('show', REVISION6_SOURCE_COMMIT + ':' + path)","git('show', REVISION6_COMMIT + ':' + path)")
    tail=tail.replace('for directory in (EVIDENCE, REVISION3_EVIDENCE, REVISION4_EVIDENCE, REVISION6_EVIDENCE):','for directory in (EVIDENCE, REVISION3_EVIDENCE, REVISION4_EVIDENCE, REVISION5_EVIDENCE, REVISION6_EVIDENCE):')
    tail=tail.replace('self.assertEqual(historical_files, 33)','self.assertEqual(historical_files, '+str(review['historical_files'])+')')
    tail=tail.replace('self.assertEqual(len(before), 13)','self.assertEqual(len(before), 15)').replace('self.assertEqual(len(after), 15)','self.assertEqual(len(after), 17)')
    tail=tail.replace("        for row in review['source_changes']:\n            path = row['path']\n","        for row in review['source_changes']:\n            self.assertEqual(row['before_commit'], REVISION6_SOURCE_COMMIT)\n            self.assertEqual(row['after_commit'], SOURCE_COMMIT)\n            path = row['path']\n")
    return (source.rstrip()+'\n\n'+methods[:client_start]+CLIENT_METHOD+tail).rstrip()+'\n'


CLIENT_METHOD=r'''
    def test_revision7_client_facts_source_bytes_and_historical_guards_are_bound(self):
        review = json.loads((CURRENT_EVIDENCE / 'reconciliation.json').read_text())
        documented = json.loads((ROOT / REVISION6_SNAPSHOTS['client_routes']['path']).read_text())
        self.assertEqual(len(self.revision6['clients']), 133)
        self.assertEqual(len(self.clients), REVISION7_EXPECTED['client_branch_count'])
        self.assertEqual(len(documented), REVISION7_EXPECTED['client_branch_count'])
        self.assertEqual(sum(row['forwarding'] for row in self.clients), 7)
        indices = REVISION7_EXPECTED['client_previous_indices']
        self.assertEqual(review['client_previous_indices'], indices)
        self.assertEqual(sorted(i for i in indices if i is not None), list(range(133)))
        self.assertEqual([i for i, previous in enumerate(indices) if previous is None], [17])
        self.assertEqual(review['clients_added'], REVISION7_EXPECTED['clients_added'])
        self.assertEqual(review['clients_removed'], [])
        additions = {row['after_index']: row for row in review['clients_added']}
        self.assertEqual(len(additions), 1)
        changes, reordered = [], []
        for index, previous in enumerate(indices):
            after = self.clients[index]
            self.assertEqual({k: v for k, v in documented[index].items() if k != 'routes'}, after)
            if previous is None:
                addition = additions[index]
                self.assertEqual(after, addition['row'])
                reference = addition['route_reference_index']
                before = self.revision6['clients'][reference]
                stable = lambda row: {k: v for k, v in row.items() if k not in {'line', 'source', 'owner', 'expression'}}
                self.assertEqual(stable(before), stable(after))
                self.assertEqual(documented[index]['routes'], self.revision6['client_routes'][reference]['routes'])
                continue
            before = self.revision6['clients'][previous]
            expected = {k: v for k, v in before.items() if k != 'line'}
            expected.update(REVISION7_EXPECTED['client_overrides'].get(index, {}))
            self.assertEqual(expected, {k: v for k, v in after.items() if k != 'line'})
            self.assertEqual(self.revision6['client_routes'][previous]['routes'], documented[index]['routes'])
            if before != after:
                changes.append(dict(before_index=previous, after_index=index, path=after['path'], methods=after['methods'],
                    changes={k: dict(before=before[k], after=after[k]) for k in before if before[k] != after[k]}))
            if previous != index:
                reordered.append(dict(before_index=previous, after_index=index))
        self.assertEqual([(row['before_index'], row['after_index']) for row in changes], REVISION7_EXPECTED['client_changed_indices'])
        self.assertEqual(review['client_changes'], changes)
        self.assertEqual(review['client_reorder'], reordered)
'''

