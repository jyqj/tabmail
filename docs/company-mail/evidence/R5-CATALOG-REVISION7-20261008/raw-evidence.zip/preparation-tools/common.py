from __future__ import annotations
import ast, hashlib, json, subprocess
from pathlib import Path


def require(value, message):
    if not value:
        raise ValueError(message)


def canonical(value):
    return (json.dumps(value, ensure_ascii=False, indent=2) + "\n").encode()


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def git(root, *args):
    return subprocess.check_output(["git", "-C", str(root), *args], stderr=subprocess.PIPE)


def fixed(root, ref, path):
    return git(root, "show", ref + ":" + path)


def blob(root, ref, path):
    observed = git(root, "ls-tree", ref, "--", path)
    return git(root, "rev-parse", ref + ":" + path).decode().strip() if observed else None


def write(root, relative, raw):
    path = root / relative
    require(path.resolve().is_relative_to(root.resolve()), "output escapes staging checkout")
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(raw)


def test_methods(raw):
    return {node.name: ast.dump(node, include_attributes=False)
            for node in ast.walk(ast.parse(raw))
            if isinstance(node, ast.FunctionDef) and node.name.startswith("test_")}


def caller_delta(before, after, reviewed_moves=()):
    """One-to-one exact row matching first, then exact identity/line movement."""
    def identity(row):
        return json.dumps({key: value for key, value in row.items() if key != "line"}, sort_keys=True)
    key = lambda row: (row["caller_id"], row["file"], row["expression"], row["line"])
    moves = {(row["caller_id"], row["source"], row["expression"], row["before_line"]): row["after_line"]
             for row in reviewed_moves}
    require(len(moves) == len(reviewed_moves), "duplicate reviewed caller movement")
    used = set()
    remaining = list(enumerate(after))
    pairs, old_only = [], []
    for old in before:
        if key(old) in moves:
            candidates = [(index, row) for index, row in remaining
                          if identity(old) == identity(row) and row["line"] == moves[key(old)]]
            require(len(candidates) == 1, "reviewed caller movement does not identify one actual row")
            exact = candidates[0]
            used.add(key(old))
        else:
            exact = next(((index, row) for index, row in remaining if old == row), None)
        if exact is None:
            candidates = [(index, row) for index, row in remaining if identity(old) == identity(row)]
            require(len(candidates) <= 1, "ambiguous caller movement requires a specific manual mapping")
            exact = candidates[0] if candidates else None
        if exact is None:
            old_only.append(old)
        else:
            remaining.remove(exact)
            pairs.append((old, exact[1]))
    require(used == set(moves), "reviewed caller movement was not consumed")
    return {
        "before_count": len(before), "after_count": len(after),
        "before_sha256": sha(canonical(before)), "after_sha256": sha(canonical(after)),
        "locations": [{"caller_id": old["caller_id"], "source": old["file"],
                       "expression": old["expression"], "before_line": old["line"], "after_line": now["line"]}
                      for old, now in pairs if old["line"] != now["line"]],
        "removed": old_only, "added": [row for _, row in remaining],
    }

