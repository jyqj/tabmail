#!/usr/bin/env python3
"""Reconcile reviewed final source against immutable revision-6 catalogs."""
import ast, copy, importlib, json, os, re, subprocess, sys
from pathlib import Path
from common import require, canonical, sha, git, fixed, blob, write, test_methods, caller_delta
from render_revision7 import render_tests

ROOT=Path('/workspace/scratch/929b325e44d9/tabmail-catalog')
OUT=Path('/workspace/scratch/929b325e44d9/evidence/catalog-revision7')
SOURCE='9b12c93cb03285298267e27893f74aebe742a8a2'
REV6='c3e1419e6245baf0190291ea868787cb2b0177ca'
REV6_SOURCE='f413a9138d305cf154ed2cecaddcf9b9a2397666'
REVIEW6='docs/company-mail/evidence/R5-CATALOG-REVISION6-20261008'
REVIEW7='docs/company-mail/evidence/R5-CATALOG-REVISION7-20261008'
TEST='scripts/tests/test_r5_catalog_reconciliation.py'
PINS={
 'transaction':{'path':'docs/company-mail/evidence/R5-TRANSACTION-COVERAGE.json','blob':'5b7b8a28f5b3817c0cd4049be4c9d350d7b4f1b1','sha256':'e820435ec2357f2fa0d0509e4e0759124a85054c0f4fc35df887f683a3c4e715'},
 'compatibility':{'path':'docs/company-mail/evidence/R5-COMPATIBILITY-GATES.json','blob':'4e134e4fbc8f35fff6be9d1da51511e2869fe971','sha256':'457fcd6c63ce7f0b80a3d38aa2d7153e243eaa06569898ff47932bc02ca0983c'},
 'clients':{'path':'docs/company-mail/evidence/R5-COMPATIBILITY-CURRENT-20261003/clients.json','blob':'570196772dae1d41af74e33c7ff7aa50e9316650','sha256':'c673d9b6d049283bcba582a5465448c94234d1388a4a55b43035fc8fcdebb679'},
 'client_routes':{'path':'docs/company-mail/evidence/R5-CLIENT-CALLS.json','blob':'aff3a16242d3204c387684cd7ca641342205c55e','sha256':'56bbc1329b0433e215413542409c6486d08af406d45d0a1fc6a6dc73dc6c6d21'},
}
HISTORY=['docs/company-mail/evidence/R5-CATALOG-RECONCILIATION-20261004','docs/company-mail/evidence/R5-CATALOG-RECONCILIATION-20261007','docs/company-mail/evidence/R5-CATALOG-REVISION4-20261007','docs/company-mail/evidence/R5-CATALOG-REVISION5-20261007',REVIEW6]

def main():
 old={}
 for name,pin in PINS.items():
  raw=fixed(ROOT,REV6,pin['path']);require(blob(ROOT,REV6,pin['path'])==pin['blob'] and sha(raw)==pin['sha256'],'revision6 snapshot drift: '+name);old[name]=json.loads(raw)
 previous=json.loads(fixed(ROOT,REV6,REVIEW6+'/reconciliation.json'))
 require(previous['source_commit']==REV6_SOURCE,'revision6 source drift')
 require(previous['source_tree']==git(ROOT,'rev-parse',REV6_SOURCE+'^{tree}').decode().strip(),'revision6 source tree drift')
 for name in ('transaction','compatibility'):require(old[name]['inventory_revision']['revision']==6 and old[name]['inventory_revision']['source_commit']==REV6_SOURCE,'revision6 metadata drift')
 for path,digest in previous['unchanged_validators_and_collectors'].items():
  require(sha(fixed(ROOT,REV6,path))==digest and (ROOT/path).read_bytes()==fixed(ROOT,REV6,path),'original tool changed: '+path)
 history=[]
 for directory in HISTORY:
  names=git(ROOT,'ls-tree','-r','--name-only',REV6,'--',directory).decode().splitlines()
  require(names and {str(p.relative_to(ROOT)) for p in (ROOT/directory).rglob('*') if p.is_file()}==set(names),'historical file set drift: '+directory)
  for path in names:require((ROOT/path).read_bytes()==fixed(ROOT,REV6,path),'historical file bytes drift: '+path)
  history.extend(names)
 tree=git(ROOT,'rev-parse',SOURCE+'^{tree}').decode().strip()
 require(tree=='87c87a0db72ac444050b43fbe67d906f45c4a2ac','frozen public product tree drift')
 sys.path.insert(0,str(ROOT/'scripts'))
 tx=importlib.import_module('check_r5_transactions');gate=importlib.import_module('check_r5_compatibility')
 require(tx.ROOT==ROOT and gate.ROOT==ROOT,'wrong producer root')
 actual_ast,migrations=tx.extract(),tx.migration_inventory();routes,clients=gate.collect()
 for name,value in [('ast',actual_ast),('migrations',migrations),('routes',routes),('clients',clients)]:write(OUT,'facts/'+name+'.json',canonical(value))
 current_tx=copy.deepcopy(old['transaction']);pg={f['id']:f for f in actual_ast['functions'] if f['file'].startswith(tx.PG)}
 require(set(pg)=={e['id'] for e in current_tx['entries']},'PostgreSQL function set changed')
 caller_changes=[]
 for entry in current_tx['entries']:
  require(entry['syntax']==pg[entry['id']],'PostgreSQL body/syntax changed: '+entry['id'])
  after=[{'caller_id':f['id'],'file':f['file'],'function':f['name'],'line':c['line'],'expression':c['expr'],'status':'name-match-candidate-not-dispatch-proof'} for f in actual_ast['functions'] for c in f['calls'] if c['name']==entry['syntax']['name']]
  if entry['callers']!=after:
   caller_changes.append(dict(id=entry['id'],**caller_delta(entry['callers'],after)));entry['callers']=after
 tx_result=tx.validate(current_tx,actual_ast,migrations)
 require(len(old['clients'])==133 and len(clients)==134,'reviewed client counts changed')
 # PR87 adds one explicit GET snapshot branch after the existing grants GET.
 indices=list(range(17))+[None]+list(range(17,133))
 added_row={'source':'web/components/company/grants.tsx','line':49,'branch':0,'callee':'company','owner':'snapshot','expression':'`${workPath(mailbox.mailbox.id)}/grants`','path':'/api/v1/company/mailboxes/{id}/grants','methods':['GET'],'forwarding':False}
 require(clients[17]==added_row,'unreviewed added client identity')
 require(sorted(i for i in indices if i is not None)==list(range(133)),'previous clients not covered once')
 added=[dict(after_index=17,row=added_row,route_reference_index=16,reason='An explicit current grants GET recovers from stale revision conflicts; it does not replay the PUT mutation.')]
 documented=[];client_changes=[];reordered=[];overrides={}
 stable=lambda row:{k:v for k,v in row.items() if k not in {'line','source','owner','expression'}}
 for index,previous_index in enumerate(indices):
  current=clients[index]
  if previous_index is None:
   reference=old['clients'][16]
   require(stable(reference)==stable(current),'added branch changes route identity')
   documented.append(dict(current,routes=old['client_routes'][16]['routes']));continue
  before=old['clients'][previous_index]
  require(stable(before)==stable(current),'method/path/callee/branch/forwarder identity changed')
  documented.append(dict(current,routes=old['client_routes'][previous_index]['routes']))
  if before!=current:
   delta={k:{'before':before[k],'after':current[k]} for k in before if before[k]!=current[k]}
   require(set(delta).issubset({'line','source','owner','expression'}),'unreviewed client change')
   client_changes.append(dict(before_index=previous_index,after_index=index,path=current['path'],methods=current['methods'],changes=delta))
   override={k:v['after'] for k,v in delta.items() if k!='line'}
   if override:overrides[index]=override
  if previous_index!=index:reordered.append(dict(before_index=previous_index,after_index=index))
 require(sum(r['forwarding'] for r in clients)==7,'forwarder count changed')
 write(ROOT,PINS['clients']['path'],canonical(clients));write(ROOT,PINS['client_routes']['path'],canonical(documented))
 facts=gate.source_facts(routes,clients);current_compat=copy.deepcopy(old['compatibility']);route_changes=[]
 require(len(facts)==len(current_compat['routes'])==132,'route set changed')
 for before,fact in zip(current_compat['routes'],facts):
  require(all(before[k]==v for k,v in fact.items() if k!='clients'),'contract/handler/middleware/release drift: '+fact['route'])
  if before['clients']!=fact['clients']:before['clients']=fact['clients'];route_changes.append(dict(route=before['route'],changed_fields=['clients']))
 current_compat['source_closure']=gate.closure(facts,clients)
 require(set(current_compat['source_closure'])==set(old['compatibility']['source_closure']),'declared closure path set changed')
 closure_changes=sorted(p for p,d in current_compat['source_closure'].items() if d!=old['compatibility']['source_closure'][p])
 compat_result=gate.validate(current_compat,routes,clients)
 rejection={}
 for name,ref in [('revision5','697b12d70b84658f5429e9a88ad2efde94e2e443'),('revision6',REV6)]:
  try:gate.validate(json.loads(fixed(ROOT,ref,PINS['compatibility']['path'])),routes,clients)
  except ValueError as e:rejection[name]='^'+re.escape(str(e))+'$'
  else:raise ValueError(name+' unexpectedly accepts current source')
 try:tx.validate(old['transaction'],actual_ast,migrations)
 except ValueError as e:require(str(e).startswith('caller drift:'),'unexpected old transaction error')
 else:raise ValueError('revision6 transaction unexpectedly accepts current source')
 for name,value in [('transaction',current_tx),('compatibility',current_compat)]:
  pin=PINS[name];value['inventory_revision']=dict(revision=7,source_commit=SOURCE,previous_snapshot=pin['path'],previous_snapshot_commit=REV6,previous_snapshot_blob=pin['blob'],previous_sha256=pin['sha256'],qualification=old[name]['inventory_revision']['qualification'],review=REVIEW7+'/README.md')
 current_tx['baseline_commit']=current_tx['last_review_base_commit']=SOURCE
 current_tx['current_review_boundary']='Revision 7 static AST/file/migration inventory only. Exact external caller changes are reviewed against revision-6 product f413, with immutable published revision-6 catalogs at c3e1419. PostgreSQL syntax, file hashes, classifications, migrations and manual reviews remain unchanged. Historical runtime links are preserved, not recertified. No implementation TODO, PostgreSQL/runtime or parent-task acceptance.'
 current_compat['acquisition']['base_commit']=SOURCE
 catalogs=dict(transaction=current_tx,compatibility=current_compat,clients=clients,client_routes=documented)
 for name,value in catalogs.items():write(ROOT,PINS[name]['path'],canonical(value))
 paths=set(closure_changes)-{PINS['clients']['path']}
 for delta in caller_changes:
  paths.update(r['source'] for r in delta['locations']);paths.update(r['file'] for k in ('added','removed') for r in delta[k])
 for delta in client_changes:paths.add(old['clients'][delta['before_index']]['source']);paths.add(clients[delta['after_index']]['source'])
 paths.update(row['row']['source'] for row in added)
 source_changes=[]
 for path in sorted(paths):
  before_blob=blob(ROOT,REV6_SOURCE,path);after_blob=blob(ROOT,SOURCE,path)
  before=fixed(ROOT,REV6_SOURCE,path) if before_blob else None;after=fixed(ROOT,SOURCE,path) if after_blob else None
  require(after is not None and (ROOT/path).read_bytes()==after,'current source provenance mismatch: '+path)
  require(before!=after,'unexplained unchanged source in delta: '+path)
  source_changes.append(dict(path=path,before_commit=REV6_SOURCE,before_blob=before_blob,before_sha256=sha(before) if before else None,after_commit=SOURCE,after_blob=after_blob,after_sha256=sha(after)))
 review=dict(schema_version=1,inventory_revision=7,source_commit=SOURCE,source_tree=tree,revision6_source_commit=REV6_SOURCE,revision6_source_tree=previous['source_tree'],revision6_snapshots={name:dict(commit=REV6,**pin) for name,pin in PINS.items()},boundary=previous['boundary'],transaction=tx_result,compatibility=compat_result,transaction_callers=caller_changes,client_previous_indices=indices,clients_added=added,clients_removed=[],client_changes=client_changes,client_reorder=reordered,client_branch_count=len(clients),compatibility_routes=route_changes,closure_changes=closure_changes,source_changes=source_changes,generated_catalogs={name:dict(path=pin['path'],sha256=sha((ROOT/pin['path']).read_bytes())) for name,pin in PINS.items()},unchanged_validators_and_collectors=previous['unchanged_validators_and_collectors'],historical_files=len(history),historical_paths=history,implementation_todos_completed=0,runtime_tests_executed=False,old_compatibility_rejections=rejection,local_source_collection=dict(go=subprocess.check_output([os.environ['R5_TEST_GO'],'version']).decode().strip(),node=subprocess.check_output(['node','--version']).decode().strip(),typescript=json.loads((ROOT/'web/node_modules/typescript/package.json').read_text())['version'],boundary=previous['local_source_collection']['boundary']))
 old_tests=fixed(ROOT,REV6,TEST).decode()
 new_tests=render_tests(old_tests,SOURCE,tree,REVIEW7,REV6,REV6_SOURCE,previous['source_tree'],PINS,review,overrides)
 before_methods=test_methods(old_tests);after_methods=test_methods(new_tests)
 require(set(before_methods).issubset(after_methods) and len(before_methods)==15 and len(after_methods)==17,'reconciliation method identities changed')
 mutations={name for name in before_methods if name.startswith('test_unapproved_')};require(len(mutations)==5 and all(before_methods[name]==after_methods[name] for name in mutations),'original negative assertion AST changed')
 compile(new_tests,TEST,'exec');write(ROOT,TEST,new_tests.encode())
 positive='scripts/tests/test_r5_compatibility.py';old_positive=fixed(ROOT,REV6,positive)
 needle=b"self.assertEqual(result['client_branches'],133)";require(old_positive.count(needle)==1,'current branch-count assertion not unique')
 new_positive=old_positive.replace(needle,b"self.assertEqual(result['client_branches'],134)");write(ROOT,positive,new_positive)
 review['current_assertion_changes']=[dict(path=positive,assertion='test_current_source_map_is_not_product_or_dependency_completion/client_branches',before=133,after=134,before_sha256=sha(old_positive),after_sha256=sha(new_positive))]
 write(ROOT,REVIEW7+'/reconciliation.json',canonical(review))
 write(OUT,'preparation.json',canonical(dict(source_commit=SOURCE,source_tree=tree,caller_entries=len(caller_changes),caller_locations=sum(len(x['locations']) for x in caller_changes),callers_added=sum(len(x['added']) for x in caller_changes),callers_removed=sum(len(x['removed']) for x in caller_changes),client_changes=len(client_changes),client_additions=len(added),client_reorder=len(reordered),closure_changes=closure_changes,source_changes=len(source_changes),historical_files=len(history),reconciliation_methods=17,original_tools_unchanged=5,mutation_methods_unchanged=5,implementation_todos_completed=0)))
 print((OUT/'preparation.json').read_text())

if __name__=='__main__':main()
