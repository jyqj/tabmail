import sys,json,pathlib,hashlib,importlib.util
P=pathlib.Path;src=P(sys.argv[1]);capturepath=P(sys.argv[2]);out=P(sys.argv[3]);sys.path.insert(0,str(src/'scripts'));spec=importlib.util.spec_from_file_location('readonly_http',src/'scripts/check_http_contract.py');v=importlib.util.module_from_spec(spec);sys.modules[spec.name]=v;spec.loader.exec_module(v)
specbytes=(src/'internal/api/openapi.yaml').read_bytes();document,parseerrors=v.contracts.parse_openapi_text(specbytes.decode());inventory=v.strict_json((src/'docs/company-mail/evidence/R5-API-MATRIX.json').read_text());raw=capturepath.read_bytes();capture=v.strict_json(raw.decode());errors=list(parseerrors);errors+=v.contracts.check_company_operations(document,inventory);rows,ie=v.company_inventory(inventory);errors+=ie
if capture.get('producer')!='TestCompanyHTTPContract' or type(capture.get('version')) is not int or capture['version']!=1 or not isinstance(capture.get('cases'),list):raise ValueError('original capture identity unknown')
validator=v.HTTPContractValidator(document);ids=set();success=set();expected_ops={(r['method'],r['path']) for r in rows};cases=[]
for case in capture['cases']:
 ce=validator.validate_response(case);errors+=ce;cid=case.get('id');observed=(case.get('method'),case.get('route'),case.get('status'))
 if cid in ids:errors.append('[capture] duplicate caseid')
 ids.add(cid);required_case=v.REQUIRED_CASES.get(cid)
 if required_case is not None and observed!=required_case:errors.append('[capture] original operation/status mismatched '+cid)
 if not ce and observed[:2] not in expected_ops:errors.append('[inventory] case operation absent '+cid)
 if not ce and type(case.get('status')) is int and 200<=case['status']<300:success.add((case['method'],case['route'],str(case['status'])))
 cases.append({'id':cid,'method':case.get('method'),'route':case.get('route'),'status':case.get('status'),'passed':not ce,'errors':ce})
for cid in sorted(set(v.REQUIRED_CASES)-ids):errors.append('[missing-requiredcase] '+cid)
required=set();excluded=[]
for r in rows:
 if r['handler'] in v.LIVE_DNS_EXCLUSIONS:excluded.append({'method':r['method'],'path':r['path'],'reason':v.LIVE_DNS_EXCLUSIONS[r['handler']]});continue
 bindings=[v.contracts.COMPANY_RESPONSES[r['handler']]] if r['handler'] in v.contracts.COMPANY_RESPONSES else [('200','','')]
 if r['handler'] in v.contracts.COMPANY_ALTERNATE_RESPONSES:bindings.append(v.contracts.COMPANY_ALTERNATE_RESPONSES[r['handler']])
 for status,_,_ in bindings:required.add((r['method'],r['path'],status))
for key in sorted(required-success):errors.append('[missing-success] '+str(key))
report={'status':'readonly_oldcapture_newdoc_pass' if not errors else 'readonly_oldcapture_newdoc_fail','errors':errors,'old_actual_capture_sha256':hashlib.sha256(raw).hexdigest(),'old_capture_embedded_spec_sha256_unchanged':capture['spec_sha256'],'new_document_sha256':hashlib.sha256(specbytes).hexdigest(),'original_go_source_sha':'33307f7bfd87a24b758f5020669c9b313337e3d3','response_count':len(capture['cases']),'per_case_results':cases,'required_success_variants':len(required),'observed_success_variants':len(success),'successful_operations':len({x[:2] for x in success}),'excluded_liveDNS':excluded,'freshformal_CLI0_or_newGoPG_run':False,'original_validate_capture_stale_spec_guard_unmodified':True,'old_spec_is_not_claimed_equal_new_spec':capture['spec_sha256']!=hashlib.sha256(specbytes).hexdigest(),'original_CLI1_and_result_unchanged':True};out.write_text(json.dumps(report,sort_keys=True,indent=2)+'\n');print(json.dumps({k:val for k,val in report.items() if k!='per_case_results'},sort_keys=True));raise SystemExit(0 if not errors else 1)
