"""Dormant C18 pure qualification controller. No tests run without explicit marker.
External process exception whitelist: only /bin/ps exact owned PID/group inspection.
RSS100ms/250ms freshness is sampling, not hard quota; missed intersample peaks unknown.
"""
import os,sys,time,json,hashlib,tempfile,subprocess,signal,shutil
from pathlib import Path
from c18_rss_protocol import *
PREP=Path(__file__).resolve().parent
PY='/private/tmp/tabmail-r5-enqueue.LUPWmvR1/tooling/venv/bin/python3'
CAP=Path('/tmp/r5-c18-contract-evidence-source-v2-20261003')

def load_json(p):
 try:return json.loads(p.read_text())
 except FileNotFoundError:return None
 except json.JSONDecodeError:return None # handshake writer may not have flushed yet; no permit before valid whole JSON

def owned_identity(pid,timeout):
 argv=['/bin/ps','-p',str(pid),'-o','pid=,uid=,pgid=,sess=,lstart=,rss=,stat=']
 p=subprocess.run(argv,capture_output=True,text=True,timeout=timeout,env={'PATH':'/usr/bin:/bin','LC_ALL':'C'})
 rows=p.stdout.strip().splitlines()
 if p.returncode!=0 or len(rows)!=1:raise ProtocolError('owned_PID_identity_unknown')
 v=rows[0].split()
 if len(v)!=11:raise ProtocolError('owned_PID_fields_unknown')
 row={'pid':int(v[0]),'uid':int(v[1]),'pgid':int(v[2]),'session_ps':v[3],'lstart':' '.join(v[4:9]),'rss_bytes':int(v[9])*1024,'stat':v[10]}
 if row['pid']!=pid:raise ProtocolError('owned_PID_mismatch')
 return row

def group_observation(pid,timeout):
 argv=['/bin/ps','-axo','pid=,uid=,pgid=,stat=']
 p=subprocess.run(argv,capture_output=True,text=True,timeout=timeout,env={'PATH':'/usr/bin:/bin','LC_ALL':'C'})
 if p.returncode:raise ProtocolError('group_observation_unknown')
 rows=[]
 for line in p.stdout.splitlines():
  v=line.split()
  if len(v)!=4:raise ProtocolError('group_parse_unknown')
  if int(v[2])==pid:rows.append({'pid':int(v[0]),'uid':int(v[1]),'pgid':int(v[2]),'stat':v[3]})
 return {'status':'observed','members':rows,'live_pids':[r['pid'] for r in rows if not r['stat'].startswith('Z')]}

def observe_parent_clock(clock):
 # One parent state shared across every phase and Freshness.clock; no handoff reset.
 wall=time.time();mono=time.monotonic();clock.check(wall,mono);return wall,mono
def bind_freshness_to_parent_clock(clock,spawnwall,spawnmono):
 # spawn timestamps may precede the already sealed start-attempt clock; never replay old observations.
 guard=Freshness(spawnwall,spawnmono);guard.parent_clock=clock;return guard

def contain_owned_child(process,identity,original_mono_deadline,qualification_failed,*,observer=None,identity_query=None,now=None,send=None,pause=None,child_signal_default=None,failed_receipt_writer=None):
 # Containment NEVER calls strict sticky qualificationclock/remain. Extra<=5 only failure.
 observer=observer or group_observation;identity_query=identity_query or owned_identity;now=now or time.monotonic;send=send or os.killpg;pause=pause or time.sleep
 child_signal_default=child_signal_default or (lambda:signal.getsignal(signal.SIGCHLD)==signal.SIG_DFL)
 start=now();original_remaining=original_mono_deadline-start
 cutoff=original_mono_deadline if original_remaining>0 else (start+5 if qualification_failed else start)
 rec={'qualification_failed':bool(qualification_failed),'qualification_admission':False,'containment_start_mono':start,'containment_cutoff_mono':cutoff,'original_mono_deadline':original_mono_deadline,'failure_only_extra_window_seconds':5 if original_remaining<=0 and qualification_failed else 0,'actions':[],'errors':[],'group':{'status':'unknown','live_pids':None},'child_exit':None}
 def left():
  value=cutoff-now()
  if value<=0:raise ProtocolError('containment_window_exhausted')
  return value
 def inspect_group():return observer(process.pid,min(.120,left()))
 def safe_signal(sig):
  current=identity_query(process.pid,min(.120,left()))
  if identity is None or not may_signal(identity,current,unreaped=process.returncode is None,default_sigchld=child_signal_default()):raise ProtocolError('containment_identity_unknown_no_signal')
  send(process.pid,sig);rec['actions'].append({'signal':sig.name,'identity':current,'mono':now()})
 try:
  group=inspect_group();rec['group']=group
  if group['status']!='observed':raise ProtocolError('containment_group_unknown')
  if group['live_pids'] and process.returncode is not None:raise ProtocolError('leader_already_reaped_group_survived_no_signal')
  if group['live_pids']:
   safe_signal(signal.SIGTERM)
   # Hold the owned unreaped leader for the whole grace, no process.poll/wait.
   grace_end=min(now()+.500,cutoff)
   while now()<grace_end:pause(min(.025,grace_end-now(),left()))
   group=inspect_group();rec['group']=group
   if group['live_pids']:safe_signal(signal.SIGKILL)
  if process.returncode is None:rec['child_exit']=process.wait(timeout=min(1.,left()))
  else:rec['child_exit']=process.returncode
 except BaseException as exc:rec['errors'].append({'class':type(exc).__name__,'reason':str(exc)[:200]})
 finally:
  # One error must not bypass final group observation or failure-receipt attempt.
  try:rec['group']=inspect_group()
  except BaseException as exc:rec['errors'].append({'group_observation_unknown':type(exc).__name__})
  rec['containment_elapsed_seconds']=now()-start;rec['containment_within_cutoff']=now()<=cutoff
  rec['cleanup_proved_gone']=rec['group'].get('status')=='observed' and not rec['group'].get('live_pids') and process.returncode is not None
  if not rec['cleanup_proved_gone'] or not rec['containment_within_cutoff']:rec['errors'].append({'cleanup':'unknown_or_remaining'})
  if failed_receipt_writer:
   rec['failure_receipt_phase']='attempt_only_not_finalcutoffproof'
   try:failed_receipt_writer(rec)
   except BaseException as exc:rec['errors'].append({'failed_receipt_unknown':type(exc).__name__})
  rec['containment_elapsed_seconds_including_receipt_attempt']=now()-start
  rec['containment_within_cutoff_after_receipt_attempt']=now()<=cutoff
  if not rec['containment_within_cutoff_after_receipt_attempt']:rec['errors'].append({'containment_budget':'receipt_attempt_over_cutoff_unknown'})
 return rec

def main():
 if os.environ.get('TABMAIL_C18_RSS_RUNTIME_APPROVED')!='1':raise SystemExit('PREPARED_ONLY: no runtime approval marker; no resource/tests started')
 if signal.getsignal(signal.SIGCHLD)!=signal.SIG_DFL:raise SystemExit('unknown parent child anchor')
 origin=time.time();mono_origin=time.monotonic();deadline=origin+90;mono_deadline=mono_origin+90;work_deadline=deadline-15;work_mono_deadline=mono_deadline-15
 wholeclock=WholeClock(origin,mono_origin)
 out=Path(tempfile.mkdtemp(prefix='tm-r5C18V2-RSS21.',dir='/private/tmp'));os.chmod(out,0o700);src=out/'src';src.mkdir();(out/'tmp').mkdir();(out/'home').mkdir()
 def write(n,x):
  observe_parent_clock(wholeclock)
  (out/n).write_text(json.dumps(x,sort_keys=True,indent=2)+'\n')
  observe_parent_clock(wholeclock)
 def remain(work=False):
  wall,mono=observe_parent_clock(wholeclock)
  return min((work_deadline if work else deadline)-wall,(work_mono_deadline if work else mono_deadline)-mono)
 failures=[];samples=[];actions=[];process=None;identity=None;returncode=None;finalgroup={'status':'not_started','live_pids':[]};guard=None;child_cpu=None;permit=False;tailpermit=False;ready_record=None;ready_received_mono=None;completion_record=None;completion_received_mono=None
 # Pending receipt before any owned start, preserved even on unknown/exception.
 write('pending-receipt.json',{'status':'not_started_unknown','origin_wall':origin,'origin_mono':mono_origin,'deadline':deadline,'mono_deadline':mono_deadline,'resources':'no PG/Go/network native services; sole audited Python group'})
 try:
  files={}
  for row in json.loads((CAP/'source-delta.json').read_text())['files']:
   rel=row['path'];raw=(CAP/'after'/rel).read_bytes()
   if hashlib.sha256(raw).hexdigest()!=row['after_sha256'] or (Path('/Users/jin/Desktop/tabmail')/rel).read_bytes()!=raw:raise ProtocolError('signed7_source_drift')
   p=src/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(raw);p.chmod(0o444);files[rel]=hashlib.sha256(raw).hexdigest()
  for p in sorted([src]+[p for p in src.rglob('*') if p.is_dir()],key=lambda p:len(p.parts),reverse=True):p.chmod(0o555)
  canonical=json.dumps(files,sort_keys=True,separators=(',',':')).encode();source_sha=hashlib.sha1(canonical).hexdigest();closure=hashlib.sha256(canonical).hexdigest()
  if source_sha!='6710e89d677d027f3baa0498206e0baf226f3a16' or closure!='52c2f082061b4fa8e9c66d8f3a6990d765f0f2481ee0b75d8724ef42be10623e':raise ProtocolError('signed_scope_closure_mismatch')
  write('source-receipt.json',{'files':files,'source_sha':source_sha,'actual_source_closure_sha256':closure,'scope':'signed7puregrammar only; no fullsourcecapture','snapshot_root':str(src)})
  selectors=json.loads((CAP/'fresh-selectors.json').read_text())['targets'];assert len(selectors)==21 and len(set(selectors))==21;write('selectors.json',selectors)
  env={'PATH':'/usr/bin:/bin','HOME':str(out/'home'),'TMPDIR':str(out/'tmp'),'PYTHONDONTWRITEBYTECODE':'1','PYTHONNOUSERSITE':'1','LC_ALL':'C','C18_WORK_DEADLINE_UNIX':str(work_deadline),'C18_MONO_ORIGIN':str(mono_origin),'C18_WORK_MONO_DEADLINE':str(work_mono_deadline)}
  argv=[PY,'-B',str(PREP/'c18_audited_child.py'),str(src),str(out)]
  write('runtime-command.json',{'argv':argv,'cwd':str(src),'environment_allowlist':env,'external_exception_whitelist':[['/bin/ps','-p','<ownedPID>','-o','pid=,uid=,pgid=,sess=,lstart=,rss=,stat='],['/bin/ps','-axo','pid=,uid=,pgid=,stat=']],'CPU60':'child actual readback mandatory before import','RSS':'1GiB100ms sampling/maxgap250ms; not hardquota/inter-sample peaks cannot be excluded','wall90':'original beforecapture;75swork+15s cleanup within90; monotonic only supplemental not replacing wallorigin'})
  if remain(True)<=.5:raise ProtocolError('original_work_budget_exhausted_before_start')
  with (out/'tests.stdout').open('w') as stdout,(out/'tests.stderr').open('w') as stderr:
   spawnwall=time.time();spawnmono=time.monotonic();process=subprocess.Popen(argv,cwd=src,env=env,stdout=stdout,stderr=stderr,start_new_session=True)
   write('owned-start-attempt.json',{'pid':process.pid,'expected_uid':os.getuid(),'expected_pgid_sid':process.pid,'start_wall':spawnwall,'start_mono':spawnmono,'argv':argv})
   guard=bind_freshness_to_parent_clock(wholeclock,spawnwall,spawnmono)
   while True:
    wall,mono=observe_parent_clock(wholeclock);guard.tick(wall,mono)
    if remain(True)<=0:raise ProtocolError('original_work_deadline_reached')
    if ready_record is None:
     ready_record=load_json(out/'child-ready.json')
     if ready_record is not None:ready_received_mono=time.monotonic()
    if completion_record is None:
     completion_record=load_json(out/'child-completion-ready.json')
     if completion_record is not None:completion_received_mono=time.monotonic()
    begin=time.monotonic();current=owned_identity(process.pid,min(.120,remain(True)))
    if identity is None:
     if current['uid']!=os.getuid() or current['pgid']!=process.pid or os.getsid(process.pid)!=process.pid:raise ProtocolError('owned_session_UID_unknown')
     identity=current.copy();write('owned-identity.json',identity)
    elif not identity_equal(identity,current):raise ProtocolError('owned_identity_changed')
    if current['stat'].startswith('Z'):
     guard.finalize(time.time(),time.monotonic())
     finalgroup=group_observation(process.pid,min(.120,remain()))
     if finalgroup['live_pids']:raise ProtocolError('leader_exited_owned_group_members_survived')
     # Anchor held until exact group observed empty, then join/reap.
     returncode=process.wait(timeout=max(.001,min(.120,remain())));break
    samplewall=time.time();samplemono=time.monotonic();guard.sample(begin,samplewall,samplemono,current['rss_bytes']);sample={'wall':samplewall,'mono':samplemono,'begin_mono':begin,'rss_bytes':current['rss_bytes'],'pid':process.pid,'identity_equal':True};samples.append(sample)
    ready=ready_record
    if not permit and ready is not None:
     post_handshake_sample_valid(ready_received_mono,sample)
     child_cpu=ready.get('cpu_readback')
     if any(ready.get(k)!=v for k,v in {'uid':os.getuid(),'pgid':process.pid,'sid':process.pid}.items()):raise ProtocolError('child_ready_identity_unknown')
     if samplewall<ready['wall']:raise ProtocolError('first_postready_RSS_required')
     import_gate(audit_armed=ready.get('audit_armed'),cpu_readback=child_cpu,ready_pid=ready.get('pid'),owned_pid=process.pid,sample=sample,now=time.time())
     write('import-permit.json',{'owned_pid':process.pid,'child_uid':os.getuid(),'first_postready_sample':sample,'monitor_armed':True,'complete_handshake_received_mono':ready_received_mono,'dedicated_sample_start_mono':sample['begin_mono'],'wall':time.time()});permit=True
    completed=completion_record
    if completed and not tailpermit:
     post_handshake_sample_valid(completion_received_mono,sample)
     if completed['pid']!=process.pid or samplewall<completed['wall']:raise ProtocolError('postcompletion_sample_required')
     write('completion-permit.json',{'owned_pid':process.pid,'last_live_sample_wall':samplewall,'complete_handshake_received_mono':completion_received_mono,'dedicated_sample_start_mono':sample['begin_mono'],'wall':time.time()});tailpermit=True
    time.sleep(max(0,min(.100-(time.monotonic()-begin),remain(True))))
 except BaseException as e:failures.append({'class':type(e).__name__,'reason':str(e)[:240]})
 finally:
  # Strict qualification failures stay sticky but cannot block failed containment.
  try:
   if remain()<=0:failures.append({'budget':'original90window_exceeded'})
  except BaseException as exc:failures.append({'qualification_clock_failed':str(exc)[:200]})
  if guard and guard.failed:failures.append({'sticky_resource_failures':guard.failed})
  if process is not None:
   def failed_containment_receipt(rec):
    # Explicit failed-only evidence path: never success admission or more test work.
    if rec['qualification_failed']:
     (out/'failed-containment-receipt.json').write_text(json.dumps({'qualification_admission':False,'original_origin_wall':origin,'original90_deadline':deadline,'sticky_clock_failures':wholeclock.failures,'failures':failures,'containment':rec},sort_keys=True,indent=2)+'\n')
   containment=contain_owned_child(process,identity,mono_deadline,bool(failures or wholeclock.failures),failed_receipt_writer=failed_containment_receipt)
   finalgroup=containment['group'];actions=containment['actions'];returncode=containment['child_exit']
   if containment['errors'] or not containment['cleanup_proved_gone']:failures.append({'failed_containment':containment})
   # Qualified normal observation has no containment extra allowance.
   if containment['failure_only_extra_window_seconds'] and not failures:failures.append({'failure_only_extra_window_used':True})
  if finalgroup.get('status')!='observed' and process is not None or finalgroup.get('live_pids'):failures.append({'cleanup':'owned_group_not_proven_gone'})
  result=load_json(out/'test-result.json');proof=load_json(out/'child-proof.json')
  try:
   post={p:hashlib.sha256((src/p).read_bytes()).hexdigest() for p in files};write('source-after.json',{'files':post,'same':post==files})
   if post!=files:failures.append({'source':'after_drift'})
  except BaseException as e:failures.append({'source_post_unknown':type(e).__name__})
  passed=returncode==0 and permit and tailpermit and result and proof and result['testsRun']==21 and result['successful'] and not result['skipped'] and not result['audit_denials'] and not failures
  try:write('RSS-samples.json',{'unit':'bytes converted from ps KiB *1024','target_interval_seconds':.100,'max_gap_allowed_seconds':.250,'samples':samples,'max_gap_observed_seconds':guard.max_gap if guard else None,'first_sample':guard.first_sample if guard else None,'tail_handshake':tailpermit,'hardquota':False,'intersample_peaks_excluded':False})
  except BaseException as e:failures.append({'RSS_receipt_unknown':type(e).__name__});passed=False
  # No PASS status in terminal body until separate final admission+outerexit chain.
  terminal={'status':'SEALED_CANDIDATE_ONLY_NOT_ACCEPTED','origin_wall':origin,'deadline':deadline,'origin_mono':mono_origin,'elapsed_wall_seconds':time.time()-origin,'elapsed_mono_seconds':time.monotonic()-mono_origin,'child_exit':returncode,'CPU_actual_readback':child_cpu,'import_permit':permit,'completion_permit':tailpermit,'cleanup':finalgroup,'cleanup_signals':actions,'failures':failures,'result':result,'runtime_qualification':False,'current_METHOD_admission':False,'no_hard_memory_quota_claim':True}
  def check_seal_clock():observe_parent_clock(wholeclock)
  def write_pending():
   # The earlier sourceafter/RSS/cleanup proof writes have all finished now.
   (out/'terminal-receipt.json').write_text(json.dumps(terminal,sort_keys=True,indent=2)+'\n')
  def publish():
   (out/'final-admission.json').write_text(json.dumps({'accepted_RSS_sampling_puregrammar':True,'clock_wall_before_publication':time.time(),'origin_wall':origin,'original_deadline':deadline,'not_runtime_qualification':True})+'\n')
  def revoke():
   (out/'final-admission.json').unlink(missing_ok=True)
  accepted=final_seal(write_pending,publish,revoke,check_seal_clock,passed)
  # No evidence serialization after final clock gate; stdout path only.
  print(str(out),flush=True)
  try:check_seal_clock()
  except BaseException:
   revoke();accepted=False
  return 0 if accepted else 1
if __name__=='__main__':sys.exit(main())
