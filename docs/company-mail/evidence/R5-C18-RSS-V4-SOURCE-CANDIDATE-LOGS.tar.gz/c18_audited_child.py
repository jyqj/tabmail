"""Runtime dormant until explicitly dispatched by separately approved outer owner."""
import os,sys,time,json,resource
from pathlib import Path
from c18_rss_protocol import import_gate,post_handshake_sample_valid
ROOT=Path(sys.argv[1]).resolve();OUT=Path(sys.argv[2]).resolve();TMP=OUT/'tmp'
# Outer created descriptors, opened before hook, never an escape for fixture open.
audit=open(OUT/'audit.jsonl','w',buffering=1); events=open(OUT/'test-events.jsonl','w',buffering=1)
resultfile=open(OUT/'test-result.json','w'); ready=open(OUT/'child-ready.json','w',buffering=1)
finished=open(OUT/'child-completion-ready.json','w',buffering=1); childproof=open(OUT/'child-proof.json','w')
observed=0;denials=[];writes=0

def deny(e,reason):
 denials.append(e);audit.write(json.dumps({'event':e,'reason':reason,'wall':time.time()})+'\n');raise RuntimeError('C18 audit denied '+e)
def in_owned_tmp(v):
 if isinstance(v,int):return False
 try:return Path(os.fsdecode(v)).resolve().is_relative_to(TMP)
 except Exception:return False
def hook(e,a):
 global observed,writes
 observed+=1
 if e.startswith(('subprocess.','socket.','ctypes.')) or e in {'os.system','os.fork','os.forkpty','os.posix_spawn','os.posix_spawnp','pty.spawn','socket.connect','socket.bind','socket.listen','os.kill','os.killpg'} or e.startswith('os.exec'):
  deny(e,'process/network action forbidden inside pure fixture')
 if e=='open':
  mode=a[1];flags=a[2]
  iswrite=(isinstance(mode,str) and any(c in mode for c in 'wax+')) or (isinstance(flags,int) and bool(flags & (os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC|os.O_APPEND)))
  if iswrite:
   if not in_owned_tmp(a[0]):deny(e,'write outside owned fixture tempdir')
   writes+=1
 if e in {'os.remove','os.rmdir','os.mkdir','os.chmod','os.chown','os.utime','os.truncate'}:
  if not in_owned_tmp(a[0]):deny(e,'mutation outside owned fixture tempdir')
 if e in {'os.rename','os.link','os.symlink'}:
  if not all(in_owned_tmp(v) for v in a[:2]):deny(e,'mutation outside owned fixture tempdir')
sys.addaudithook(hook)
# No AS attempt or except-pass fallback: new RSS sampling contract is explicit.
resource.setrlimit(resource.RLIMIT_CPU,(60,60));cpu=list(resource.getrlimit(resource.RLIMIT_CPU))
if cpu!=[60,60]:raise RuntimeError('CPU readback missing exact60')
identity={'pid':os.getpid(),'uid':os.getuid(),'pgid':os.getpgrp(),'sid':os.getsid(0)}
ready.write(json.dumps({'audit_armed':True,'cpu_readback':cpu,'wall':time.time(),**identity}));ready.flush()

def wait_permit(name):
 # Origin/deadline are parent pinned; never resets phase budget.
 deadline=float(os.environ['C18_WORK_DEADLINE_UNIX']);mono_origin=float(os.environ['C18_MONO_ORIGIN']);mono_deadline=float(os.environ['C18_WORK_MONO_DEADLINE'])
 previous=time.time()
 while True:
  now=time.time()
  if now<previous or now>=deadline or time.monotonic()>=mono_deadline:raise RuntimeError('parent original budget/clock denied child permit')
  previous=now
  p=OUT/name
  if p.exists():return json.loads(p.read_text())
  time.sleep(.010)
permit=wait_permit('import-permit.json')
post_handshake_sample_valid(permit['complete_handshake_received_mono'],permit['first_postready_sample'])
import_gate(audit_armed=True,cpu_readback=cpu,ready_pid=identity['pid'],owned_pid=permit['owned_pid'],sample=permit['first_postready_sample'],now=time.time())
if permit['child_uid']!=identity['uid'] or identity['pid']!=identity['pgid'] or identity['pid']!=identity['sid']:raise RuntimeError('child monitor handshake identity mismatch')
# First test import is strictly after armed audit, CPU readback and outer first RSS.
import_wall=time.time();import unittest
sys.path.insert(0,str(ROOT));os.chdir(ROOT)
class Result(unittest.TextTestResult):
 def event(self,t,status):events.write(json.dumps({'test':t.id(),'status':status,'wall_ns':time.time_ns()})+'\n')
 def startTest(self,t):self.event(t,'start');super().startTest(t)
 def addSuccess(self,t):self.event(t,'pass');super().addSuccess(t)
 def addError(self,t,e):self.event(t,'error');super().addError(t,e)
 def addFailure(self,t,e):self.event(t,'fail');super().addFailure(t,e)
 def addSkip(self,t,r):self.event(t,'skip');super().addSkip(t,r)
 def addSubTest(self,t,s,e):self.event(s,'subtest_pass' if e is None else 'subtest_fail');super().addSubTest(t,s,e)
names=json.loads((OUT/'selectors.json').read_text());suite=unittest.defaultTestLoader.loadTestsFromNames(names)
def flatten(s):
 for t in s:
  if isinstance(t,unittest.TestSuite):yield from flatten(t)
  else:yield t.id()
discovered=list(flatten(suite))
if discovered!=names:raise RuntimeError('exact21 discovery mismatch')
res=unittest.TextTestRunner(verbosity=2,resultclass=Result).run(suite)
summary={'discovered':discovered,'testsRun':res.testsRun,'failures':[t.id() for t,_ in res.failures],'errors':[t.id() for t,_ in res.errors],'skipped':[t.id() for t,_ in res.skipped],'successful':res.wasSuccessful(),'audit_denials':denials,'runtime_qualification':False}
json.dump(summary,resultfile);resultfile.close();events.flush();audit.write(json.dumps({'summary':True,'audit_events_observed':observed,'audit_denials':denials,'owned_tmp_write_events':writes})+'\n');audit.flush()
finished.write(json.dumps({'pid':identity['pid'],'wall':time.time(),'testsRun':res.testsRun}));finished.flush()
endpermit=wait_permit('completion-permit.json')
if endpermit['dedicated_sample_start_mono']<endpermit['complete_handshake_received_mono']:raise RuntimeError('postcompletion RSS query began before complete handshake')
if endpermit['owned_pid']!=identity['pid'] or time.time()-endpermit['last_live_sample_wall']>.250:raise RuntimeError('tail RSS monitor handshake stale')
json.dump({'identity':identity,'audit_armed_before_import':True,'CPU60_actual_readback':cpu,'first_test_import_wall':import_wall,'import_permit':permit,'completion_permit':endpermit},childproof);childproof.close();audit.close();events.close();ready.close();finished.close()
sys.exit(0 if res.wasSuccessful() and not denials else 1)
