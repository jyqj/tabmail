"""External, reviewed-tool preparation around the unchanged versioned runner."""
import base64
import hashlib
import importlib.util
import io
import json
import os
from pathlib import Path
import sys
import tarfile
import urllib.request

ROOT = Path('/workspace/tabmail')
OUT = Path('/workspace/r5-batch5/logs')
sys.path.insert(0, str(ROOT/'scripts'))
import run_r5_source_version_tests as runner
import r5_selected_source_binding_v2 as binding

pin = json.loads((ROOT/'docs/company-mail/evidence/R5-INTEGRATION-BATCH4-20261003/typescript-tool-pin.json').read_text())
raw = urllib.request.urlopen(pin['resolved'], timeout=60).read()
assert hashlib.sha256(raw).hexdigest() == pin['tar_sha256']
assert 'sha512-'+base64.b64encode(hashlib.sha512(raw).digest()).decode() == pin['integrity']
payload = {}
with tarfile.open(fileobj=io.BytesIO(raw), mode='r:gz') as archive:
    for entry in archive:
        if entry.isdir():
            continue
        assert entry.isfile() and entry.name.startswith('package/')
        name = entry.name[len('package/'):]
        assert name and '..' not in Path(name).parts and not Path(name).is_absolute()
        assert Path(name).suffix not in ('.go', '.so', '.a') and Path(name).name not in ('go.mod', 'go.sum')
        payload[name] = archive.extractfile(entry).read()
assert {name:hashlib.sha256(data).hexdigest() for name,data in payload.items()} == pin['files_sha256']
(OUT/'typescript-pin-verified.json').write_text(json.dumps(dict(tar_sha256=pin['tar_sha256'],integrity=pin['integrity'],regular_files=len(payload),files_sha256=pin['files_sha256']),indent=2)+'\n')
original_checkout = runner.checkout
observations = []

def checkout(root, destination, sha):
    original_checkout(root, destination, sha)
    before = after = None
    if sha != runner.BASELINE:
        before = {label:binding.capture(destination, Path(os.environ['R5_TEST_GO']), cache=Path(os.environ['R5_TEST_CACHE']), modulecache=Path(os.environ['R5_TEST_MODULECACHE']), context=context)
                  for label,context in [('default',binding.DEFAULT_CONTEXT),('race-r5protocol',binding.CONTEXT)]}
    for name,data in payload.items():
        target = Path(destination)/'web/node_modules/typescript'/name
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(data)
    if before is not None:
        after = {label:binding.capture(destination, Path(os.environ['R5_TEST_GO']), cache=Path(os.environ['R5_TEST_CACHE']), modulecache=Path(os.environ['R5_TEST_MODULECACHE']), context=context)
                 for label,context in [('default',binding.DEFAULT_CONTEXT),('race-r5protocol',binding.CONTEXT)]}
        keys = ['selected_local','selected_local_packages','root_mvs','production_coverage','base_source','environment','go_env','generated_testmain','external_modulecache_inputs','native_inputs','toolchain_source_inputs','package_records','archive_static']
        comparisons = {label:{key:before[label].get(key)==after[label].get(key) for key in keys} for label in before}
        assert all(all(v.values()) for v in comparisons.values()), comparisons
        (OUT/'prepared-before-after-capture.json').write_text(json.dumps(dict(source_sha=sha,before=before,after=after,comparisons=comparisons),indent=2)+'\n')
    observations.append(dict(source_sha=sha,regular_files=len(payload),clean_tracked=not runner.git(destination,'status','--porcelain','--untracked-files=no')))
    (OUT/'prepared-checkouts.json').write_text(json.dumps(observations,indent=2)+'\n')

runner.checkout = checkout
raise SystemExit(runner.run(ROOT, OUT/'versioned-prepared.json'))
